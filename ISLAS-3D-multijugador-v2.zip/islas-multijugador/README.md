# ISLAS 3D — Versión inmersiva 3.0

Juego original de mesa digital para 2–6 personas. No es una adaptación oficial de CATAN.

## Mejoras de esta versión
- Tablero WebGL en pantalla completa sin desplazamiento vertical de la página en partida.
- HUD flotante responsive para jugadores, recursos, construcciones, chat, asistente, cartas y perfil.
- Cámara de mesa / primera persona, y acceso opcional a pantalla completa del navegador.
- Dados físicos sencillos animados sobre la mesa, con resultados sincronizados por servidor.
- Indicadores 3D más grandes para construir carreteras, poblados y ciudades.
- Materiales procedurales refinados y menos costosos en GPU.
- Redibujo adaptativo (aprox. 30 FPS móvil, hasta 50 FPS escritorio) y menos regeneración de mallas.
- El motor multijugador existente y la desconexión segura se mantienen.

## Desarrollo local

```bash
npm test
npm start
```

Visitar http://localhost:3000. Para publicar en Render se requiere Node 20+.

## Despliegue en Render (repositorio existente)

El servicio existente descomprime el archivo con nombre `ISLAS-3D-multijugador-v2.zip`, ejecuta las pruebas desde la carpeta `islas-multijugador` y arranca el servidor. Por compatibilidad, el paquete distribuido para actualizar el servidor **conserva ese nombre**. Para nuevas instalaciones es preferible publicar el contenido descomprimido en GitHub, con raíz `islas-multijugador`.

Las salas se persisten en un archivo local; **Render gratuito no garantiza su conservación entre reinicios y despliegues**. Para partidas persistentes se requiere un almacenamiento externo duradero.

## Alcance

Esta versión prioriza interfaz, fluidez y claridad. Los materiales se generan procedimentalmente y **todavía no son renderizado fotorrealista PBR con texturas de escaneo**. Chat de voz y conexión de jugadores requieren prueba real entre dispositivos. Los ajustes responsive se han comprobado a nivel estático y unitario; no sustituyen una prueba visual de navegación en múltiples móviles.
