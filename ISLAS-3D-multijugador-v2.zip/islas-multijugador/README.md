# ISLAS 3D · 5.0 · Corrección de colocación e interfaz adaptable

- **Colocación inicial:** mapa táctico automático para la primera casa y la carretera; sin arrastre de cámara accidental.
- **Selección fiable:** botón de confirmación y marcadores ampliados en la vista 2D; la cámara 3D requiere gesto deliberado, y durante la construcción un dedo no la mueve.
- **Multidispositivo:** HUD responsivo y mapa táctico para teléfonos verticales/horizontales, tablets y escritorio; sin scroll de página.
- **Compatibilidad:** conserva reglas, salas, imágenes de jugadores y optimizaciones gráficas de v4.

## Ejecutar
`npm start` y `npm test` (Node >=20).

## Publicar en Render
El repositorio existente contiene el ZIP `ISLAS-3D-multijugador-v2.zip`; este paquete tiene la misma estructura y el mismo nombre para sustituirlo. Luego hay que disparar un deploy de la última versión de `main`.

## Limitaciones
La vista 3D depende de WebGL2. Las salas en el plan gratuito de Render no tienen almacenamiento persistente garantizado entre reinicios. Los cambios deben validarse visualmente en dispositivos reales.
