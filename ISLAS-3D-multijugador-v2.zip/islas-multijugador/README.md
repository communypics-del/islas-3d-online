# ISLAS 3D — sala multijugador de mesa (versión 2.0)

Experiencia de estrategia y construcción por recursos para amigos. **ISLAS es un proyecto original independiente, no es CATAN oficial**. No incluye material gráfico oficial ni expansiones licenciadas.

## Lo que incluye

- Home con catálogo de juegos: **ISLAS disponible**; juegos adicionales marcados como próximamente.
- Salas privadas por enlace de 8 caracteres hexadecimales, de **2 a 6 jugadores**, con presencia visible para quien abra una invitación antes de unirse. Los enlaces son invitaciones, no autenticación de cuentas.
- Tablero, sala, mesa, paredes, iluminación, personajes, sillas, caminos y casas renderizados en **WebGL 2 real 3D**, sin dependencias externas. Materiales procedurales y geometría volumétrica; son estilizados, no modelos fotorrealistas profesionales.
- Vista panorámica orbitable con cursor o táctil, zoom mediante rueda y transición al asiento propio al llegar el turno; botón para volver a vista general.
- Fotografía opcional al entrar o durante la partida: comprimida en el navegador y representada como textura sobre un avatar humanoide estilizado. **No se reconstruye biometría facial ni un modelo 3D de rostro/cuerpo fiel**. Se puede quitar la fotografía de la sala.
- Chat de voz **WebRTC**, participación voluntaria, silenciar micrófono y salir. Las voces viajan entre los navegadores (P2P); el servidor solo transporta señales SDP/ICE. Navegadores deben autorizar el micrófono. HTTPS requerido fuera de `localhost`.
- Chat escrito y registro de jugadas, reconexión por token de asiento, comunicación SSE de estado, validación de reglas en servidor.
- Juego original tipo construcción/comercio: dados, producción, ladrón, descarte, caminos, poblados, ciudades, intercambio bancario y entre amigos, cartas de desarrollo, puertos, premios y victoria. Tablero expandido para 5–6, turno de apoyo emparejado.
- Asistente privado por jugador que identifica construcciones legales, recursos faltantes y sugerencias.
- Juego básico **Clásico** y escenario original **Gran continente**. No incluye Navegantes/Ciudades y Caballeros ni otras expansiones oficiales.
- Si WebGL 2 no está disponible, se usa un tablero SVG 2D para continuar la partida.

## Cómo ejecutarlo

Instalar Node.js 20+; no hay dependencias que descargar.

```bash
npm start
```

Abrir http://localhost:3000; crear sala y compartir enlace. Para probar con un segundo jugador en el mismo equipo, usar otro navegador o ventana privada, o abrir la URL desde otro dispositivo apuntando a la IP del equipo. Los permisos de micrófono **solo funcionan en `localhost` o dominios HTTPS**; una IP local HTTP normalmente no permite el audio.

Pruebas: `npm test`.

## Publicación con Render

Este juego requiere un servidor Node en ejecución, no un hosting web estático.

1. Subir la carpeta del proyecto a un repositorio GitHub sin `data/rooms.json` (ya figura en `.gitignore`).
2. En Render, crear **New Web Service** desde ese repositorio, o usar el `render.yaml` incluido.
3. Comando inicial `npm start`; build `echo ready` o el configurado por `render.yaml`.
4. Al terminar, Render te entrega un dominio HTTPS, necesario para acceder al micrófono en navegadores remotos.
5. Abrir la URL pública y compartir enlaces de las salas.

**Persistencia**: Render gratuito puede dormir/reiniciar el servicio, con almacenamiento local efímero. Esto puede eliminar las salas y fotos. Para mantener partidas y avatares durante mucho tiempo, usar disco persistente y definir `ROOMS_FILE=/ruta/rooms.json` o integrar PostgreSQL/Redis. **No está desplegado automáticamente**: descargar este código no publica el sitio.

## Voz: características y límites importantes

La solución de voz utiliza una *malla WebRTC* de hasta seis personas, con STUN público para establecer conexiones. **En algunas redes con NAT estricto o firewall la voz puede fallar**; para producción se debe instalar/configurar un servidor TURN (por ejemplo coturn) y agregar las credenciales apropiadas a `public/voice.js`. Para escalar más allá de seis usuarios por llamada conviene usar un servidor SFU. La conexión real a través de redes distintas no se ha podido verificar de extremo a extremo en este entorno de pruebas.

Para activar el audio, cada participante debe pulsar `Entrar a voz` y aprobar el permiso. El micrófono jamás se activa automáticamente al ingresar. Puede silenciarlo o salir en cualquier momento.

## Sobre la estética 3D

El motor WebGL genera la geometría 3D mediante código y utiliza materiales de ruido/procedurales, sombreado e iluminación. Es una **primera versión jugable**, más cercana a un juego 3D estilizado que a un render de arquitectura fotorrealista. Para llegar al acabado solicitado se necesitan modelos de mobiliario y personajes 3D con alto detalle, texturas PBR (madera, piel, tela, rocas), luces de área, sombras, normal maps, HDRI y optimización móvil. La reconstrucción facial fiel desde una foto es una integración distinta, con control explícito de consentimiento, almacenamiento y privacidad. No se debe afirmar que esta versión ya crea modelos humanos realistas con identidad facial precisa.

## Privacidad y seguridad

- Los retratos son opcionales y se almacenan como JPEG comprimido dentro del estado de la sala. Se comparten con quienes poseen su enlace, incluso antes de unirse, para mostrar quién está en la mesa.
- No se almacenan grabaciones de voz; no existe un servidor central de audio en este prototipo.
- Los tokens secretos que autorizan a actuar en cada asiento **no se incluyen en los datos públicos de otros jugadores**. Los IDs públicos de jugador son independientes.
- Existe un botón **Quitar foto** que elimina inmediatamente el retrato del estado del servidor de la sala. Las copias previas que los participantes hayan cargado en sus navegadores no se pueden revocar retroactivamente.
- Las salas se eliminan de la memoria al reinicio o al recargar tras siete días. El proyecto todavía no dispone de cuentas, moderación avanzada, controles parentales ni base de datos para producción.

## Archivos

- `game.js`: motor de partidas y asistentes.
- `server.js`: REST, presencia, salas, SSE y señalización WebRTC.
- `public/scene3d.js`: motor WebGL 2 y experiencia 3D.
- `public/voice.js`: chat de voz WebRTC.
- `public/main.js`: interfaz, lobby, modo de juego, acciones y sincronización.
- `public/styles.css`: diseño responsive.
- `tests/game.test.js`: pruebas automatizadas de reglas.
- `render.yaml`/`Dockerfile`: despliegue.
