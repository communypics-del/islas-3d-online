# ISLAS 3D · v6.0 · Intercambios estables y tablero inicial oculto

## Cambios de v6

1. **Intercambio con la banca:** se conserva la elección de recursos mientras llegan mensajes o cambios de estado del servidor. El menú no desaparece ni se sustituye al actualizar la partida. Los recursos predeterminados son distintos y se muestra de antemano la tasa según los puertos (4:1, 3:1 o 2:1), las existencias y si se puede confirmar. Los intercambios inválidos no cambian las cartas.
2. **Intercambios entre personas:** se conserva el destinatario y los contadores cuando se actualiza el panel. Se evitan envíos duplicados mientras hay una acción pendiente y se conserva el desplazamiento interno de la ventana.
3. **Colocación inicial a ciegas:** los terrenos son neutros e idénticos en la vista 3D y en el mapa táctico, sin números ni materiales reconocibles, puertos ni posición del ladrón. **El servidor omite los tipos y números en los datos enviados**, además de ocultar recursos/tarifas durante esa fase. Al colocar la última carretera de la segunda ronda se revela todo el terreno, los números y los puertos para todos a la vez.
4. **Compatibilidad:** conserva salas multijugador, cámara orbital, vista táctica, construcción, dados, chat y voz de la versión anterior.

## Pruebas

`npm test` — 27 pruebas superadas en Node.js >= 20: reglas de la partida, 2–6 jugadores, colocación inicial, intercambio bancario 4:1/3:1/2:1, recursos insuficientes, banca agotada, intercambio entre jugadores, información oculta del tablero, conservación de menús de selección, cámara e interfaz.

`npm start` — inicia el servidor en el puerto `PORT`, por defecto 3000.

## Publicación en Render

Subí el ZIP adjunto **con el mismo nombre exacto** `ISLAS-3D-multijugador-v2.zip` a la rama `main` del repositorio existente `communypics-del/islas-3d-online`. El servicio Render ya está configurado para descomprimirlo y arrancar `islas-multijugador/server.js`. Después se debe desplegar el commit nuevo. El ZIP contiene la carpeta `islas-multijugador/` y un `data/rooms.json` vacío.

## Limitaciones

La prueba gráfica completa en navegadores reales no se completó porque Chromium no pudo abrir el servidor local en el entorno de pruebas. Render Free no garantiza la persistencia de las salas tras reinicios/suspensiones. Se recomienda terminar las partidas activas antes de desplegar; la actualización reinicia el servidor.
