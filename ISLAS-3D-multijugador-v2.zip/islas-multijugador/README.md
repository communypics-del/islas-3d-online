# ISLAS 3D · v7.0 · Corrección completa del ladrón

## Problema resuelto

Al sacar un **7**, la UI mostraba terrenos seleccionables para el ladrón, pero `placementAllowed()` los rechazaba porque el servidor no enviaba `actions.robber.positions`. Ahora los hexágonos válidos están publicados solo para el jugador activo, el mapa táctico se abre automáticamente y se puede seleccionar y confirmar una casilla distinta a la actual. También se puede volver a la vista 3D.

## Secuencia de juego

1. Al lanzar **7**, cada jugador con más de siete recursos descarta la mitad (redondeando hacia abajo). Si no hay descarte, se pasa directamente al mapa del ladrón.
2. El jugador activo mueve el ladrón a **otro** hexágono, confirmado mediante el mapa táctico o el escenario 3D. Se bloquea la producción en ese terreno hasta que se vuelva a mover.
3. Si en la casilla seleccionada hay jugadores rivales con un poblado o ciudad adyacente **y con alguna carta de recurso**, aparece un panel accesible con sus nombres, retratos y la cantidad total de cartas. El usuario elige a quién robar, incluso si solo hay un candidato.
4. Se roba **exactamente una carta de recurso aleatoria** de ese jugador. Se transfieren recursos en el servidor, sin exponer su mano a otros jugadores. Si no hay rivales elegibles, se vuelve directamente a la fase principal.
5. Las mismas reglas de ubicación/robo funcionan cuando se juega la carta **Caballero**.

## Comprobaciones

`npm test`: **32 pruebas superadas**, incluidas cinco pruebas nuevas de movimiento, privilegios de turno, victimarios válidos, privacidad, casos de uno/varios/ningún rival y cartas Caballero.

`node --check`: verificación de sintaxis JS del servidor, reglas y cliente.

Prueba HTTP local: mover ladrón, seleccionar rival y verificar transferencia exacta de una carta; el servidor confirma la fase principal después del robo.

**Limitación:** la prueba con Chromium no pudo cargar `localhost` debido a `ERR_BLOCKED_BY_ADMINISTRATOR`. Hay que probar el diseño en celular/computadora una vez publicado.

## Publicación

El archivo ZIP está preparado para la configuración existente de Render: subir **`ISLAS-3D-multijugador-v2.zip`** al directorio raíz del repositorio `communypics-del/islas-3d-online`, reemplazando el anterior, y confirmar el commit. Render descomprime automáticamente el directorio `islas-multijugador/`, ejecuta sus pruebas e inicia `server.js`.

El archivo `data/rooms.json` incluido está vacío para no distribuir fichas de sesiones, pero **una actualización del servidor puede interrumpir las salas actuales**. Finalizar partidas antes de publicar. La persistencia tras reinicios en Render Free no está garantizada.
