import { randomBytes } from 'node:crypto';

export const RES = ['wood','brick','wool','grain','ore'];
export const RES_ES = {wood:'Madera',brick:'Arcilla',wool:'Lana',grain:'Trigo',ore:'Mineral'};
export const COSTS = {road:{wood:1,brick:1},settlement:{wood:1,brick:1,wool:1,grain:1},city:{grain:2,ore:3},development:{wool:1,grain:1,ore:1}};
const HEX_TO_RES = {forest:'wood',hill:'brick',pasture:'wool',field:'grain',mountain:'ore'};
const COLORS = ['#e48f56','#70b4bb','#e3bf60','#b28bcc','#8fc578','#dc7799'];
const rand = n => Math.floor(Math.random()*n);
const shuffle = a => { const b=[...a]; for(let i=b.length-1;i>0;i--){const j=rand(i+1);[b[i],b[j]]=[b[j],b[i]]}return b};
const uid = () => randomBytes(18).toString('base64url');
const clampStr = (s,max=25) => String(s??'').replace(/[<>\r\n]/g,'').trim().slice(0,max);
const sum = o => Object.values(o||{}).reduce((a,b)=>a+b,0);
const cardCount = p => sum(p.hand);
const copy = o => JSON.parse(JSON.stringify(o));
const has = (p,c) => Object.entries(c).every(([k,v])=>(p.hand[k]||0)>=v);
const cost = (p,c) => {if(!has(p,c)) throw Error('No tienes los recursos necesarios.'); for(const [k,v] of Object.entries(c))p.hand[k]-=v};
const creditBank = (g,c) => {for(const[k,v] of Object.entries(c))g.bank[k]+=v};
const pay = (g,p,c) => {cost(p,c);creditBank(g,c)};
const log = (g,s) => {g.log.unshift({at:Date.now(),text:s});g.log=g.log.slice(0,45)};
function coordsFor(size){
 const lengths=size===2?[3,4,5,4,3]:[3,4,5,6,5,4,3]; const out=[];
 const mid=Math.floor(lengths.length/2);
 for(let r=0;r<lengths.length;r++)for(let col=0;col<lengths[r];col++){
   const axialR=r-mid;const axialQ=col-Math.floor((lengths[r]-1)/2)-Math.ceil(axialR/2);
   out.push({q:axialQ,r:axialR});
 }return out;
}
export function buildBoard(size=2){
 const coords=coordsFor(size); const n=coords.length;const resBag=n===19?
  ['forest','forest','forest','forest','hill','hill','hill','pasture','pasture','pasture','pasture','field','field','field','field','mountain','mountain','mountain','desert']:
  ['forest','forest','forest','forest','forest','forest','hill','hill','hill','hill','hill','pasture','pasture','pasture','pasture','pasture','pasture','field','field','field','field','field','field','mountain','mountain','mountain','mountain','desert','desert','hill'];
 let numBag=n===19?[2,3,3,4,4,5,5,6,6,8,8,9,9,10,10,11,11,12]:[2,2,3,3,3,4,4,4,5,5,5,6,6,6,8,8,8,9,9,9,10,10,10,11,11,11,12,12];
 const tiles=shuffle(resBag);numBag=shuffle(numBag);let ni=0;
 const vertices=[];const edges=[];const vByKey=new Map();const eByKey=new Map();
 const hexes=coords.map((a,i)=>{
   const x=Math.sqrt(3)*62*(a.q+a.r/2);const y=93*a.r;
   const type=tiles[i];const corners=[];
   for(let k=0;k<6;k++){
     const theta=(-90+k*60)*Math.PI/180;const vx=x+62*Math.cos(theta),vy=y+62*Math.sin(theta);const key=`${Math.round(vx*100)},${Math.round(vy*100)}`;
     let vi=vByKey.get(key);if(vi===undefined){vi=vertices.length;vByKey.set(key,vi);vertices.push({id:vi,x:vx,y:vy,hexes:[],edges:[],owner:null,building:null,port:null})}
     vertices[vi].hexes.push(i);corners.push(vi);
   }
   for(let k=0;k<6;k++){
     const va=corners[k],vb=corners[(k+1)%6],key=[va,vb].sort((a,b)=>a-b).join(':');
     let ei=eByKey.get(key);if(ei===undefined){ei=edges.length;eByKey.set(key,ei);edges.push({id:ei,a:va,b:vb,hexes:[],owner:null,kind:'road'});vertices[va].edges.push(ei);vertices[vb].edges.push(ei)}
     edges[ei].hexes.push(i);
   }
   return{id:i,...a,x,y,type,number:type==='desert'?null:numBag[ni++]};
 });
 const outer=edges.filter(e=>e.hexes.length===1).sort((a,b)=>{
   const ma={x:(vertices[a.a].x+vertices[a.b].x)/2,y:(vertices[a.a].y+vertices[a.b].y)/2};
   const mb={x:(vertices[b.a].x+vertices[b.b].x)/2,y:(vertices[b.a].y+vertices[b.b].y)/2};
   return Math.atan2(ma.y,ma.x)-Math.atan2(mb.y,mb.x);
 });
 const harborTypes=size===2?['all','wood','brick','all','wool','grain','all','ore','all']:['all','wood','all','brick','all','wool','all','grain','ore','all','all'];
 const used=new Set();let pick=[];
 for(let i=0;i<harborTypes.length;i++){
   const target=Math.floor((i+0.4)*outer.length/harborTypes.length);
   let edge=null;
   for(let off=0;off<outer.length;off++){
     const e=outer[(target+off)%outer.length];if(!used.has(e.a)&&!used.has(e.b)){edge=e;break}
   }
   if(edge){pick.push({edge,kind:harborTypes[i]});used.add(edge.a);used.add(edge.b)}
 }
 for(const {edge,kind} of pick){vertices[edge.a].port=kind;vertices[edge.b].port=kind}
 return {hexes,vertices,edges,robber:hexes.find(h=>h.type==='desert').id};
}
export function newGame(code,name,max=6,variant='classic'){
 const player={id:uid(),seatId:uid().slice(0,12),avatar:null,name:clampStr(name)||'Jugador 1',color:COLORS[0],hand:Object.fromEntries(RES.map(x=>[x,0])),dev:[],roads:[],settlements:[],cities:[],army:0};
 return {code,host:player.id,max:Math.max(2,Math.min(6,Number(max)||6)),created:Date.now(),players:[player],board:null,bank:null,deck:[],started:false,finished:false,turn:null,offer:null,largestArmy:null,longestRoad:null,log:[],event:0,version:1,variant:variant==='continents'?'continents':'classic'};
}
export function joinGame(g,name){if(g.started)throw Error('La partida ya empezó.');if(g.players.length>=g.max)throw Error('Sala completa.');
 const p={id:uid(),seatId:uid().slice(0,12),avatar:null,name:clampStr(name)||`Jugador ${g.players.length+1}`,color:COLORS[g.players.length],hand:Object.fromEntries(RES.map(x=>[x,0])),dev:[],roads:[],settlements:[],cities:[],army:0};
 g.players.push(p);log(g,`${p.name} entró a la sala.`);return p;
}
export function startGame(g,pid){if(pid!==g.host)throw Error('Solo el anfitrión puede empezar.');if(g.started)throw Error('La partida ya empezó.');if(g.players.length<2)throw Error('Necesitas al menos 2 jugadores.');
 g.board=buildBoard(g.players.length>=5||g.variant==='continents'?3:2);g.bank=Object.fromEntries(RES.map(x=>[x,g.players.length>=5||g.variant==='continents'?29:19]));
 let deck=['knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','vp','vp','vp','vp','vp','roads','roads','plenty','plenty','monopoly','monopoly'];
 if(g.players.length>=5) deck.push('knight','knight','knight','knight','knight','knight','vp','roads','plenty','monopoly');
 g.deck=shuffle(deck);g.started=true;g.turn={phase:'setup',index:0,setupStep:0,setupMode:'settlement',lastVertex:null,rolled:null,secondary:false,turnNumber:0,devPlayed:false,freeRoads:0,pendingDiscard:{},robberFrom:null};
 log(g,`La partida comenzó con ${g.players.length} jugadores. Ronda de colocación inicial.`);
}
function setupPlayerIndex(g){const n=g.players.length,i=g.turn.setupStep;return i<n?i:2*n-1-i}
function currentIndex(g){return g.turn.phase==='setup'?setupPlayerIndex(g):g.turn.secondary?(g.turn.index+3)%g.players.length:g.turn.index}
function current(g){return g.players[currentIndex(g)]}
function distanceClear(g,v){if(v.owner!==null)return false;return !v.edges.some(ei=>{const e=g.board.edges[ei];return g.board.vertices[e.a===v.id?e.b:e.a].owner!==null})}
function legalSettlement(g,p,v){if(!distanceClear(g,v))return false;
 if(g.turn.phase==='setup')return g.turn.setupMode==='settlement';
 return v.edges.some(ei=>g.board.edges[ei].owner===p.id);
}
function legalRoad(g,p,e){if(e.owner!==null)return false;
 if(g.turn.phase==='setup')return g.turn.setupMode==='road'&&(e.a===g.turn.lastVertex||e.b===g.turn.lastVertex);
 return [e.a,e.b].some(id=>{const v=g.board.vertices[id];if(v.owner===p.id)return true;if(v.owner&&v.owner!==p.id)return false;return v.edges.some(ei=>g.board.edges[ei].owner===p.id)});
}
function legalCity(g,p,v){return v.owner===p.id&&v.building==='settlement'}
function countKind(g,p,kind){return kind==='road'?p.roads.length:kind==='settlement'?p.settlements.length:p.cities.length}
function canPlace(g,p,kind){const limit=kind==='road'?15:kind==='settlement'?5:4;return countKind(g,p,kind)<limit}
function available(g,p,kind){
 if(!canPlace(g,p,kind))return [];
 if(kind==='road')return g.board.edges.filter(e=>legalRoad(g,p,e)).map(e=>e.id);
 if(kind==='settlement')return g.board.vertices.filter(v=>legalSettlement(g,p,v)).map(v=>v.id);
 if(kind==='city')return g.board.vertices.filter(v=>legalCity(g,p,v)).map(v=>v.id);
 return [];
}
function phaseIsAction(g,p){return g.turn.phase==='main'&&current(g).id===p.id}
function countScore(g,p,hidden=false){let score=p.settlements.length+2*p.cities.length;
 if(g.longestRoad===p.id)score+=2;if(g.largestArmy===p.id)score+=2;
 if(hidden)score+=p.dev.filter(d=>d.type==='vp').length;
 return score;
}
function longestPath(g,p){
 const own=new Set(p.roads);let best=0;
 function walk(v,visited){const vert=g.board.vertices[v];if(visited.size>0&&vert.owner&&vert.owner!==p.id)return 0;
  let max=0;for(const ei of vert.edges){if(!own.has(ei)||visited.has(ei))continue;
   const edge=g.board.edges[ei];visited.add(ei);const length=1+walk(edge.a===v?edge.b:edge.a,visited);visited.delete(ei);max=Math.max(max,length)
  }return max;
 }
 for(const ei of own){const e=g.board.edges[ei];best=Math.max(best,walk(e.a,new Set()),walk(e.b,new Set()))}return best;
}
function recompute(g){
 // Keep the current holder on ties; a challenger must beat the current length.
 const roads=g.players.map(p=>({id:p.id,n:longestPath(g,p)})).sort((a,b)=>b.n-a.n);
 if(g.longestRoad){const holder=roads.find(p=>p.id===g.longestRoad);if(!holder||holder.n<5||roads[0].n>holder.n)g.longestRoad=null}
 if(!g.longestRoad&&roads[0]?.n>=5&&roads[0].n>roads[1]?.n)g.longestRoad=roads[0].id;
 const armies=[...g.players].sort((a,b)=>b.army-a.army);
 if(g.largestArmy){const holder=g.players.find(p=>p.id===g.largestArmy);if(holder.army<3||armies[0].army>holder.army)g.largestArmy=null}
 if(!g.largestArmy&&armies[0].army>=3&&armies[0].army>(armies[1]?.army??0))g.largestArmy=armies[0].id;
 const c=current(g);
 if(g.turn.phase==='main'&&countScore(g,c,true)>=(g.variant==='continents'?12:10)){g.finished=true;g.turn.phase='finished';g.winner=c.id;log(g,`¡${c.name} ganó la partida con ${countScore(g,c,true)} puntos!`)}
}
function takeResources(g,p,vid){const v=g.board.vertices[vid];for(const hi of v.hexes){const key=HEX_TO_RES[g.board.hexes[hi].type];if(key&&g.bank[key]>0){g.bank[key]--;p.hand[key]++}}}
function addRoad(g,p,ei,free=false){const e=g.board.edges[ei];if(!e||!legalRoad(g,p,e))throw Error('Esta carretera no está permitida.');
 if(!canPlace(g,p,'road'))throw Error('Alcanzaste el límite de carreteras.');if(!free)pay(g,p,COSTS.road);
 e.owner=p.id;p.roads.push(ei);log(g,`${p.name} construyó una carretera.`);
}
function addSettlement(g,p,vi,free=false){const v=g.board.vertices[vi];if(!v||!legalSettlement(g,p,v))throw Error('Aquí no puedes fundar un poblado.');
 if(!canPlace(g,p,'settlement'))throw Error('Alcanzaste el límite de poblados.');if(!free)pay(g,p,COSTS.settlement);
 v.owner=p.id;v.building='settlement';p.settlements.push(vi);log(g,`${p.name} fundó un poblado.`);
}
function addCity(g,p,vi){const v=g.board.vertices[vi];if(!v||!legalCity(g,p,v))throw Error('La ciudad debe mejorar un poblado propio.');
 if(!canPlace(g,p,'city'))throw Error('Alcanzaste el límite de ciudades.');pay(g,p,COSTS.city);
 v.building='city';p.settlements=p.settlements.filter(i=>i!==vi);p.cities.push(vi);log(g,`${p.name} mejoró un poblado a ciudad.`)
}
function afterSetupRoad(g,p){g.turn.setupStep++;g.turn.lastVertex=null;g.turn.setupMode='settlement';
 if(g.turn.setupStep===g.players.length*2){g.turn.phase='roll';g.turn.index=0;g.turn.turnNumber=1;log(g,`Comienza el juego. Es el turno de ${g.players[0].name}.`)}
}
function resourceRoll(g,n){const demands={};for(const k of RES)demands[k]=[];
 for(const h of g.board.hexes){if(h.number!==n||g.board.robber===h.id)continue;const k=HEX_TO_RES[h.type];if(!k)continue;
  for(const vi of g.board.vertices.filter(v=>v.hexes.includes(h.id))){if(vi.owner)demands[k].push({p:g.players.find(x=>x.id===vi.owner),qty:vi.building==='city'?2:1})}
 }
 const yields=[];
 for(const k of RES){const needed=demands[k].reduce((a,x)=>a+x.qty,0);if(needed>g.bank[k]){if(needed)log(g,`No alcanzan las cartas de ${RES_ES[k]} en la banca.`);continue}
  for(const {p,qty} of demands[k]){p.hand[k]+=qty;g.bank[k]-=qty;yields.push(`${p.name} +${qty} ${RES_ES[k]}`)}
 }if(yields.length)log(g,yields.join(' · '));else log(g,'No se produjeron recursos.');
}
function stealCard(g,thief,victim){
 const cards=RES.flatMap(k=>Array.from({length:victim.hand[k]},()=>k));
 if(!cards.length)throw Error('Ese jugador ya no tiene recursos.');
 const key=cards[rand(cards.length)];victim.hand[key]--;thief.hand[key]++;
 log(g,`${thief.name} robó una carta a ${victim.name}.`);
 g.turn.phase='main';g.turn.stealVictims=[];g.turn.robberFrom=null;recompute(g);
}
function moveRobber(g,p,hexId){const h=g.board.hexes[hexId];if(!h||hexId===g.board.robber)throw Error('Debes mover el ladrón a otra casilla.');
 g.board.robber=hexId;
 const victims=[...new Set(g.board.vertices.filter(v=>v.hexes.includes(hexId)&&v.owner&&v.owner!==p.id).map(v=>v.owner))].map(id=>g.players.find(z=>z.id===id)).filter(x=>cardCount(x)>0);
 log(g,`${p.name} movió el ladrón.`);
 // Every robbery requires the active player's explicit choice of an eligible rival.
 // The choice is also visible when just one rival has a resource, to avoid silent steals.
 g.turn.stealVictims=victims.map(v=>v.id);
 if(victims.length){g.turn.phase='steal';return}
 g.turn.phase='main';g.turn.robberFrom=null;recompute(g);
}
function portRate(g,p,k){const ports=[...p.settlements,...p.cities].map(vi=>g.board.vertices[vi].port).filter(Boolean);
 return ports.includes(k)?2:ports.includes('all')?3:4;
}
function validateCounts(c){const x={};for(const k of RES){const v=Number(c?.[k]||0);if(!Number.isInteger(v)||v<0||v>30)throw Error('Cantidad inválida.');x[k]=v}return x}
function nextTurn(g){g.offer=null;g.turn.index=(g.turn.index+1)%g.players.length;g.turn.secondary=false;g.turn.phase='roll';g.turn.rolled=null;g.turn.devPlayed=false;g.turn.freeRoads=0;g.turn.turnNumber++;log(g,`Turno de ${current(g).name}.`)}
export function applyAction(g,pid,a){
 const p=g.players.find(x=>x.id===pid);if(!p)throw Error('No perteneces a esta sala.');if(!g.started)throw Error('La partida no comenzó.');if(g.finished)throw Error('La partida terminó.');
 const t=g.turn;const op=String(a?.type||'');const active=current(g);const meActive=active.id===pid;
 if(op==='chat'){const message=clampStr(a.text,180);if(!message)throw Error('Escribe un mensaje.');log(g,`💬 ${p.name}: ${message}`);return}
 if(op==='discard'){
  if(t.phase!=='discard'||!t.pendingDiscard[pid])throw Error('No tienes cartas pendientes de descartar.');
  const hand=validateCounts(a.cards);const count=t.pendingDiscard[pid];if(sum(hand)!==count||!has(p,hand))throw Error(`Debes descartar exactamente ${count} cartas.`);
  pay(g,p,hand);delete t.pendingDiscard[pid];log(g,`${p.name} descartó ${count} cartas.`);
  if(!Object.keys(t.pendingDiscard).length){t.phase='robber';log(g,'El jugador activo debe mover el ladrón.')}return;
 }
 if(op==='respondTrade'){
   const offer=g.offer;if(!offer||offer.to!==pid)throw Error('No hay un intercambio dirigido a ti.');
   if(a.accept){const src=g.players.find(q=>q.id===offer.from);const dst=p;
    if(!has(src,offer.give)||!has(dst,offer.want))throw Error('Alguno de los jugadores ya no tiene suficientes recursos.');
    for(const k of RES){src.hand[k]-=offer.give[k];dst.hand[k]+=offer.give[k];dst.hand[k]-=offer.want[k];src.hand[k]+=offer.want[k]}
    log(g,`${src.name} y ${dst.name} completaron un intercambio.`);
   }else log(g,`${p.name} rechazó el intercambio.`);
   g.offer=null;return;
 }
 if(!meActive)throw Error('No es tu turno.');
 if(t.phase==='setup'){
   if(t.setupMode==='settlement'&&op==='placeSettlement'){const vi=Number(a.vertex);addSettlement(g,p,vi,true);t.lastVertex=vi;t.setupMode='road';if(t.setupStep>=g.players.length)takeResources(g,p,vi);return}
   if(t.setupMode==='road'&&op==='placeRoad'){addRoad(g,p,Number(a.edge),true);afterSetupRoad(g,p);return}
   throw Error(`Debes colocar ${t.setupMode==='road'?'una carretera':'un poblado'}.`);
 }
 if(op==='roll'&&t.phase==='roll'){
   const d1=1+rand(6),d2=1+rand(6);t.rolled=[d1,d2];log(g,`${p.name} lanzó ${d1} + ${d2} = ${d1+d2}.`);
   if(d1+d2===7){t.pendingDiscard={};for(const q of g.players)if(cardCount(q)>7)t.pendingDiscard[q.id]=Math.floor(cardCount(q)/2);
    t.phase=Object.keys(t.pendingDiscard).length?'discard':'robber';if(t.phase==='discard')log(g,'Los jugadores con más de 7 recursos deben descartar la mitad.');}
   else{resourceRoll(g,d1+d2);t.phase='main'}return;
 }
 if(op==='moveRobber'&&t.phase==='robber'){moveRobber(g,p,Number(a.hex));return}
 if(op==='steal'&&t.phase==='steal'){const target=g.players.find(x=>x.id===a.target);if(!target||!t.stealVictims.includes(target.id))throw Error('Selecciona un rival válido para robar.');
  // Never trust the client: victim must still touch the robber hex and own cards.
  if(!g.board.vertices.some(v=>v.hexes.includes(g.board.robber)&&v.owner===target.id)||!cardCount(target))throw Error('Ese rival no tiene cartas junto al ladrón.');
  stealCard(g,p,target);return}
 if(t.phase!=='main')throw Error('Esta acción no está permitida ahora.');
 if(op==='placeRoad'){const free=t.freeRoads>0;addRoad(g,p,Number(a.edge),free);if(free)t.freeRoads--;recompute(g);return}
 if(op==='placeSettlement'){addSettlement(g,p,Number(a.vertex));recompute(g);return}
 if(op==='placeCity'){addCity(g,p,Number(a.vertex));recompute(g);return}
 if(op==='buyDev'){if(!g.deck.length)throw Error('Ya no quedan cartas de desarrollo.');pay(g,p,COSTS.development);const c=g.deck.pop();p.dev.push({id:uid(),type:c,boughtTurn:t.turnNumber});log(g,`${p.name} compró una carta de desarrollo.`);recompute(g);return}
 if(op==='playDev'){
   if(t.devPlayed)throw Error('Solo puedes jugar una carta de desarrollo por fase.');const card=p.dev.find(x=>x.id===a.card);if(!card||card.boughtTurn===t.turnNumber||card.type==='vp')throw Error('Esta carta no se puede jugar ahora.');
   const type=card.type;const allowed=['knight','roads','plenty','monopoly'];if(!allowed.includes(type))throw Error('Carta desconocida.');
   if(type==='plenty'){
     const cards=validateCounts(a.cards);if(sum(cards)!==2)throw Error('Selecciona exactamente dos recursos.');for(const k of RES)if(g.bank[k]<cards[k])throw Error(`La banca no tiene suficientes cartas de ${RES_ES[k]}.`);
     for(const k of RES){g.bank[k]-=cards[k];p.hand[k]+=cards[k]}
   }
   if(type==='monopoly'){
     const k=a.resource;if(!RES.includes(k))throw Error('Recurso inválido.');let count=0;
     for(const other of g.players){if(other.id===pid)continue;count+=other.hand[k];p.hand[k]+=other.hand[k];other.hand[k]=0}
     log(g,`${p.name} monopolizó ${RES_ES[k]} y obtuvo ${count} cartas.`);
   }
   if(type==='roads')t.freeRoads+=2;
   if(type==='knight'){p.army++;t.robberFrom='knight';t.phase='robber';}
   p.dev=p.dev.filter(x=>x.id!==card.id);t.devPlayed=true;log(g,`${p.name} jugó ${type==='knight'?'un caballero':type==='roads'?'Construcción de caminos':type==='plenty'?'Año de abundancia':'Monopolio'}.`);recompute(g);return;
 }
 if(op==='bankTrade'){
   const give=a.give,want=a.want;if(!RES.includes(give)||!RES.includes(want)||give===want)throw Error('Selecciona recursos distintos.');
   const rate=portRate(g,p,give);if(p.hand[give]<rate)throw Error(`Necesitas ${rate} cartas de ${RES_ES[give]}.`);if(g.bank[want]<1)throw Error('La banca no tiene ese recurso.');
   p.hand[give]-=rate;g.bank[give]+=rate;g.bank[want]--;p.hand[want]++;log(g,`${p.name} intercambió ${rate} ${RES_ES[give]} por 1 ${RES_ES[want]}.`);return;
 }
 if(op==='offerTrade'){
   if(t.secondary)throw Error('El segundo jugador del turno solo puede comerciar con la banca.');if(g.offer)throw Error('Ya existe una propuesta sin responder.');
   const to=g.players.find(q=>q.id===a.to);if(!to||to.id===pid)throw Error('Selecciona a otro jugador.');
   const give=validateCounts(a.give),want=validateCounts(a.want);
   if(sum(give)<1||sum(want)<1||!has(p,give))throw Error('La oferta debe intercambiar al menos una carta por otra, y debes tener lo que ofreces.');
   g.offer={from:pid,to:to.id,give,want};log(g,`${p.name} ofreció un intercambio a ${to.name}.`);return;
 }
 if(op==='cancelTrade'){if(g.offer?.from!==pid)throw Error('No puedes cancelar esta oferta.');g.offer=null;return}
 if(op==='endTurn'){
   if(t.freeRoads>0)t.freeRoads=0;
   if(g.players.length>=5&&!t.secondary){t.secondary=true;t.devPlayed=false;g.offer=null;log(g,`Turno de apoyo de ${current(g).name}: puede construir, comerciar con la banca y jugar una carta.`)}
   else nextTurn(g);return;
 }
 throw Error('Acción no reconocida.');
}
const friendlyDev={knight:'Caballero',vp:'Punto de victoria',roads:'Construcción de caminos',plenty:'Año de abundancia',monopoly:'Monopolio'};
function describeCost(p,kind){const c=COSTS[kind];return {price:c,affordable:has(p,c),missing:Object.fromEntries(RES.filter(k=>(p.hand[k]||0)<(c[k]||0)).map(k=>[k,c[k]-p.hand[k]]))}}
function rollWeight(n){return 6-Math.abs(7-n)}
export function snapshot(g,pid){
 const p=g.players.find(x=>x.id===pid);const t=g.turn;const index=g.started?currentIndex(g):null;const meTurn=g.started&&!g.finished&&current(g)?.id===pid;
 const actions={};const hints=[];
 if(g.started&&p){
   for(const kind of ['road','settlement','city','development']){
     const info=describeCost(p,kind);const positions=kind==='development'?[]:available(g,p,kind);
     const piece=kind==='development'?g.deck.length>0:canPlace(g,p,kind);
     actions[kind]={...info,positions,piece,enabled:meTurn&&t.phase==='main'&&piece&&(kind==='development'||positions.length>0)&&(info.affordable||kind==='road'&&t.freeRoads>0)};
   }
   if(t.phase==='setup'&&meTurn){actions.settlement.enabled=t.setupMode==='settlement';actions.road.enabled=t.setupMode==='road';}
   // The client must be given legitimate target hexes; otherwise pointer picks are
   // rejected before they can reach applyAction('moveRobber').
   actions.robber={enabled:meTurn&&t.phase==='robber',positions:meTurn&&t.phase==='robber'?g.board.hexes.filter(h=>h.id!==g.board.robber).map(h=>h.id):[]};
   if(t.phase==='main'&&meTurn){
     for(const kind of ['settlement','city','road','development']){
       const a=actions[kind],label={settlement:'poblado',city:'ciudad',road:'carretera',development:'carta de desarrollo'}[kind];
       if(a.enabled){hints.push(`Puedes ${kind==='development'?'comprar':'construir'} ${kind==='development'?'una':kind==='city'?'una':kind==='road'?'una':'un'} ${label}.`)}
       else if(a.piece&&(kind==='development'||a.positions.length>0)&&Object.keys(a.missing).length){hints.push(`Para ${label} te falta ${Object.entries(a.missing).map(([k,v])=>`${v} ${RES_ES[k]}`).join(', ')}.`)}
     }
     const best=available(g,p,'settlement').map(vi=>{const v=g.board.vertices[vi];return{vi,score:v.hexes.reduce((x,hi)=>x+(g.board.hexes[hi].number?rollWeight(g.board.hexes[hi].number):0),0)}}).sort((a,b)=>b.score-a.score)[0];
     if(best&&actions.settlement.enabled)hints.push(`Sugerencia: el poblado resaltado con ★ suma ${best.score} puntos de probabilidad de producción.`);
     actions.bestVertex=best?.vi??null;
   }else if(t.phase==='setup'&&meTurn)hints.push(t.setupMode==='settlement'?'Elige un cruce libre para fundar tu poblado inicial.':'Elige una arista conectada a tu poblado para colocar la carretera.');
   else if(t.phase==='roll'&&meTurn)hints.push('Lanza los dados para producir recursos.');
   else if(t.phase==='robber'&&meTurn)hints.push('Toca un hexágono distinto al actual para mover el ladrón.');
   else if(t.phase==='steal'&&meTurn)hints.push('Selecciona a qué jugador adyacente deseas robarle una carta.');
   else if(t.phase==='discard'&&t.pendingDiscard[pid])hints.push(`Debes descartar ${t.pendingDiscard[pid]} recursos para continuar.`);
   else if(!meTurn)hints.push('Observa las jugadas y prepara tu próxima estrategia.');
 }
 // The placement round is a blind draft: only the server knows the terrain,
 // probability tokens, robber and harbor resources until every player has built
 // both initial settlements and both roads. Never send secret tiles to clients.
 const setupHidden=!!(g.started&&t?.phase==='setup');
 const board=g.board?copy(g.board):null;
 if(board){
   board.concealed=setupHidden;
   if(setupHidden){
     for(const h of board.hexes){h.type='unknown';h.number=null;}
     for(const v of board.vertices)v.port=null;
     board.robber=null;
   }
for(const v of board.vertices){v.owner=v.owner?g.players.findIndex(p=>p.id===v.owner):null}for(const e of board.edges){e.owner=e.owner?g.players.findIndex(p=>p.id===e.owner):null}}
 return {code:g.code,variant:g.variant,winTarget:g.variant==='continents'?12:10,host:g.host===pid,max:g.max,started:g.started,finished:g.finished,winner:g.players.find(x=>x.id===g.winner)?.seatId||null,players:g.players.map((q,i)=>({id:q.seatId,name:q.name,color:q.color,avatar:q.avatar||null,connected:!!q.connected,resources:setupHidden?0:cardCount(q),devCount:q.dev.length,points:countScore(g,q,false),army:q.army,roadLength:g.started?longestPath(g,q):0,me:q.id===pid})),me:p?.seatId||null,
   mine:p?{hand:setupHidden?Object.fromEntries(RES.map(k=>[k,0])):{...p.hand},dev:p.dev.map(d=>({...d,name:friendlyDev[d.type]})),score:g.started?countScore(g,p,true):0,portRates:g.started?Object.fromEntries(RES.map(k=>[k,setupHidden?4:portRate(g,p,k)])):null}:null,
   board,turn:t?{phase:t.phase,index,primaryIndex:t.index,secondary:t.secondary,rolled:t.rolled,turnNumber:t.turnNumber,setupMode:t.setupMode,pendingDiscard:pid?t.pendingDiscard[pid]||0:0,discardWaiting:t.phase==='discard'?Object.keys(t.pendingDiscard).length:0,freeRoads:t.freeRoads,stealVictims:meTurn?(t.stealVictims||[]).map(id=>g.players.find(x=>x.id===id)?.seatId):[],devPlayed:t.devPlayed}:null,
   active:meTurn,actions,hints,offer:g.offer?{from:g.players.find(x=>x.id===g.offer.from)?.seatId,to:g.players.find(x=>x.id===g.offer.to)?.seatId,give:g.offer.give,want:g.offer.want}:null,largestArmy:g.players.find(x=>x.id===g.largestArmy)?.seatId||null,longestRoad:g.players.find(x=>x.id===g.longestRoad)?.seatId||null,log:g.log,deckCount:g.deck.length,bank:setupHidden?Object.fromEntries(RES.map(k=>[k,g.players.length>=5||g.variant==='continents'?29:19])):g.bank,version:g.version};
}
