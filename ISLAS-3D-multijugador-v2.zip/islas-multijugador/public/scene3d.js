/* ISLAS 4.0 · Terrenos geológicos volumétricos, materiales procedurales y cámara táctica orbital.
   WebGL 2 propio sin dependencias externas. Calidad visual y rendimiento adaptativos. */
const R=Math.PI/180;
const palette={unknown:[.35,.37,.35],forest:[.19,.34,.20],hill:[.52,.275,.17],pasture:[.38,.53,.28],field:[.63,.48,.20],mountain:[.40,.43,.43],desert:[.76,.65,.43]};
const MAT={plain:0,earth:1,wood:2,stone:3,fabric:4,metal:5,sand:6,grass:7,forest:8,clay:9,crops:10,granite:11,bark:12,leaves:13,water:14,brick:15,wool:16,gravel:17};
const MATERIAL_BY_TERRAIN={forest:MAT.forest,hill:MAT.clay,pasture:MAT.grass,field:MAT.crops,mountain:MAT.granite,desert:MAT.sand};
const hexToWorld=.0195;
function col(hex){if(!hex)return [.8,.7,.5];return [1,3,5].map(x=>parseInt(hex.slice(x,x+2),16)/255)}
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function sub(a,b){return a.map((v,i)=>v-b[i])}
function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}
function norm(a){const l=Math.hypot(...a)||1;return a.map(x=>x/l)}
function dot(a,b){return a.reduce((s,x,i)=>s+x*b[i],0)}
function lookAt(eye,target){const z=norm(sub(eye,target)),x=norm(cross([0,1,0],z)),y=cross(z,x);return [x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1]}
function perspective(fov,aspect,n,f){const t=1/Math.tan(fov/2);return [t/aspect,0,0,0,0,t,0,0,0,0,(f+n)/(n-f),-1,0,0,2*f*n/(n-f),0]}
function mult(a,b){let o=new Array(16).fill(0);for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let i=0;i<4;i++)o[c*4+r]+=a[i*4+r]*b[c*4+i];return o}
function proj(p,m,w,h){const x=p[0],y=p[1],z=p[2],q=m[3]*x+m[7]*y+m[11]*z+m[15];if(q<=0)return null;const nx=(m[0]*x+m[4]*y+m[8]*z+m[12])/q,ny=(m[1]*x+m[5]*y+m[9]*z+m[13])/q;if(Math.abs(nx)>1.4||Math.abs(ny)>1.4)return null;return [(nx*.5+.5)*w,(-ny*.5+.5)*h,q]}
class Geometry {
 constructor(){this.data=[];this.photos=[];this.labels=[];this.clickables=[]}
 tri(a,b,c,color,mat=0){const n=norm(cross(sub(b,a),sub(c,a)));for(const p of [a,b,c])this.data.push(...p,...n,...color,mat)}
 quad(a,b,c,d,color,mat=0){this.tri(a,b,c,color,mat);this.tri(a,c,d,color,mat)}
 box(x,y,z,w,h,d,color,mat=0,theta=0){const cc=Math.cos(theta),ss=Math.sin(theta),P=(a,b,c)=>[x+a*cc-c*ss,y+b,z+a*ss+c*cc],a=w/2,b=h/2,c=d/2;
  const p=[P(-a,-b,-c),P(a,-b,-c),P(a,b,-c),P(-a,b,-c),P(-a,-b,c),P(a,-b,c),P(a,b,c),P(-a,b,c)];
  for(const I of [[0,3,2,1],[4,5,6,7],[0,4,7,3],[1,2,6,5],[3,7,6,2],[0,1,5,4]])this.quad(...I.map(i=>p[i]),color,mat)}
 cyl(x,y,z,rx,rz,h,color,mat=0,sides=18){let top=[],bottom=[];for(let i=0;i<sides;i++){const a=2*Math.PI*i/sides;top.push([x+Math.cos(a)*rx,y+h,z+Math.sin(a)*rz]);bottom.push([x+Math.cos(a)*rx,y,z+Math.sin(a)*rz])}
  for(let i=0;i<sides;i++){const j=(i+1)%sides;this.quad(bottom[j],bottom[i],top[i],top[j],color,mat);this.tri([x,y+h,z],top[j],top[i],color,mat);this.tri([x,y,z],bottom[i],bottom[j],color,mat)}}
 cone(x,y,z,r,h,color,mat=0,sides=9){const apex=[x,y+h,z];for(let i=0;i<sides;i++){const a=i*2*Math.PI/sides,b=(i+1)*2*Math.PI/sides;this.tri([x+Math.cos(b)*r,y,z+Math.sin(b)*r],[x+Math.cos(a)*r,y,z+Math.sin(a)*r],apex,color,mat)}}
 sphere(x,y,z,r,color,mat=0){const rows=8,cols=12;for(let i=0;i<rows;i++)for(let j=0;j<cols;j++){
  const pt=(ri,cj)=>{const ph=ri*Math.PI/rows,th=cj*2*Math.PI/cols;return [x+Math.sin(ph)*Math.cos(th)*r,y+Math.cos(ph)*r,z+Math.sin(ph)*Math.sin(th)*r]};
  this.quad(pt(i,j),pt(i,j+1),pt(i+1,j+1),pt(i+1,j),color,mat)}}
 // Faceted irregular stone with several angled rock planes and varied highlights.
 rock(x,y,z,r,h,color,mat=MAT.granite,sides=7,seed=0){
  const bottom=[],ridge=[];
  for(let k=0;k<sides;k++){
   const a=2*Math.PI*k/sides,ir=0.75+0.23*Math.sin(seed*3.47+k*2.1),r2=.48+.19*Math.cos(seed+k*5.11);
   bottom.push([x+Math.cos(a)*r*ir,y,z+Math.sin(a)*r*ir]);
   ridge.push([x+Math.cos(a+.14)*r*r2,y+h*(.67+.17*Math.sin(k*5.3+seed)),z+Math.sin(a+.14)*r*r2]);
  }
  const peak=[x+Math.sin(seed)*r*.10,y+h,z+Math.cos(seed*1.7)*r*.11];
  for(let k=0;k<sides;k++){
   const j=(k+1)%sides,c=color.map(v=>clamp(v*(.84+.20*Math.sin(seed+k*8.37)),0,1));
   this.quad(bottom[k],bottom[j],ridge[j],ridge[k],c,mat);
   this.tri(ridge[k],ridge[j],peak,color.map(v=>v*(.87+.11*Math.cos(k*4.7))),mat);
  }
 }
 // Gentle topography is physically part of each tile, not a flat color texture.
 terrain(x,y,z,r,h,color,mat,seed){
  const corners=[];
  for(let k=0;k<6;k++){
   const a=(-90+k*60)*R;corners.push([x+r*Math.cos(a),y,z+r*Math.sin(a)]);
  }
  for(let k=0;k<6;k++){
   const a=corners[k],b=corners[(k+1)%6];
   this.quad([b[0],y-h,b[2]],[a[0],y-h,a[2]],a,b,color.map(v=>v*.63),mat);
  }
  const rings=4,segments=36;
  const perturb=(rad,a)=>{
   // Radial boundary of a true six-sided hexagon at the requested angle.
   const normal=Math.round(a/(Math.PI/3))*(Math.PI/3);
   const radialBoundary=r*Math.cos(Math.PI/6)/Math.cos(a-normal);
   const radius=rad/r*radialBoundary;
   const dune=(mat===MAT.sand?.055:mat===MAT.granite?.060:.035);
   const wave=Math.sin(a*3+seed*.17+rad*4.2)*.53+Math.cos(a*5.7-seed*.33+rad*7.3)*.27;
   return [x+Math.cos(a)*radius,y+rad*(1-rad/r)*dune*wave,z+Math.sin(a)*radius];
  };
  for(let n=0;n<rings;n++){
   const r0=n*r/rings,r1=(n+1)*r/rings;
   for(let k=0;k<segments;k++){
    const a0=(k-.5)*Math.PI*2/segments,a1=(k+.5)*Math.PI*2/segments;
    const c=color.map(v=>clamp(v*(.965+.028*Math.sin(seed+k*1.87+n*2.23)),0,1));
    this.quad(perturb(r0,a0),perturb(r0,a1),perturb(r1,a1),perturb(r1,a0),c,mat);
   }
  }
 }
 beam(a,b,r,color,mat=0){let v=sub(b,a),l=Math.hypot(...v);if(!l)return;const t=norm(v),up=Math.abs(t[1])>.9?[1,0,0]:[0,1,0],u=norm(cross(t,up)),w=cross(t,u),n=7;
  for(let i=0;i<n;i++){const k=i*2*Math.PI/n,k2=(i+1)*2*Math.PI/n,pt=(o,ang)=>[o[0]+r*(Math.cos(ang)*u[0]+Math.sin(ang)*w[0]),o[1]+r*(Math.cos(ang)*u[1]+Math.sin(ang)*w[1]),o[2]+r*(Math.cos(ang)*u[2]+Math.sin(ang)*w[2])];this.quad(pt(a,k2),pt(b,k2),pt(b,k),pt(a,k),color,mat)}}
 hex(x,y,z,r,h,color,mat=0){let pts=[];for(let k=0;k<6;k++){const a=(-90+k*60)*R;pts.push([x+r*Math.cos(a),y,z+r*Math.sin(a)])}for(let i=0;i<6;i++){this.tri([x,y,z],pts[(i+1)%6],pts[i],color,mat);const a=pts[i],b=pts[(i+1)%6];this.quad([b[0],y-h,b[2]],[a[0],y-h,a[2]],a,b,color.map(c=>c*.77),mat)}}
}
const vertSrc=`#version 300 es
precision highp float;layout(location=0)in vec3 aP;layout(location=1)in vec3 aN;layout(location=2)in vec3 aC;layout(location=3)in float aM;uniform mat4 uVP;out vec3 vP;out vec3 vN;out vec3 vC;out float vM;void main(){vP=aP;vN=aN;vC=aC;vM=aM;gl_Position=uVP*vec4(aP,1.0);}`;
const fragSrc=`#version 300 es
precision highp float;in vec3 vP;in vec3 vN;in vec3 vC;in float vM;out vec4 outColor;uniform vec3 uEye;
float hash21(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
float valueNoise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash21(i),hash21(i+vec2(1,0)),f.x),mix(hash21(i+vec2(0,1)),hash21(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){return .56*valueNoise(p)+.29*valueNoise(p*2.09)+.15*valueNoise(p*4.17);}
float edgeDist(float p){return min(fract(p),1.-fract(p));}
void main(){
 vec3 n=normalize(vN),base=vC;
 float m=floor(vM+.5),rough=.86,ao=1.,spark=0.;
 vec2 p=vP.xz; float micro=hash21(floor(p*143.));
 if(m==6.){ // Real granular quartz sand and curving wind-formed dunes.
  float grain=fbm(p*16.);float ripple=sin((p.x+sin(p.y*2.8)*.26)*46.)*.5+.5;
  float sand=clamp(.82+.27*grain+.075*ripple+.10*(micro-.5),.60,1.3);
  base*=sand;base+=vec3(.04,.025,.007)*(micro*.55);rough=.98;
 }else if(m==7.){ // Pasture: rich uneven blades, small green shadows and dirt patches.
  float patchShade=fbm(p*8.7),blade=hash21(floor(p*61.));
  base*=.70+.42*patchShade+.13*blade;
  base=mix(base,vec3(.19,.25,.115),smoothstep(.55,.82,patchShade)*.15);rough=.95;
 }else if(m==8.){ // Forest duff: shadowy moss, fallen needles, and compact earth.
  float moss=fbm(p*9.2),needle=fbm(p*42.);
  base*=.57+.54*moss+.19*needle;
  base+=vec3(.04,.052,.0)*smoothstep(.62,.86,moss);ao=.92;rough=.99;
 }else if(m==9.){ // Clay strata and fissures, mineral inclusions.
  float crust=fbm(p*11.),crack=fbm(p*27.);
  base*=.66+.46*crust;
  base*=1.-.24*(1.-smoothstep(.015,.08,abs(crack-.49)));
  base+=vec3(.064,.023,.012)*hash21(floor(p*63.));rough=.92;
 }else if(m==10.){ // Golden wheat soil: tilled rows and coarse stubble.
  float furrow=sin(p.x*26.+sin(p.y*4.)*.9)*.5+.5;
  base*=.68+.26*furrow+.27*fbm(p*15.);
  base+=vec3(.03,.024,.0)*hash21(floor(p*95.));rough=.98;
 }else if(m==11.||m==3.||m==17.){ // Faceted granite and angular gravel.
  float grain=fbm(p*31.+vec2(vP.y*12.)),vein=sin(p.x*26.+p.y*17.+vP.y*11.);
  base*=.62+.57*grain+.07*vein+.12*(micro-.5);rough=.86;
 }else if(m==12.||m==2.){ // Bark and varnished wood grain.
  float rings=sin(vP.x*34.+sin(vP.z*11.+vP.y*3.)*3.)*.5+.5;
  base*=.73+.37*rings+.14*fbm(p*8.);rough=m==2.?.50:.91;
 }else if(m==13.){ // Dense foliage, individual needle clusters.
  float leaves=fbm(p*49.+vec2(vP.y*13.));base*=.62+.56*leaves+.17*micro;rough=.94;
 }else if(m==14.){ // Water: green-blue translucent-looking waves.
  float wave=sin(p.x*18.+sin(p.y*9.)*.8)*sin(p.y*26.);base*=.88+.12*wave;rough=.24;spark=.08*pow(max(dot(n,normalize(vec3(-.45,.8,.4))),0.),7.);
 }else if(m==15.){ // Terracotta brick ceramic pores and mortar lines.
  float mortar=step(edgeDist(p.x*5.2+floor(p.y*6.)*.5),.055)+step(edgeDist(p.y*6.),.055);
  base*=mortar>0.?.43:(.80+.23*fbm(p*29.));rough=.94;
 }else if(m==16.){ // Wool, soft clumped fleece.
  base*=.77+.32*fbm(p*22.);rough=1.;
 }else if(m>=1.){
  base*=.80+.27*fbm(p*19.)+.05*micro;
  if(m==4.)rough=.97;
 }
 vec3 L=normalize(vec3(-.48,.91,.38)),F=normalize(vec3(.64,.58,-.51));
 float diffuse=max(dot(n,L),0.),fill=max(dot(n,F),0.);
 float light=.37+.53*diffuse+.18*fill;
 vec3 view=normalize(uEye-vP);vec3 refl=reflect(-L,n);
 float spec=pow(max(dot(view,refl),0.),mix(12.,105.,1.-rough))*(.22*(1.-rough)+.014);
 vec3 c=base*(light*ao)+vec3(1.0,.85,.63)*spec+vec3(.7,.87,1.)*spark;
 float dist=length(uEye-vP),fog=1.-exp(-.00010*dist*dist);
 c=mix(c,vec3(.13,.13,.13),fog*.26);
 outColor=vec4(pow(max(c,vec3(0.)),vec3(.91)),1.);
}`;
const photoVert=`#version 300 es
layout(location=0)in vec3 aP;layout(location=1)in vec2 aUV;uniform mat4 uVP;out vec2 vUV;void main(){vUV=aUV;gl_Position=uVP*vec4(aP,1.);}`;
const photoFrag=`#version 300 es
precision mediump float;uniform sampler2D uImage;in vec2 vUV;out vec4 color;void main(){color=texture(uImage,vUV);}`;
function shader(gl,type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s}
function program(gl,vs,fs){const p=gl.createProgram();gl.attachShader(p,shader(gl,gl.VERTEX_SHADER,vs));gl.attachShader(p,shader(gl,gl.FRAGMENT_SHADER,fs));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p}
const demoTypes=['forest','hill','pasture','field','mountain','forest','pasture','field','hill','forest','desert','pasture','field','mountain','forest','field','pasture','hill','mountain'];
function preview(){const lengths=[3,4,5,4,3],hexes=[];for(let r=0;r<5;r++)for(let c=0;c<lengths[r];c++){hexes.push({id:hexes.length,x:(c-(lengths[r]-1)/2)*108+(r-2)*-9,y:(r-2)*93,type:demoTypes[hexes.length],number:[5,9,10,8,6,3,11,4,12,2,6,8,9,10,5,4,3,11,9][hexes.length]})}return hexes}
export class IslasScene {
 constructor(canvas,onPick){this.canvas=canvas;this.hud=canvas.parentElement.querySelector('.scene-hud');this.onPick=onPick;this.gl=canvas.getContext('webgl2',{antialias:true,alpha:false,preserveDrawingBuffer:false});if(!this.gl)throw Error('WebGL 2 no disponible.');this.g=new Geometry();this.angles={yaw:.46,dist:14.5,height:16.0};this.pan=[0,0,0];this.cameraInitialized=false;this.touchPointers=new Map();this.zoomScale=1;this.eye=[8,15,20];this.targetEye=[8,15,20];this.targetLook=[0,1,0];this.look=[0,1,0];this.first=false;this.manual=false;this.frame=0;this.raf=null;this.photos=new Map();this.images=new Map();this.labelMap=[];this.game=null;this.mode=null;this.hasMoved=false;this.lastRollKey='';this.diceAnimationAt=0;this.diceValues=null;this.lastFrame=0;this.quality=1;this.frameTimes=[];
  const gl=this.gl;this.prg=program(gl,vertSrc,fragSrc);this.photoPrg=program(gl,photoVert,photoFrag);this.uVP=gl.getUniformLocation(this.prg,'uVP');this.uEye=gl.getUniformLocation(this.prg,'uEye');this.imgVP=gl.getUniformLocation(this.photoPrg,'uVP');this.buffer=gl.createBuffer();this.diceBuffer=gl.createBuffer();this.imgBuffer=gl.createBuffer();gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.clearColor(.065,.060,.052,1);
  // Separate selection from camera gestures. A tap never rotates the camera.
  // While placing buildings/roads, one-finger gestures select only; two fingers can still navigate.
  const centerOf=()=>{const v=[...this.touchPointers.values()];return [(v[0].x+v[1].x)/2,(v[0].y+v[1].y)/2]};
  const distanceOf=()=>{const v=[...this.touchPointers.values()];return Math.hypot(v[0].x-v[1].x,v[0].y-v[1].y)};
  const down=e=>{
   this.touchPointers.set(e.pointerId,{x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,kind:e.pointerType});
   if(this.touchPointers.size===1){this.hasMoved=false;this.dragging=false;this.lastDown={x:e.clientX,y:e.clientY};}
   if(this.touchPointers.size===2){this.pinch={center:centerOf(),distance:distanceOf()};this.hasMoved=true;}
   canvas.setPointerCapture?.(e.pointerId);
  };
  const move=e=>{
   if(!this.touchPointers.has(e.pointerId))return;
   const previous=this.touchPointers.get(e.pointerId);
   this.touchPointers.set(e.pointerId,{...previous,x:e.clientX,y:e.clientY});
   if(this.touchPointers.size>=2){
    const center=centerOf(),distance=Math.max(10,distanceOf());
    if(this.pinch){const ratio=clamp(this.pinch.distance/distance,.73,1.38);this.zoom(ratio);
     const dx=center[0]-this.pinch.center[0],dy=center[1]-this.pinch.center[1];
     const k=this.angles.dist*.002;
     this.pan[0]+=(-dx*Math.cos(this.angles.yaw)+dy*Math.sin(this.angles.yaw))*k;
     this.pan[2]+=(dx*Math.sin(this.angles.yaw)+dy*Math.cos(this.angles.yaw))*k;
    }
    this.pinch={center,distance};this.hasMoved=true;this.manual=true;return;
   }
   const dx=e.clientX-previous.x,dy=e.clientY-previous.y;
   const movement=Math.hypot(e.clientX-previous.startX,e.clientY-previous.startY);
   const isTouch=previous.kind==='touch';
   const threshold=isTouch?16:9;
   // A finger on a target must not orbit the board instead of building.
   if(movement>threshold){this.hasMoved=true;this.dragging=true;}
   if(!this.dragging||this.placementActive())return;
   this.angles.yaw-=dx*.0075;
   this.angles.height=clamp(this.angles.height+dy*.055,7,31);
   this.manual=true;
  };
  const up=e=>{
   const wasTracked=this.touchPointers.has(e.pointerId);
   this.touchPointers.delete(e.pointerId);
   this.pinch=null;
   if(this.touchPointers.size===0){
    const shouldPick=wasTracked&&!this.hasMoved&&e.type==='pointerup';
    this.dragging=false;this.lastDown=null;
    if(shouldPick)this.pick(e);
   }
  };
  canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);
  canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);
  canvas.addEventListener('wheel',e=>{e.preventDefault();this.zoom(Math.exp(e.deltaY*.0009));this.manual=true},{passive:false});
  this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(canvas);this.resize();this.animate();
 }
 placementActive(){const t=this.game?.turn;if(!this.game?.active||!t)return false;return t.phase==='setup'||t.phase==='robber'||(t.phase==='main'&&['road','settlement','city'].includes(this.mode))}
 resize(){if(!this.canvas?.isConnected)return;const dpr=Math.min((devicePixelRatio||1)*this.quality,innerWidth<700?1.35:1.7),w=Math.max(10,Math.floor(this.canvas.clientWidth*dpr)),h=Math.max(10,Math.floor(this.canvas.clientHeight*dpr));if(this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;this.hud.width=w;this.hud.height=h}this.width=w;this.height=h;this.gl.viewport(0,0,w,h)}
 update(game,mode){this.game=game;this.mode=mode;
  const board=game.board,players=game.players;
  const stateKey=[game.started,game.variant,board?.concealed,board?.robber,game.turn?.index,
    players.map(p=>[p.id,p.name,p.color,p.connected,p.avatar?.length,p.avatar?.slice(-20)].join(':')).join('|'),
    board?.edges?.map(e=>e.owner==null?'_':e.owner).join(''),
    board?.vertices?.map(v=>v.owner==null?'_':String(v.owner)+(v.building==='city'?'C':'S')).join(',')].join('|');
  if(this.stateKey!==stateKey){this.stateKey=stateKey;this.rebuild()}
  const active=!!game.active&&!game.finished;
  if(active!==this.lastActive){this.lastActive=active;this.override=false;if(active)this.setFirstPerson();else this.setOverview()}
 }
 rollDice(values){this.diceValues=Array.isArray(values)?values.slice(0,2):null;this.diceAnimationAt=performance.now()}
 cameraAspect(){return this.canvas.clientWidth/Math.max(1,this.canvas.clientHeight)}
 fitView(seat=false){
  const aspect=this.cameraAspect(),portrait=aspect<.8;
  this.first=seat;this.manual=false;
  const tiles=this.game?.board?.hexes||preview();
  const centerX=tiles.reduce((s,h)=>s+h.x,0)/tiles.length*hexToWorld;
  const centerZ=tiles.reduce((s,h)=>s+h.y,0)/tiles.length*hexToWorld;
  this.pan=[centerX,0,centerZ];
  const radius=Math.max(...tiles.map(h=>Math.hypot(h.x*hexToWorld-centerX,h.y*hexToWorld-centerZ)))+1.12;
  const verticalFov=aspect<.8?69:aspect<1.28?60:52;
  const required=radius/(Math.tan(verticalFov*R/2)*Math.min(aspect,1)*.88);
  const depth=Math.max(portrait?20:13.2,required);
  const myIndex=this.game?.players?.findIndex(p=>p.me)??-1;
  this.angles.yaw=seat?Math.max(0,myIndex)*Math.PI/3:Math.PI*.20;
  this.angles.dist=clamp(depth*(portrait?.51:.55),5,32);
  this.angles.height=clamp(1.0+depth*(portrait?.86:.84),8,36);
  this.override=!seat;this.cameraInitialized=true;
 }
 setOverview(){this.fitView(false)}
 setFirstPerson(){this.fitView(true)}
 zoom(factor){this.angles.dist=clamp(this.angles.dist*factor,4.6,36);this.angles.height=clamp(this.angles.height*factor,6.9,36)}
 zoomIn(){this.zoom(.82);this.manual=true}
 zoomOut(){this.zoom(1.22);this.manual=true}
 fitBoard(){this.fitView(this.first)}
 drawRoom(g){const A=[.115,.11,.097],wall=[.23,.215,.195],gold=[.71,.49,.24];
  g.box(0,-.30,0,42,.5,42,[.22,.165,.105],2);g.box(0,25,0,42,.4,42,[.27,.24,.22],3);
  g.box(-20,6,0,.4,12,42,wall,3);g.box(20,6,0,.4,12,42,wall,3);g.box(0,6,-20,42,12,.5,wall,3);
  for(let i=-17;i<=17;i+=4){g.box(i,6,-19.64,.13,10.5,.12,[.43,.33,.21],2);g.box(i,6.2,-19.48,2.5,7.2,.07,[.09,.18,.20],0);g.box(i,2.7,-19.4,2.6,.10,.14,gold,0);g.box(i,9.7,-19.4,2.6,.10,.14,gold,0)}
  // Low-angle window light, picture frames and wall sconces.
  for(let i=-14;i<=14;i+=14){g.box(i,6.1,-19.31,4.7,3.1,.15,[.095,.095,.09],2);g.box(i,6.1,-19.21,4.1,2.5,.08,[.32,.29,.23],1);g.box(i,6.1,-19.12,3.5,1.9,.09,[.15,.24,.19],1);}
  for(let i=0;i<6;i++){const a=i*Math.PI/3;g.cyl(Math.sin(a)*14,.0,Math.cos(a)*14,.90,.90,.026,[.09,.065,.042],0,20)}
  // Large circular oak table, carved edge, brass lip and solid legs.
  g.cyl(0,.15,0,8.05,6.95,1.21,[.20,.105,.052],2,56);g.cyl(0,1.25,0,8.33,7.18,.20,[.46,.275,.145],2,56);
  g.cyl(0,1.40,0,8.23,7.09,.045,gold,0,56);g.cyl(0,1.445,0,8.06,6.92,.075,[.37,.215,.112],2,56);
  for(let i=0;i<4;i++){const a=(i+.5)*Math.PI/2;g.cyl(Math.sin(a)*4.6,-.02,Math.cos(a)*3.4,.40,.40,1.6,[.20,.115,.07],2,12)}
  // Hanging brass chandelier and warm bulbs.
  g.cyl(0,23.3,0,.09,.09,1.8,[.42,.31,.18],0,12);g.cyl(0,22.8,0,2.2,2.2,.25,[.55,.36,.17],0,24);g.cyl(0,22.53,0,2.0,2.0,.18,[.88,.73,.44],0,24);
  for(let i=0;i<8;i++){const a=i*Math.PI/4;g.sphere(Math.sin(a)*1.65,22.46,Math.cos(a)*1.65,.24,[.99,.77,.41],0)}
 }
 drawChair(g,a){const x=Math.sin(a)*9.15,z=Math.cos(a)*8.35;const t=a,wood=[.23,.13,.076],fabric=[.19,.18,.17];g.box(x,.79,z,1.25,.20,1.16,fabric,4,t);const bx=x+Math.sin(a)*.52,bz=z+Math.cos(a)*.52;g.box(bx,1.55,bz,1.32,1.55,.23,wood,2,t);g.box(bx,1.67,bz,1.04,1.18,.28,[.25,.25,.23],4,t);
  for(const u of [-.47,.47])for(const v of [-.43,.43]){const px=x+u*Math.cos(t)-v*Math.sin(t),pz=z+u*Math.sin(t)+v*Math.cos(t);g.box(px,.36,pz,.13,.72,.14,wood,2,t)}
  return [x,z]
 }
 drawAvatar(g,p,i,n){const a=i*2*Math.PI/n,x=Math.sin(a)*9.15,z=Math.cos(a)*8.35,rgb=col(p.color),shirt=rgb.map(v=>v*.48+.17),dark=[.105,.112,.132];const toward=[-Math.sin(a),0,-Math.cos(a)];
  // Volumetric seated body, arms, legs and head; the uploaded portrait is visible on the face plane.
  g.box(x,1.67,z,1.05,1.17,.67,shirt,4,a);
  for(const side of [-1,1]){const sx=x+side*Math.cos(a)*.60,sz=z+side*Math.sin(a)*.60;g.beam([sx,2.02,sz],[sx+toward[0]*.20,1.35,sz+toward[2]*.20],.18,shirt,4)}
  g.sphere(x,2.61,z,.43,[.71,.53,.40],4);g.sphere(x,2.92,z-.055,.38,[.23,.17,.14],4);
  for(const side of [-1,1]){const bx=x+side*Math.cos(a)*.29,bz=z+side*Math.sin(a)*.29;g.beam([bx,1.05,bz],[bx+toward[0]*.45,.41,bz+toward[2]*.45],.19,dark,4)}
  const face=[x+toward[0]*.390,2.60,z+toward[2]*.390];
  if(p.avatar){const right=[Math.cos(a),0,-Math.sin(a)],H=.57,W=.58;const pt=(xx,yy)=>[face[0]+right[0]*xx,face[1]+yy,face[2]+right[2]*xx];g.photos.push({id:p.id,src:p.avatar,p:[pt(-W/2,H/2),pt(W/2,H/2),pt(W/2,-H/2),pt(-W/2,-H/2)]})}
  else {g.sphere(x+toward[0]*.32,2.61,z+toward[2]*.32,.25,[.82,.63,.45],4)}
  this.g.labels.push({type:'player',p:[x,3.46,z],name:p.name,me:p.me,connected:p.connected,active:this.game?.turn?.index===i&&this.game.started});
  if(this.game?.started&&this.game.turn?.index===i){g.cyl(x,.012,z,1.13,1.00,.020,[.93,.68,.29],0,24)}
 }
 tileDecor(g,h,x,z){
  const seed=h.id*137+71;
  const rnd=(n)=>{const v=Math.sin(seed*31.713+n*91.733)*43758.5453;return v-Math.floor(v)};
  const base=palette[h.type]||[.4,.4,.4],y=1.81,material=h.type==='unknown'?MAT.plain:(MATERIAL_BY_TERRAIN[h.type]||MAT.earth);
  const medium=this.canvas.clientWidth<700;
  const count=(mobile,desktop)=>medium?mobile:desktop;
  const spot=(n,min=.38,max=.93)=>{
   const a=rnd(n*2)*Math.PI*2,r=min+(max-min)*Math.sqrt(rnd(n*2+1));
   return [x+Math.cos(a)*r,z+Math.sin(a)*r];
  };
  // Layered strata with a high-frequency procedural albedo and subtle displaced top.
  g.terrain(x,y,z,1.165,.27,base,material,seed);
  if(h.type==='forest'){
   for(let i=0;i<count(12,22);i++){
    const [tx,tz]=spot(i+13),r=.09+rnd(i+81)*.105,ht=.39+rnd(i+18)*.34;
    const shade=rnd(i+37),leaf=[.085+.06*shade,.24+.11*shade,.11+.065*shade];
    g.cyl(tx,y-.018,tz,r*.25,r*.25,ht*.55,[.25,.135,.07],MAT.bark,5);
    g.cone(tx,y+ht*.12,tz,r*1.7,ht*.61,leaf,MAT.leaves,7);
    g.cone(tx,y+ht*.37,tz,r*1.42,ht*.58,leaf.map(v=>v*1.1),MAT.leaves,7);
    if(i%4===0)g.cone(tx,y+ht*.67,tz,r,ht*.36,leaf.map(v=>v*.82),MAT.leaves,7);
   }
   for(let k=0;k<count(10,22);k++){
    const [fx,fz]=spot(k+123,.34,1.00);g.cone(fx,y-.009,fz,.065,.075,[.12,.21,.075],MAT.leaves,4);
   }
  }
  if(h.type==='hill'){
   // Terracotta deposits, a brick stack and scattered weathered baked-clay blocks.
   for(let k=0;k<count(9,17);k++){
    const [bx,bz]=spot(k+60),r=.17+rnd(k+88)*.14;
    g.rock(bx,y-.009,bz,r,.13+rnd(k+31)*.15,[.54+.15*rnd(k+40),.24+.075*rnd(k+3),.13],MAT.clay,6,k);
   }
   for(let k=0;k<count(19,34);k++){
    const [bx,bz]=spot(k+88,.43,.97),rotate=rnd(k+44)*Math.PI;
    g.box(bx,y+.045,bz,.12+.04*rnd(k),.085,.080,[.60+.10*rnd(k+39),.30+.05*rnd(k+32),.18],MAT.brick,rotate);
   }
   // Small red brick stack with uneven courses, placed away from number marker.
   for(let row=0;row<3;row++)for(let k=0;k<3;k++){
    g.box(x-.67+k*.16,y+.045+row*.084,z+.53+row*.022,.145,.081,.11,[.62-.055*row,.31,.19],MAT.brick,row%2?.2:0);
   }
  }
  if(h.type==='pasture'){
   for(let k=0;k<count(24,45);k++){
    const [gx,gz]=spot(k+4,.33,1.00);
    const height=.08+rnd(k+34)*.14;
    for(let t=0;t<3;t++)g.cone(gx+(t-1)*.033,y-.017,gz+.029*(t%2),.018,height*(.8+.2*rnd(k+t)),[.20+.08*rnd(k),.43+.18*rnd(k+2),.14],MAT.grass,3);
   }
   for(let k=0;k<2;k++){
    const [sx,sz]=spot(k+82,.48,.67);
    g.cyl(sx,y+.015,sz,.13,.085,.10,[.32,.27,.21],MAT.earth,7);
    g.sphere(sx,y+.20,sz,.14,[.85,.83,.70],MAT.wool);
    g.sphere(sx+.11,y+.20,sz-.06,.073,[.53,.46,.36],MAT.fabric);
    for(let t=-1;t<=1;t+=2)g.cyl(sx+t*.07,y+.02,sz+.035,.022,.022,.1,[.46,.39,.3],MAT.fabric,5);
   }
  }
  if(h.type==='field'){
   for(let row=-3;row<=3;row++){
    const zrow=z+row*.235;
    for(let k=0;k<count(7,11);k++){
     const wx=x-.84+k*(1.68/(count(7,11)-1))+.03*(rnd(row*22+k)-.5);
     if(Math.hypot(wx-x,zrow-z)<.36||Math.hypot(wx-x,zrow-z)>1.04)continue;
     const ht=.17+.12*rnd(k+row*16);
     g.beam([wx,y,zrow],[wx+.028,y+ht,zrow],.0085,[.45,.31,.11],MAT.crops);
     g.cone(wx+.018,y+ht*.66,zrow,.035,ht*.40,[.85+.10*rnd(k+row*4),.64+.10*rnd(k+80),.26],MAT.crops,4);
    }
   }
  }
  if(h.type==='mountain'){
   for(let k=0;k<count(9,15);k++){
    const [rx,rz]=spot(k+7,.31,.98),height=.24+rnd(k+44)*.36;
    const grey=.32+.17*rnd(k+16);
    g.rock(rx,y-.012,rz,.15+.17*rnd(k+9),height,[grey,grey*1.04,grey*1.08],MAT.granite,5+k%3,k+seed);
   }
   for(let k=0;k<3;k++){
    const [rx,rz]=spot(k+54,.41,.74);
    g.rock(rx,y-.012,rz,.28,.48+.29*rnd(k+10),[.42,.43,.43],MAT.granite,7,k+19);
    g.cone(rx,y+.37,rz,.12,.15,[.70,.70,.66],MAT.granite,5);
   }
  }
  if(h.type==='desert'){
   // Layered sweeping dune crests, small stones and fine quartz grains.
   for(let k=0;k<9;k++){
    const cx=x+(k-4)*.21,zz=z+.44+.16*Math.sin(k*.67+seed);
    const cr=[.86-.07*rnd(k+3),.73-.07*rnd(k+16),.48-.07*rnd(k+43)];
    g.rock(cx,y-.012,zz,.16,.052+Math.sin(k/9*Math.PI)*.15,cr,MAT.sand,6,k+66);
   }
   for(let k=0;k<count(12,24);k++){
    const [sx,sz]=spot(k+75,.38,1.00),rr=.015+.025*rnd(k+7);
    g.rock(sx,y-.018,sz,rr,rr*.6,[.65,.55,.39],MAT.gravel,5,k+11);
   }
  }
  // During blind setup, all tiles stay neutral: no structures, color or number hints.
  if(h.type==='unknown')return;
  // Physically layered ivory/bronze number plate; keep it visible among terrain details.
  g.cyl(x,y+.042,z,.30,.30,.040,[.26,.20,.13],MAT.metal,24);
  g.cyl(x,y+.075,z,.273,.273,.086,[.89,.79,.57],MAT.plain,24);
  this.g.labels.push({type:'number',p:[x,y+.174,z],text:String(h.number||''),robber:this.game.board?.robber===h.id});
  if(this.game.board?.robber===h.id){g.cyl(x+.41,y+.07,z+.26,.104,.104,.36,[.15,.14,.14],MAT.metal,12);g.sphere(x+.41,y+.46,z+.26,.13,[.12,.12,.11],MAT.fabric)}
 }
 drawBoard(g){const game=this.game,b=game.board,hs=b?b.hexes:preview();const offsetY=1.82;g.cyl(0,1.54,0,6.5,5.4,.075,[.064,.18,.19],MAT.water,44);g.cyl(0,1.61,0,6.19,5.13,.045,[.092,.25,.25],MAT.water,44);
  for(const h of hs){const x=h.x*hexToWorld,z=h.y*hexToWorld;this.tileDecor(g,h,x,z)}
  if(!b)return;
  for(const e of b.edges)if(e.owner!==null){const a=b.vertices[e.a],v=b.vertices[e.b],color=col(game.players[e.owner]?.color);g.beam([a.x*hexToWorld,2.07,a.y*hexToWorld],[v.x*hexToWorld,2.07,v.y*hexToWorld],.073,color,4)}
  for(const v of b.vertices)if(v.owner!==null){const x=v.x*hexToWorld,z=v.y*hexToWorld,c=col(game.players[v.owner]?.color),isCity=v.building==='city';g.box(x,2.11,z,isCity?.30:.23,isCity?.40:.27,isCity?.28:.23,c,4);g.cone(x,2.11+(isCity?.20:.12),z,isCity?.27:.22,isCity?.27:.20,[.85,.76,.58],2,4)}
 }
 rebuild(){const g=new Geometry();this.g=g;this.drawRoom(g);this.drawBoard(g);for(let i=0;i<6;i++)this.drawChair(g,i*Math.PI/3);this.game.players.forEach((p,i)=>this.drawAvatar(g,p,i,Math.max(this.game.max,6)));
  const gl=this.gl;this.count=g.data.length/10;gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(g.data),gl.STATIC_DRAW);
  const old=this.images;this.images=new Map();for(const photo of g.photos){if(old.has(photo.src)){this.images.set(photo.src,old.get(photo.src));old.delete(photo.src)}else {const img=new Image();img.onload=()=>{const texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,1);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);gl.generateMipmap(gl.TEXTURE_2D);this.images.set(photo.src,texture)};img.src=photo.src}}
  for(const tex of old.values())gl.deleteTexture(tex);
 }
 currentEye(){
  const yaw=this.angles.yaw;
  const center=[this.pan[0],1.02+this.pan[1],this.pan[2]];
  return {target:[center[0]+Math.sin(yaw)*this.angles.dist,this.angles.height+this.pan[1],center[2]+Math.cos(yaw)*this.angles.dist],look:center};
 }
 render(time){
  if(!this.canvas?.isConnected)return;
  this.resize();const {target,look}=this.currentEye();
  for(let i=0;i<3;i++){this.eye[i]+=(target[i]-this.eye[i])*.13;this.look[i]+=(look[i]-this.look[i])*.13}
  const gl=this.gl,aspect=this.width/this.height;
  const fov=(aspect<.8?69:aspect<1.28?60:52)*R;
  this.vp=mult(perspective(fov,aspect,.2,120),lookAt(this.eye,this.look));
  gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(this.prg);gl.uniformMatrix4fv(this.uVP,false,new Float32Array(this.vp));gl.uniform3fv(this.uEye,new Float32Array(this.eye));gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);gl.enableVertexAttribArray(0);gl.enableVertexAttribArray(1);gl.enableVertexAttribArray(2);gl.enableVertexAttribArray(3);gl.vertexAttribPointer(0,3,gl.FLOAT,false,40,0);gl.vertexAttribPointer(1,3,gl.FLOAT,false,40,12);gl.vertexAttribPointer(2,3,gl.FLOAT,false,40,24);gl.vertexAttribPointer(3,1,gl.FLOAT,false,40,36);gl.drawArrays(gl.TRIANGLES,0,this.count||0);
  this.renderDice(time);this.renderPhotos();this.renderHud(); }
 renderDice(time){
  if(!this.diceValues?.length)return;
  const elapsed=Math.max(0,(time-this.diceAnimationAt)/1000),throwing=elapsed<1.35;
  const g=new Geometry();const centers=[-0.53,0.53],z=5.85;
  for(let i=0;i<2;i++){
    const settle=Math.min(1,elapsed/1.35),scatter=throwing?(1-settle)*(.72+Math.sin(time*.021+i)*.20):0;
    const x=centers[i]+scatter*(i?1:-1),pz=z+(throwing?Math.sin(elapsed*7+i)*.33*(1-settle):0);
    const bounce=throwing?Math.abs(Math.sin(elapsed*15+i*.9))*.63*(1-settle):0;
    g.cyl(x,1.53,pz,.29,.29,.012,[.07,.07,.06],0,18);
    const theta=throwing?elapsed*14+i*3:0;
    const y=1.53+.27+bounce,face=[.94,.91,.82],pip=[.13,.16,.17];
    g.box(x,y,pz,.47,.47,.47,face,0,theta);
    const dots={1:[[0,0]],2:[[-1,-1],[1,1]],3:[[-1,-1],[0,0],[1,1]],4:[[-1,-1],[1,-1],[-1,1],[1,1]],5:[[-1,-1],[1,-1],[0,0],[-1,1],[1,1]],6:[[-1,-1],[1,-1],[-1,0],[1,0],[-1,1],[1,1]]};
    const ss=Math.sin(theta),cc=Math.cos(theta);
    for(const [a,b] of dots[this.diceValues[i]]||dots[1]){
      const dx=a*.125,dz=b*.125;
      g.cyl(x+dx*cc-dz*ss,y+.235,pz+dx*ss+dz*cc,.030,.030,.007,pip,0,8);
    }
  }
  const gl=this.gl;gl.useProgram(this.prg);gl.uniformMatrix4fv(this.uVP,false,new Float32Array(this.vp));gl.uniform3fv(this.uEye,new Float32Array(this.eye));gl.bindBuffer(gl.ARRAY_BUFFER,this.diceBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(g.data),gl.DYNAMIC_DRAW);
  gl.vertexAttribPointer(0,3,gl.FLOAT,false,40,0);gl.vertexAttribPointer(1,3,gl.FLOAT,false,40,12);gl.vertexAttribPointer(2,3,gl.FLOAT,false,40,24);gl.vertexAttribPointer(3,1,gl.FLOAT,false,40,36);gl.drawArrays(gl.TRIANGLES,0,g.data.length/10);
 }
 renderPhotos(){const gl=this.gl;gl.useProgram(this.photoPrg);gl.uniformMatrix4fv(this.imgVP,false,new Float32Array(this.vp));gl.enableVertexAttribArray(0);gl.enableVertexAttribArray(1);gl.bindBuffer(gl.ARRAY_BUFFER,this.imgBuffer);for(const item of this.g.photos){const tex=this.images.get(item.src);if(!tex)continue;const [a,b,c,d]=item.p,flat=[...a,0,0,...d,0,1,...c,1,1,...a,0,0,...c,1,1,...b,1,0];gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(flat),gl.DYNAMIC_DRAW);gl.vertexAttribPointer(0,3,gl.FLOAT,false,20,0);gl.vertexAttribPointer(1,2,gl.FLOAT,false,20,12);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,tex);gl.disable(gl.CULL_FACE);gl.drawArrays(gl.TRIANGLES,0,6);gl.enable(gl.CULL_FACE)}}
 markers(){if(!this.game.started||!this.game.active)return [];const t=this.game.turn,b=this.game.board;const choice=t.phase==='setup'?t.setupMode:t.phase==='robber'?'robber':this.mode;const positions=this.game.actions?.[choice]?.positions||[];
  if(choice==='robber')return b.hexes.filter(h=>h.id!==b.robber).map(h=>({kind:'hex',id:h.id,p:[h.x*hexToWorld,2.24,h.y*hexToWorld]}));
  if(choice==='road')return b.edges.filter(e=>positions.includes(e.id)).map(e=>{const a=b.vertices[e.a],q=b.vertices[e.b];return {kind:'edge',id:e.id,p:[(a.x+q.x)*hexToWorld/2,2.22,(a.y+q.y)*hexToWorld/2]}});
  if(choice==='city'||choice==='settlement')return b.vertices.filter(v=>positions.includes(v.id)).map(v=>({kind:'vertex',id:v.id,p:[v.x*hexToWorld,2.28,v.y*hexToWorld],best:this.game.actions.bestVertex===v.id}));return [];
 }
 renderHud(){const ctx=this.hud.getContext('2d'),w=this.width,h=this.height;ctx.clearRect(0,0,w,h);const sf=Math.min(w/1100,h/700)*1.5;
  ctx.textAlign='center';ctx.textBaseline='middle';for(const l of this.g.labels){const p=proj(l.p,this.vp,w,h);if(!p)continue;const [x,y]=p;if(l.type==='number'){if(!l.text)continue;ctx.font=`700 ${clamp(15*sf,11,25)}px system-ui`;ctx.fillStyle=l.robber?'#49312c':'#2d251b';ctx.fillText(l.text,x,y)}else{const f=clamp(12*sf,11,17);ctx.font=`600 ${f}px system-ui`;const txt=l.name+(l.me?' · vos':'');const tw=ctx.measureText(txt).width;ctx.fillStyle='rgba(17,23,22,.82)';ctx.beginPath();ctx.roundRect(x-tw/2-11,y-10,tw+22,22,7);ctx.fill();ctx.fillStyle=l.connected?'#fff3da':'#929693';ctx.fillText(txt,x,y+1)}}
  this.clickables=[];const pulse=.75+.25*Math.sin(performance.now()*.005);
  for(const m of this.markers()){
    const p=proj(m.p,this.vp,w,h);if(!p)continue;const [x,y]=p;if(x<0||x>w||y<0||y>h)continue;
    const density=clamp(this.width/Math.max(1,this.canvas.clientWidth),1,2);const radius=(m.kind==='hex'?27:m.kind==='edge'?19:20)*density;
    ctx.save();ctx.shadowBlur=16;ctx.shadowColor='#efc374';ctx.beginPath();ctx.arc(x,y,radius+5,0,2*Math.PI);ctx.fillStyle=`rgba(234,186,106,${.11*pulse})`;ctx.fill();ctx.shadowBlur=0;
    ctx.beginPath();ctx.arc(x,y,radius,0,2*Math.PI);ctx.lineWidth=3;ctx.strokeStyle=(this.selectedPlacement?.kind===m.kind&&this.selectedPlacement?.id===m.id)?'#8de2c0':m.best?'#fff4bf':'#efca81';ctx.stroke();
    ctx.beginPath();ctx.arc(x,y,Math.max(11,radius*.59),0,2*Math.PI);ctx.fillStyle='rgba(21,27,25,.78)';ctx.fill();
    ctx.fillStyle=m.best?'#fff6bf':'#ffe0a5';ctx.font=`800 ${Math.max(15,radius*.83)}px system-ui`;ctx.fillText(m.kind==='edge'?'╱':m.kind==='hex'?'♟':'⌂',x,y+.5);
    ctx.restore();this.clickables.push({x,y,r:Math.max(radius+12*density,36*density),kind:m.kind,id:m.id});
  }
 }
 pick(ev){const box=this.canvas.getBoundingClientRect(),x=(ev.clientX-box.left)/box.width*this.width,y=(ev.clientY-box.top)/box.height*this.height;const best=this.clickables.map(o=>({...o,d:Math.hypot(o.x-x,o.y-y)})).filter(o=>o.d<o.r).sort((a,b)=>a.d-b.d)[0];if(best)this.onPick?.(best.kind,best.id)}
 animate(){this.raf=requestAnimationFrame((t)=>{const diff=t-this.lastFrame;if(!document.hidden&&diff>=(innerWidth<700?28:18)){
   this.lastFrame=t;this.render(t);
   if(this.frameTimes.length>45)this.frameTimes.shift();this.frameTimes.push(diff);
   if(this.frameTimes.length===45&&this.frame%45===0){const avg=this.frameTimes.reduce((a,b)=>a+b,0)/45;
    const next=avg>42?Math.max(.75,this.quality-.10):avg<24?Math.min(1.0,this.quality+.06):this.quality;
    if(next!==this.quality){this.quality=next;this.resize()}
   }
   this.frame++;
  }this.animate()})}
 dispose(){cancelAnimationFrame(this.raf);this.resizeObserver?.disconnect();for(const tex of this.images.values())this.gl.deleteTexture(tex);this.gl.deleteBuffer(this.buffer);this.gl.deleteBuffer(this.diceBuffer);this.gl.deleteBuffer(this.imgBuffer);this.gl.deleteProgram(this.prg);this.gl.deleteProgram(this.photoPrg)}
}
