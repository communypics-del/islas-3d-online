/* ISLAS · Motor visual WebGL propio, sin dependencia de CDNs. Geometría real 3D,
   luz direccional, materiales procedurales, perspectiva y selección proyectada. */
const R=Math.PI/180;
const palette={forest:[.17,.35,.24],hill:[.49,.27,.15],pasture:[.38,.52,.29],field:[.72,.54,.23],mountain:[.41,.43,.43],desert:[.66,.55,.37]};
const hexToWorld=.0195;
function col(hex){if(!hex)return [.8,.7,.5];return [1,3,5].map(x=>parseInt(hex.slice(x,x+2),16)/255)}
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function sub(a,b){return a.map((v,i)=>v-b[i])}
function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]}
function norm(a){const l=Math.hypot(...a)||1;return a.map(x=>x/l)}
function dot(a,b){return a.reduce((s,x,i)=>s+x*b[i],0)}
function lookAt(eye,target){const z=norm(sub(eye,target)),x=norm(cross([0,1,0],z)),y=cross(z,x);return [x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1]}
function perspective(fov,aspect,n,f){const t=1/Math.tan(fov/2);return [t/aspect,0,0,0,0,t,0,0,0,0,(f+n)/(n-f),-1,0,0,2*f*n/(n-f),0]}
function mult(a,b){let o=new Array(16).fill(0);for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let i=0;i<4;i++)o[c*4+r]+=a[i*4+r]*b[c*4+i];return o}
function proj(p,m,w,h){const x=p[0],y=p[1],z=p[2],q=m[3]*x+m[7]*y+m[11]*z+m[15];if(q<=0)return null;const nx=(m[0]*x+m[4]*y+m[8]*z+m[12])/q,ny=(m[1]*x+m[5]*y+m[9]*z+m[13])/q;if(Math.abs(nx)>1.4||Math.abs(ny)>1.4)return null;return [(nx*.5+.5)*w,(-ny*.5+.5)*h,q]}
class Geometry {
 constructor(){this.data=[];this.photos=[];this.labels=[];this.clickables=[]}
 tri(a,b,c,color,mat=0){const n=norm(cross(sub(b,a),sub(c,a)));for(const p of [a,b,c])this.data.push(...p,...n,...color,mat)}
 quad(a,b,c,d,color,mat=0){this.tri(a,b,c,color,mat);this.tri(a,c,d,color,mat)}
 box(x,y,z,w,h,d,color,mat=0,theta=0){const cc=Math.cos(theta),ss=Math.sin(theta),P=(a,b,c)=>[x+a*cc-c*ss,y+b,z+a*ss+c*cc],a=w/2,b=h/2,c=d/2;
  const p=[P(-a,-b,-c),P(a,-b,-c),P(a,b,-c),P(-a,b,-c),P(-a,-b,c),P(a,-b,c),P(a,b,c),P(-a,b,c)];
  for(const I of [[0,3,2,1],[4,5,6,7],[0,4,7,3],[1,2,6,5],[3,7,6,2],[0,1,5,4]])this.quad(...I.map(i=>p[i]),color,mat)}
 cyl(x,y,z,rx,rz,h,color,mat=0,sides=18){let top=[],bottom=[];for(let i=0;i<sides;i++){const a=2*Math.PI*i/sides;top.push([x+Math.cos(a)*rx,y+h,z+Math.sin(a)*rz]);bottom.push([x+Math.cos(a)*rx,y,z+Math.sin(a)*rz])}
  for(let i=0;i<sides;i++){const j=(i+1)%sides;this.quad(bottom[j],bottom[i],top[i],top[j],color,mat);this.tri([x,y+h,z],top[j],top[i],color,mat);this.tri([x,y,z],bottom[i],bottom[j],color,mat)}}
 cone(x,y,z,r,h,color,mat=0,sides=9){const apex=[x,y+h,z];for(let i=0;i<sides;i++){const a=i*2*Math.PI/sides,b=(i+1)*2*Math.PI/sides;this.tri([x+Math.cos(b)*r,y,z+Math.sin(b)*r],[x+Math.cos(a)*r,y,z+Math.sin(a)*r],apex,color,mat)}}
 sphere(x,y,z,r,color,mat=0){const rows=8,cols=12;for(let i=0;i<rows;i++)for(let j=0;j<cols;j++){
  const pt=(ri,cj)=>{const ph=ri*Math.PI/rows,th=cj*2*Math.PI/cols;return [x+Math.sin(ph)*Math.cos(th)*r,y+Math.cos(ph)*r,z+Math.sin(ph)*Math.sin(th)*r]};
  this.quad(pt(i,j),pt(i,j+1),pt(i+1,j+1),pt(i+1,j),color,mat)}}
 beam(a,b,r,color,mat=0){let v=sub(b,a),l=Math.hypot(...v);if(!l)return;const t=norm(v),up=Math.abs(t[1])>.9?[1,0,0]:[0,1,0],u=norm(cross(t,up)),w=cross(t,u),n=7;
  for(let i=0;i<n;i++){const k=i*2*Math.PI/n,k2=(i+1)*2*Math.PI/n,pt=(o,ang)=>[o[0]+r*(Math.cos(ang)*u[0]+Math.sin(ang)*w[0]),o[1]+r*(Math.cos(ang)*u[1]+Math.sin(ang)*w[1]),o[2]+r*(Math.cos(ang)*u[2]+Math.sin(ang)*w[2])];this.quad(pt(a,k2),pt(b,k2),pt(b,k),pt(a,k),color,mat)}}
 hex(x,y,z,r,h,color,mat=0){let pts=[];for(let k=0;k<6;k++){const a=(-90+k*60)*R;pts.push([x+r*Math.cos(a),y,z+r*Math.sin(a)])}for(let i=0;i<6;i++){this.tri([x,y,z],pts[(i+1)%6],pts[i],color,mat);const a=pts[i],b=pts[(i+1)%6];this.quad([b[0],y-h,b[2]],[a[0],y-h,a[2]],a,b,color.map(c=>c*.77),mat)}}
}
const vertSrc=`#version 300 es
precision highp float;layout(location=0)in vec3 aP;layout(location=1)in vec3 aN;layout(location=2)in vec3 aC;layout(location=3)in float aM;uniform mat4 uVP;out vec3 vP;out vec3 vN;out vec3 vC;out float vM;void main(){vP=aP;vN=aN;vC=aC;vM=aM;gl_Position=uVP*vec4(aP,1.0);}`;
const fragSrc=`#version 300 es
precision highp float;in vec3 vP;in vec3 vN;in vec3 vC;in float vM;out vec4 outColor;uniform vec3 uEye;
float hash(vec3 p){return fract(sin(dot(p,vec3(127.1,311.7,74.7)))*43758.5453);}
float noise(vec3 p){vec3 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);float n=0.;for(int dx=0;dx<=1;dx++)for(int dy=0;dy<=1;dy++)for(int dz=0;dz<=1;dz++){vec3 d=vec3(float(dx),float(dy),float(dz));n+=hash(i+d)*mix(1.-f.x,f.x,d.x)*mix(1.-f.y,f.y,d.y)*mix(1.-f.z,f.z,d.z);}return n;}
void main(){vec3 N=normalize(vN);float n=noise(vP*7.5),fine=noise(vP*46.);vec3 base=vC;
 if(vM>0.5){base*=.80+.32*n+.095*(fine-.5);}
 if(vM>1.5&&vM<2.5){float strip=sin(vP.x*19.+sin(vP.z*3.)*.8);base*=.89+.12*strip+.18*n;}
 if(vM>2.5&&vM<3.5){base*=.83+.23*noise(vP*25.)+.085*fine;}
 if(vM>3.5&&vM<4.5){base*=.90+.13*sin(vP.x*32.)+.08*fine;}
 if(vM>4.5){base*=.92+.18*noise(vP*12.);}
 vec3 L=normalize(vec3(-.46,.92,.34));float light=max(dot(N,L),0.);float fill=max(dot(N,normalize(vec3(.65,.55,-.50))),0.);float shade=.37+light*.55+fill*.17;
 vec3 viewDir=normalize(uEye-vP);vec3 reflectDir=reflect(-L,N);float spec=pow(max(dot(viewDir,reflectDir),0.),vM>1.5&&vM<2.5?19.:40.)*.16;
 vec3 c=base*shade+vec3(1.0,.77,.52)*spec;float dist=length(uEye-vP);float fog=1.-exp(-.0010*dist*dist);c=mix(c,vec3(.095,.084,.074),fog*.53);outColor=vec4(pow(max(c,vec3(0.0)),vec3(.94)),1.);}`;
const photoVert=`#version 300 es
layout(location=0)in vec3 aP;layout(location=1)in vec2 aUV;uniform mat4 uVP;out vec2 vUV;void main(){vUV=aUV;gl_Position=uVP*vec4(aP,1.);}`;
const photoFrag=`#version 300 es
precision mediump float;uniform sampler2D uImage;in vec2 vUV;out vec4 color;void main(){color=texture(uImage,vUV);}`;
function shader(gl,type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s}
function program(gl,vs,fs){const p=gl.createProgram();gl.attachShader(p,shader(gl,gl.VERTEX_SHADER,vs));gl.attachShader(p,shader(gl,gl.FRAGMENT_SHADER,fs));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p}
const demoTypes=['forest','hill','pasture','field','mountain','forest','pasture','field','hill','forest','desert','pasture','field','mountain','forest','field','pasture','hill','mountain'];
function preview(){const lengths=[3,4,5,4,3],hexes=[];for(let r=0;r<5;r++)for(let c=0;c<lengths[r];c++){hexes.push({id:hexes.length,x:(c-(lengths[r]-1)/2)*108+(r-2)*-9,y:(r-2)*93,type:demoTypes[hexes.length],number:[5,9,10,8,6,3,11,4,12,2,6,8,9,10,5,4,3,11,9][hexes.length]})}return hexes}
export class IslasScene {
 constructor(canvas,onPick){this.canvas=canvas;this.hud=canvas.parentElement.querySelector('.scene-hud');this.onPick=onPick;this.gl=canvas.getContext('webgl2',{antialias:true,alpha:false,preserveDrawingBuffer:false});if(!this.gl)throw Error('WebGL 2 no disponible.');this.g=new Geometry();this.angles={yaw:.46,dist:19.5,height:11.8};this.eye=[8,15,20];this.targetEye=[8,15,20];this.targetLook=[0,1,0];this.look=[0,1,0];this.first=false;this.manual=false;this.frame=0;this.raf=null;this.photos=new Map();this.images=new Map();this.labelMap=[];this.game=null;this.mode=null;this.hasMoved=false;
  const gl=this.gl;this.prg=program(gl,vertSrc,fragSrc);this.photoPrg=program(gl,photoVert,photoFrag);this.uVP=gl.getUniformLocation(this.prg,'uVP');this.uEye=gl.getUniformLocation(this.prg,'uEye');this.imgVP=gl.getUniformLocation(this.photoPrg,'uVP');this.buffer=gl.createBuffer();this.imgBuffer=gl.createBuffer();gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.clearColor(.065,.060,.052,1);
  const down=e=>{this.drag={x:e.clientX,y:e.clientY,yaw:this.angles.yaw,height:this.angles.height};this.hasMoved=false;canvas.setPointerCapture?.(e.pointerId)};
  const move=e=>{if(!this.drag)return;const dx=e.clientX-this.drag.x,dy=e.clientY-this.drag.y;if(Math.abs(dx)+Math.abs(dy)>7)this.hasMoved=true;this.angles.yaw=this.drag.yaw-dx*.0065;this.angles.height=clamp(this.drag.height+dy*.034,6.5,24);this.manual=true};
  const up=e=>{if(!this.drag)return;this.drag=null;if(!this.hasMoved)this.pick(e)};
  canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',()=>{this.drag=null});
  canvas.addEventListener('wheel',e=>{e.preventDefault();this.angles.dist=clamp(this.angles.dist+e.deltaY*.025,12,38);this.manual=true},{passive:false});
  this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(canvas);this.resize();this.animate();
 }
 resize(){if(!this.canvas?.isConnected)return;const dpr=Math.min(devicePixelRatio||1,innerWidth<700?1.25:1.5),w=Math.max(10,Math.floor(this.canvas.clientWidth*dpr)),h=Math.max(10,Math.floor(this.canvas.clientHeight*dpr));if(this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;this.hud.width=w;this.hud.height=h}this.width=w;this.height=h;this.gl.viewport(0,0,w,h)}
 update(game,mode){this.game=game;this.mode=mode;const stateKey=`${game.version}|${game.started}|${game.players.map(p=>p.avatar?.length||0).join(',')}`;if(this.stateKey!==stateKey){this.stateKey=stateKey;this.rebuild()}
  const first=!!game.active&&!game.finished;
  if(this.first!==first){this.first=first;this.manual=false}
 }
 setOverview(){this.first=false;this.manual=false;this.override=true;}
 setFirstPerson(){this.first=true;this.manual=false;this.override=false;}
 drawRoom(g){const A=[.115,.11,.097],wall=[.23,.215,.195],gold=[.71,.49,.24];
  g.box(0,-.30,0,42,.5,42,[.22,.165,.105],2);g.box(0,25,0,42,.4,42,[.27,.24,.22],3);
  g.box(-20,6,0,.4,12,42,wall,3);g.box(20,6,0,.4,12,42,wall,3);g.box(0,6,-20,42,12,.5,wall,3);
  for(let i=-17;i<=17;i+=4){g.box(i,6,-19.64,.13,10.5,.12,[.43,.33,.21],2);g.box(i,6.2,-19.48,2.5,7.2,.07,[.09,.18,.20],0);g.box(i,2.7,-19.4,2.6,.10,.14,gold,0);g.box(i,9.7,-19.4,2.6,.10,.14,gold,0)}
  // Low-angle window light, picture frames and wall sconces.
  for(let i=-14;i<=14;i+=14){g.box(i,6.1,-19.31,4.7,3.1,.15,[.095,.095,.09],2);g.box(i,6.1,-19.21,4.1,2.5,.08,[.32,.29,.23],1);g.box(i,6.1,-19.12,3.5,1.9,.09,[.15,.24,.19],1);}
  for(let i=0;i<6;i++){const a=i*Math.PI/3;g.cyl(Math.sin(a)*14,.0,Math.cos(a)*14,.90,.90,.026,[.09,.065,.042],0,20)}
  // Large circular oak table, carved edge, brass lip and solid legs.
  g.cyl(0,.15,0,8.05,6.95,1.21,[.20,.105,.052],2,56);g.cyl(0,1.25,0,8.33,7.18,.20,[.46,.275,.145],2,56);
  g.cyl(0,1.40,0,8.23,7.09,.045,gold,0,56);g.cyl(0,1.445,0,8.06,6.92,.075,[.37,.215,.112],2,56);
  for(let i=0;i<4;i++){const a=(i+.5)*Math.PI/2;g.cyl(Math.sin(a)*4.6,-.02,Math.cos(a)*3.4,.40,.40,1.6,[.20,.115,.07],2,12)}
  // Hanging brass chandelier and warm bulbs.
  g.cyl(0,9.0,0,.09,.09,4.2,[.42,.31,.18],0,12);g.cyl(0,8.7,0,2.2,2.2,.25,[.55,.36,.17],0,24);g.cyl(0,8.37,0,2.0,2.0,.18,[.88,.73,.44],0,24);
  for(let i=0;i<8;i++){const a=i*Math.PI/4;g.sphere(Math.sin(a)*1.65,8.30,Math.cos(a)*1.65,.24,[.99,.77,.41],0)}
 }
 drawChair(g,a){const x=Math.sin(a)*9.15,z=Math.cos(a)*8.35;const t=a,wood=[.23,.13,.076],fabric=[.19,.18,.17];g.box(x,.79,z,1.25,.20,1.16,fabric,4,t);const bx=x+Math.sin(a)*.52,bz=z+Math.cos(a)*.52;g.box(bx,1.55,bz,1.32,1.55,.23,wood,2,t);g.box(bx,1.67,bz,1.04,1.18,.28,[.25,.25,.23],4,t);
  for(const u of [-.47,.47])for(const v of [-.43,.43]){const px=x+u*Math.cos(t)-v*Math.sin(t),pz=z+u*Math.sin(t)+v*Math.cos(t);g.box(px,.36,pz,.13,.72,.14,wood,2,t)}
  return [x,z]
 }
 drawAvatar(g,p,i,n){const a=i*2*Math.PI/n,x=Math.sin(a)*9.15,z=Math.cos(a)*8.35,rgb=col(p.color),shirt=rgb.map(v=>v*.48+.17),dark=[.105,.112,.132];const toward=[-Math.sin(a),0,-Math.cos(a)];
  // Volumetric seated body, arms, legs and head; the uploaded portrait is visible on the face plane.
  g.box(x,1.67,z,1.05,1.17,.67,shirt,4,a);
  for(const side of [-1,1]){const sx=x+side*Math.cos(a)*.60,sz=z+side*Math.sin(a)*.60;g.beam([sx,2.02,sz],[sx+toward[0]*.20,1.35,sz+toward[2]*.20],.18,shirt,4)}
  g.sphere(x,2.61,z,.43,[.71,.53,.40],4);g.sphere(x,2.92,z-.055,.38,[.23,.17,.14],4);
  for(const side of [-1,1]){const bx=x+side*Math.cos(a)*.29,bz=z+side*Math.sin(a)*.29;g.beam([bx,1.05,bz],[bx+toward[0]*.45,.41,bz+toward[2]*.45],.19,dark,4)}
  const face=[x+toward[0]*.390,2.60,z+toward[2]*.390];
  if(p.avatar){const right=[Math.cos(a),0,-Math.sin(a)],H=.57,W=.58;const pt=(xx,yy)=>[face[0]+right[0]*xx,face[1]+yy,face[2]+right[2]*xx];g.photos.push({id:p.id,src:p.avatar,p:[pt(-W/2,H/2),pt(W/2,H/2),pt(W/2,-H/2),pt(-W/2,-H/2)]})}
  else {g.sphere(x+toward[0]*.32,2.61,z+toward[2]*.32,.25,[.82,.63,.45],4)}
  this.g.labels.push({type:'player',p:[x,3.46,z],name:p.name,me:p.me,connected:p.connected,active:this.game?.turn?.index===i&&this.game.started});
  if(this.game?.started&&this.game.turn?.index===i){g.cyl(x,.012,z,1.13,1.00,.020,[.93,.68,.29],0,24)}
 }
 tileDecor(g,h,x,z){const seed=h.id*31+4,j=(i)=>Math.sin(seed+i*18.27)*.43+.5,base=palette[h.type]||[.4,.4,.4],y=1.81;
  g.hex(x,y,z,1.165,.27,base,1);
  if(h.type==='forest'){for(let i=0;i<5;i++){const dx=(j(i*2)-.5)*1.05,dz=(j(i*2+1)-.5)*1.05;g.cyl(x+dx,y,z+dz,.052,.052,.26,[.23,.14,.07],2,6);g.cone(x+dx,y+.14,z+dz,.23,.54,[.095+.055*j(i),.25+.07*j(i+4),.15],1)}}
  if(h.type==='field'){for(let i=0;i<5;i++){const dx=(i-2)*.19;for(let q=0;q<4;q++)g.cone(x+dx,y,z+(q-1.5)*.26,.050,.34,[.83,.66+.12*j(q),.22],1,5)}}
  if(h.type==='hill'){for(let i=0;i<4;i++)g.box(x+(j(i*3)-.5)*1.05,y+.12,z+(j(i*5)-.5)*.85,.24,.25,.26,[.64,.35,.20],3,j(i*4))}
  if(h.type==='pasture'){for(let i=0;i<4;i++){const dx=(j(i*2)-.5)*1.1,dz=(j(i*2+1)-.5)*.9;g.sphere(x+dx,y+.18,z+dz,.13,[.88,.84,.70],0);g.sphere(x+dx+.10,y+.18,z+dz-.08,.073,[.66,.58,.47],0)}}
  if(h.type==='mountain'){for(let i=0;i<4;i++){const dx=(j(i*3)-.5)*.77,dz=(j(i*4)-.5)*.80;g.cone(x+dx,y,z+dz,.27,.46+j(i)*.30,[.33,.35,.38],3,5)}}
  if(h.type==='desert'){for(let i=0;i<3;i++)g.sphere(x+(j(i)-.5)*1.0,y+.05,z+(j(i+3)-.5)*.5,.18,[.68,.51,.29],1)}
  g.cyl(x,y+.04,z,.255,.255,.095,[.88,.75,.49],0,18);
  this.g.labels.push({type:'number',p:[x,y+.155,z],text:String(h.number||''),robber:this.game.board?.robber===h.id});
  if(this.game.board?.robber===h.id){g.cyl(x+.42,y+.07,z+.26,.105,.105,.34,[.15,.14,.14],4,12);g.sphere(x+.42,y+.44,z+.26,.14,[.12,.12,.11],4)}
 }
 drawBoard(g){const game=this.game,b=game.board,hs=b?b.hexes:preview();const offsetY=1.82;g.cyl(0,1.54,0,6.5,5.4,.075,[.08,.18,.18],0,44);g.cyl(0,1.61,0,6.19,5.13,.045,[.095,.24,.23],0,44);
  for(const h of hs){const x=h.x*hexToWorld,z=h.y*hexToWorld;this.tileDecor(g,h,x,z)}
  if(!b)return;
  for(const e of b.edges)if(e.owner!==null){const a=b.vertices[e.a],v=b.vertices[e.b],color=col(game.players[e.owner]?.color);g.beam([a.x*hexToWorld,2.07,a.y*hexToWorld],[v.x*hexToWorld,2.07,v.y*hexToWorld],.073,color,4)}
  for(const v of b.vertices)if(v.owner!==null){const x=v.x*hexToWorld,z=v.y*hexToWorld,c=col(game.players[v.owner]?.color),isCity=v.building==='city';g.box(x,2.11,z,isCity?.30:.23,isCity?.40:.27,isCity?.28:.23,c,4);g.cone(x,2.11+(isCity?.20:.12),z,isCity?.27:.22,isCity?.27:.20,[.85,.76,.58],2,4)}
 }
 rebuild(){const g=new Geometry();this.g=g;this.drawRoom(g);this.drawBoard(g);for(let i=0;i<6;i++)this.drawChair(g,i*Math.PI/3);this.game.players.forEach((p,i)=>this.drawAvatar(g,p,i,Math.max(this.game.max,6)));
  const gl=this.gl;this.count=g.data.length/10;gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(g.data),gl.STATIC_DRAW);
  const old=this.images;this.images=new Map();for(const photo of g.photos){if(old.has(photo.src)){this.images.set(photo.src,old.get(photo.src));old.delete(photo.src)}else {const img=new Image();img.onload=()=>{const texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,1);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);gl.generateMipmap(gl.TEXTURE_2D);this.images.set(photo.src,texture)};img.src=photo.src}}
  for(const tex of old.values())gl.deleteTexture(tex);
 }
 currentEye(){let target,look=[0,1.8,0];if(this.first&&this.game?.active){const i=this.game.players.findIndex(p=>p.me),a=Math.max(i,0)*Math.PI/3;target=[Math.sin(a)*8.4,3.70,Math.cos(a)*7.8];look=[0,1.82,0]}
  else target=[Math.sin(this.angles.yaw)*this.angles.dist,this.angles.height,Math.cos(this.angles.yaw)*this.angles.dist];return {target,look}}
 render(time){if(!this.canvas?.isConnected)return;this.resize();const {target,look}=this.currentEye();for(let i=0;i<3;i++){this.eye[i]+=(target[i]-this.eye[i])*.13;this.look[i]+=(look[i]-this.look[i])*.13}const gl=this.gl;this.vp=mult(perspective((this.first?49:45)*R,this.width/this.height,.2,95),lookAt(this.eye,this.look));
  gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(this.prg);gl.uniformMatrix4fv(this.uVP,false,new Float32Array(this.vp));gl.uniform3fv(this.uEye,new Float32Array(this.eye));gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);gl.enableVertexAttribArray(0);gl.enableVertexAttribArray(1);gl.enableVertexAttribArray(2);gl.enableVertexAttribArray(3);gl.vertexAttribPointer(0,3,gl.FLOAT,false,40,0);gl.vertexAttribPointer(1,3,gl.FLOAT,false,40,12);gl.vertexAttribPointer(2,3,gl.FLOAT,false,40,24);gl.vertexAttribPointer(3,1,gl.FLOAT,false,40,36);gl.drawArrays(gl.TRIANGLES,0,this.count||0);
  this.renderPhotos();this.renderHud(); }
 renderPhotos(){const gl=this.gl;gl.useProgram(this.photoPrg);gl.uniformMatrix4fv(this.imgVP,false,new Float32Array(this.vp));gl.enableVertexAttribArray(0);gl.enableVertexAttribArray(1);gl.bindBuffer(gl.ARRAY_BUFFER,this.imgBuffer);for(const item of this.g.photos){const tex=this.images.get(item.src);if(!tex)continue;const [a,b,c,d]=item.p,flat=[...a,0,0,...d,0,1,...c,1,1,...a,0,0,...c,1,1,...b,1,0];gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(flat),gl.DYNAMIC_DRAW);gl.vertexAttribPointer(0,3,gl.FLOAT,false,20,0);gl.vertexAttribPointer(1,2,gl.FLOAT,false,20,12);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,tex);gl.disable(gl.CULL_FACE);gl.drawArrays(gl.TRIANGLES,0,6);gl.enable(gl.CULL_FACE)}}
 markers(){if(!this.game.started||!this.game.active)return [];const t=this.game.turn,b=this.game.board;const choice=t.phase==='setup'?t.setupMode:t.phase==='robber'?'robber':this.mode;const positions=this.game.actions?.[choice]?.positions||[];
  if(choice==='robber')return b.hexes.filter(h=>h.id!==b.robber).map(h=>({kind:'hex',id:h.id,p:[h.x*hexToWorld,2.24,h.y*hexToWorld]}));
  if(choice==='road')return b.edges.filter(e=>positions.includes(e.id)).map(e=>{const a=b.vertices[e.a],q=b.vertices[e.b];return {kind:'edge',id:e.id,p:[(a.x+q.x)*hexToWorld/2,2.22,(a.y+q.y)*hexToWorld/2]}});
  if(choice==='city'||choice==='settlement')return b.vertices.filter(v=>positions.includes(v.id)).map(v=>({kind:'vertex',id:v.id,p:[v.x*hexToWorld,2.28,v.y*hexToWorld],best:this.game.actions.bestVertex===v.id}));return [];
 }
 renderHud(){const ctx=this.hud.getContext('2d'),w=this.width,h=this.height;ctx.clearRect(0,0,w,h);const sf=Math.min(w/1100,h/700)*1.5;
  ctx.textAlign='center';ctx.textBaseline='middle';for(const l of this.g.labels){const p=proj(l.p,this.vp,w,h);if(!p)continue;const [x,y]=p;if(l.type==='number'){if(!l.text)continue;ctx.font=`700 ${clamp(15*sf,11,25)}px system-ui`;ctx.fillStyle=l.robber?'#49312c':'#2d251b';ctx.fillText(l.text,x,y)}else{const f=clamp(12*sf,11,17);ctx.font=`600 ${f}px system-ui`;const txt=l.name+(l.me?' · vos':'');const tw=ctx.measureText(txt).width;ctx.fillStyle='rgba(17,23,22,.82)';ctx.beginPath();ctx.roundRect(x-tw/2-11,y-10,tw+22,22,7);ctx.fill();ctx.fillStyle=l.connected?'#fff3da':'#929693';ctx.fillText(txt,x,y+1)}}
  this.clickables=[];for(const m of this.markers()){const p=proj(m.p,this.vp,w,h);if(!p)continue;const [x,y]=p;if(x<0||x>w||y<0||y>h)continue;const radius=m.kind==='hex'?26: m.kind==='edge'?14:12;ctx.beginPath();ctx.arc(x,y,radius,0,2*Math.PI);ctx.strokeStyle=m.best?'#fffbb8':'#e6cc89';ctx.lineWidth=2.4;ctx.stroke();ctx.beginPath();ctx.arc(x,y,4.1,0,Math.PI*2);ctx.fillStyle=m.best?'#ffe59e':'#eaf6e7';ctx.fill();this.clickables.push({x,y,r:Math.max(radius,22),kind:m.kind,id:m.id})}
 }
 pick(ev){const box=this.canvas.getBoundingClientRect(),x=(ev.clientX-box.left)/box.width*this.width,y=(ev.clientY-box.top)/box.height*this.height;const best=this.clickables.map(o=>({...o,d:Math.hypot(o.x-x,o.y-y)})).filter(o=>o.d<o.r).sort((a,b)=>a.d-b.d)[0];if(best)this.onPick?.(best.kind,best.id)}
 animate(){this.raf=requestAnimationFrame((t)=>{this.render(t);this.animate()})}
 dispose(){cancelAnimationFrame(this.raf);this.resizeObserver?.disconnect();for(const tex of this.images.values())this.gl.deleteTexture(tex);this.gl.deleteBuffer(this.buffer);this.gl.deleteBuffer(this.imgBuffer);this.gl.deleteProgram(this.prg);this.gl.deleteProgram(this.photoPrg)}
}
