/* Voice chat: browser WebRTC mesh with private-room SSE signaling. Audio is peer-to-peer.
   A TURN server is recommended for strict NATs; microphone requires HTTPS or localhost. */
export class VoiceRoom {
 constructor({room,token,id,changed,onError}){this.room=room;this.token=token;this.id=id;this.changed=changed;this.onError=onError;this.peers=new Map();this.active=false;this.muted=false;this.stream=null;this.source=null;this.audioBox=document.createElement('div');this.audioBox.hidden=true;this.audioBox.id='remote-audio';document.body.append(this.audioBox)}
 async post(type,to,payload){const r=await fetch('/api/signal',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({room:this.room,token:this.token,to,type,payload})});if(!r.ok)throw Error('Error de señalización de voz')}
 async join(){if(this.active)return;try{if(!navigator.mediaDevices?.getUserMedia)throw Error('El chat de voz requiere HTTPS o localhost.');this.stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});this.active=true;this.muted=false;this.source=new EventSource(`/api/voice-stream?room=${encodeURIComponent(this.room)}&token=${encodeURIComponent(this.token)}`);this.source.onmessage=e=>{this.onMessage(JSON.parse(e.data)).catch(err=>this.onError?.(err.message))};this.source.onerror=()=>{if(this.active)this.changed?.()};this.changed?.()}catch(e){this.onError?.(e.message||'No se pudo acceder al micrófono.');this.leave()}}
 createPeer(id){let p=this.peers.get(id);if(p)return p;const pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});p={pc,queued:[],remoteSet:false,id};this.peers.set(id,p);for(const track of this.stream.getAudioTracks())pc.addTrack(track,this.stream);pc.onicecandidate=e=>{if(e.candidate)this.post('candidate',id,e.candidate.toJSON()).catch(()=>{})};pc.ontrack=e=>{let audio=p.audio;if(!audio){audio=document.createElement('audio');audio.autoplay=true;audio.playsInline=true;audio.dataset.peer=id;this.audioBox.append(audio);p.audio=audio}audio.srcObject=e.streams[0]||new MediaStream([e.track]);audio.play().catch(()=>{})};pc.onconnectionstatechange=()=>{if(pc.connectionState==='failed'){this.onError?.('No se pudo conectar una voz. Puede ser necesario un servidor TURN.')}};return p}
 async offer(id){if(!this.active||id===this.id)return;const p=this.createPeer(id);if(p.pc.signalingState!=='stable')return;const offer=await p.pc.createOffer();await p.pc.setLocalDescription(offer);await this.post('offer',id,p.pc.localDescription.toJSON())}
 async onMessage(msg){if(!this.active)return;if(msg.type==='welcome'){for(const id of msg.peers)await this.offer(id);this.changed?.();return}
  if(msg.type==='peer-left'){this.closePeer(msg.from);this.changed?.();return}
  if(msg.type==='peer-joined'){this.changed?.();return}
  if(!msg.from||msg.from===this.id)return;
  const p=this.createPeer(msg.from),pc=p.pc;
  if(msg.type==='offer'){if(pc.signalingState!=='stable')await pc.setLocalDescription({type:'rollback'}).catch(()=>{});await pc.setRemoteDescription(new RTCSessionDescription(msg.payload));p.remoteSet=true;await this.flush(p);const ans=await pc.createAnswer();await pc.setLocalDescription(ans);await this.post('answer',msg.from,pc.localDescription.toJSON())}
  if(msg.type==='answer'){if(pc.signalingState==='have-local-offer'){await pc.setRemoteDescription(new RTCSessionDescription(msg.payload));p.remoteSet=true;await this.flush(p)}}
  if(msg.type==='candidate'){if(pc.remoteDescription)await pc.addIceCandidate(msg.payload).catch(()=>{});else p.queued.push(msg.payload)}
 }
 async flush(p){for(const c of p.queued)await p.pc.addIceCandidate(c).catch(()=>{});p.queued=[]}
 toggleMute(){if(!this.active)return;this.muted=!this.muted;for(const t of this.stream.getAudioTracks())t.enabled=!this.muted;this.changed?.()}
 closePeer(id){const p=this.peers.get(id);if(!p)return;p.audio?.remove();p.pc.close();this.peers.delete(id)}
 leave(){this.source?.close();this.source=null;for(const id of [...this.peers.keys()])this.closePeer(id);this.stream?.getTracks().forEach(t=>t.stop());this.stream=null;this.active=false;this.changed?.()}
 destroy(){this.leave();this.audioBox.remove()}
 get count(){return this.peers.size+Number(this.active)}
}
