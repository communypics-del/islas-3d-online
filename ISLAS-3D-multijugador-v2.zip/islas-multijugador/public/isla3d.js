import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js';
const status=document.querySelector('#status');
try {
const scene=new THREE.Scene();scene.background=new THREE.Color('#91d6ed');scene.fog=new THREE.FogExp2(0x91d6ed,.008);
const camera=new THREE.PerspectiveCamera(74,innerWidth/innerHeight,.1,440);camera.position.set(0,1.75,14);
const renderer=new THREE.WebGLRenderer({antialias:false,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);renderer.outputColorSpace=THREE.SRGBColorSpace;document.body.prepend(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xe8f7ff,0x687d55,2.2));const sunlight=new THREE.DirectionalLight(0xffecc8,2);sunlight.position.set(-30,55,-35);scene.add(sunlight);

// Procedural, tileable textures: locally generated; no additional downloads.
function texture(base, flecks, count=1100){
 const c=document.createElement('canvas');c.width=c.height=256;const ctx=c.getContext('2d');
 ctx.fillStyle=base;ctx.fillRect(0,0,256,256);
 let n=873;const rnd=()=>((n=(Math.imul(n,1664525)+1013904223)>>>0)/4294967296);
 for(let i=0;i<count;i++){ctx.globalAlpha=.07+rnd()*.22;ctx.fillStyle=flecks[Math.floor(rnd()*flecks.length)];ctx.fillRect(rnd()*256,rnd()*256,.5+rnd()*4,.5+rnd()*6)}
 ctx.globalAlpha=1;const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),4);return t;
}
const sandTex=texture('#e9d7ac',['#fff1d1','#a68d6b','#f8e4bd'],2200);sandTex.repeat.set(19,19);
const woodTex=texture('#93643c',['#38251b','#caa06c','#6a4529'],1500);woodTex.repeat.set(2,2);
const thatchTex=texture('#b49b5f',['#4c4329','#dfc58a','#8b713f'],2500);
const stoneTex=texture('#a29f92',['#555b57','#e4d9be','#747569'],1800);
const mat=(c)=>new THREE.MeshStandardMaterial({color:c,roughness:1});
const sand=new THREE.MeshStandardMaterial({map:sandTex,roughness:1}),wood=new THREE.MeshStandardMaterial({map:woodTex,roughness:.95});
const thatch=new THREE.MeshStandardMaterial({map:thatchTex,side:THREE.DoubleSide,roughness:1});
const leaf=new THREE.MeshStandardMaterial({color:0x287a42,side:THREE.DoubleSide,roughness:.85});
const leaf2=new THREE.MeshStandardMaterial({color:0x4b9651,side:THREE.DoubleSide,roughness:.85});
const stone=new THREE.MeshStandardMaterial({map:stoneTex,roughness:1});
const sea=new THREE.MeshStandardMaterial({color:0x25b6c3,metalness:.05,roughness:.27,transparent:true,opacity:.89});
function add(geometry,material,x,y,z){const mesh=new THREE.Mesh(geometry,material);mesh.position.set(x,y,z);scene.add(mesh);return mesh}
function cube(x,y,z,w,h,d,m){return add(new THREE.BoxGeometry(w,h,d),m,x,y,z)}
function palm(x,z,h){
 const trunk=add(new THREE.CylinderGeometry(.15,.3,h,8),wood,x,h/2,z);
 trunk.rotation.z=(x%7)*.007;
 for(let j=0;j<9;j++){
  const a=j*Math.PI*2/9;
  const blade=new THREE.Mesh(new THREE.PlaneGeometry(.65,4.8,1,4),j%2?leaf:leaf2);
  blade.position.set(x+Math.cos(a)*1.7,h-.45,z+Math.sin(a)*1.7);
  blade.rotation.order='YXZ';blade.rotation.y=-a;blade.rotation.x=-.55;
  scene.add(blade);
 }
 for(let k=0;k<3;k++)add(new THREE.SphereGeometry(.23,6,5),mat(0x82622b),x+.3*Math.cos(k*2.1),h-.3,z+.3*Math.sin(k*2.1));
}
function bush(x,z,s){for(let i=0;i<5;i++)add(new THREE.IcosahedronGeometry(s*.53,1),i%2?leaf:leaf2,x+(i%3-1)*s*.38,s*.43,z+Math.floor(i/3)*s*.5)}
const blocks=[];
function hut(x,z,s=1){
 const w=5*s,d=4*s;
 // Open timber hut with posts, woven wall panels and visible door.
 cube(x,1.5*s,z-d/2,w,3*s,.16*s,wood);
 for(const xx of [-w/2,w/2])for(const zz of [-d/2,d/2])cube(x+xx,1.8*s,z+zz,.24*s,3.6*s,.24*s,wood);
 cube(x,1.4*s,z+d/2,w,2.8*s,.12*s,wood);
 cube(x,1.1*s,z+d/2+.09*s,1.2*s,2.2*s,.06*s,mat(0x30221a));
 for(const side of [-1,1])cube(x+side*w/2,1.3*s,z,.12*s,2.6*s,d,wood);
 const roof=add(new THREE.ConeGeometry(4.2*s,2.4*s,4),thatch,x,4.05*s,z);roof.rotation.y=Math.PI/4;
 for(let i=0;i<8;i++)cube(x-w/2+i*.72*s,2.9*s,z+d/2,.08*s,.17*s,.4*s,wood);
 blocks.push({x,z,r:3.4*s});
}
function rock(x,z,s){const r=add(new THREE.IcosahedronGeometry(s,1),stone,x,.48*s,z);r.scale.set(1.4,.65,1.15);blocks.push({x,z,r:s})}
const ground=add(new THREE.PlaneGeometry(174,174,32,32),sand,0,-.03,0);ground.rotation.x=-Math.PI/2;
const water=add(new THREE.PlaneGeometry(520,520),sea,0,-.37,0);water.rotation.x=-Math.PI/2;
const foam=new THREE.MeshBasicMaterial({color:0xd8f4e8,transparent:true,opacity:.48,side:THREE.DoubleSide});
for(let i=0;i<16;i++){
 const angle=i*Math.PI/8;
 const strip=add(new THREE.PlaneGeometry(13,.18),foam,Math.cos(angle)*85,-.012,Math.sin(angle)*85);
 strip.rotation.set(-Math.PI/2,0,angle);
}
const houses=[[-19,-13],[18,-20],[-12,28],[28,12],[-33,13],[5,-34]];
houses.forEach(([x,z],i)=>hut(x,z,i%2?.85:1.1));
let seed=457;function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296}
for(let i=0;i<155;i++){
 const x=(rand()-.5)*160,z=(rand()-.5)*160;
 if(Math.hypot(x,z)<11||houses.some(([hx,hz])=>Math.hypot(x-hx,z-hz)<9))continue;
 if(i%10===0)rock(x,z,.8+rand()*2);else if(i%4===0)bush(x,z,.7+rand());else palm(x,z,4+rand()*7);
}
for(let i=0;i<16;i++){const x=(rand()-.5)*120,z=(rand()-.5)*120;cube(x,.08,z,1,.16,3,wood)}
// Light tropical haze and gentle water shimmer, with no expensive postprocessing.
const skyGlow=new THREE.MeshBasicMaterial({color:0xfff4d4,transparent:true,opacity:.55});
add(new THREE.SphereGeometry(4,12,8),skyGlow,-115,87,-170);
const move={x:0,y:0},stick=document.querySelector('#stick'),knob=document.querySelector('#knob');let stickId=null;
function stickMove(e){const r=stick.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),length=Math.max(1,Math.hypot(dx,dy)),m=Math.min(1,length/44);move.x=dx/length*m;move.y=dy/length*m;knob.style.transform=`translate(${move.x*42}px,${move.y*42}px)`}
stick.addEventListener('pointerdown',e=>{stickId=e.pointerId;stick.setPointerCapture(stickId);stickMove(e)});stick.addEventListener('pointermove',e=>{if(stickId===e.pointerId)stickMove(e)});function stop(e){if(stickId!==e.pointerId)return;stickId=null;move.x=move.y=0;knob.style.transform=''}stick.addEventListener('pointerup',stop);stick.addEventListener('pointercancel',stop);
let yaw=0,pitch=0,lookId=null,oldX=0,oldY=0;const look=document.querySelector('#look');look.addEventListener('pointerdown',e=>{lookId=e.pointerId;oldX=e.clientX;oldY=e.clientY;look.setPointerCapture(lookId)});look.addEventListener('pointermove',e=>{if(e.pointerId!==lookId)return;yaw-=(e.clientX-oldX)*.004;pitch=Math.max(-1.3,Math.min(1.3,pitch-(e.clientY-oldY)*.004));oldX=e.clientX;oldY=e.clientY});look.addEventListener('pointerup',()=>lookId=null);look.addEventListener('pointercancel',()=>lookId=null);
const keys=new Set();window.addEventListener('keydown',e=>keys.add(e.key.toLowerCase()));window.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));let vy=0,ground=true;document.querySelector('#jump').addEventListener('pointerdown',e=>{e.preventDefault();if(ground){vy=5.7;ground=false}});
let prev=performance.now();function frame(now){requestAnimationFrame(frame);const dt=Math.min((now-prev)/1000,.05);prev=now;const dx=move.x+Number(keys.has('d'))-Number(keys.has('a')),dz=move.y+Number(keys.has('s'))-Number(keys.has('w'));const nx=camera.position.x+(Math.cos(yaw)*dx+Math.sin(yaw)*dz)*7*dt,nz=camera.position.z+(-Math.sin(yaw)*dx+Math.cos(yaw)*dz)*7*dt;if(Math.abs(nx)<82&&Math.abs(nz)<82&&!blocks.some(o=>Math.hypot(nx-o.x,nz-o.z)<o.r+.4)){camera.position.x=nx;camera.position.z=nz}if(!ground){vy-=14*dt;camera.position.y+=vy*dt;if(camera.position.y<1.75){camera.position.y=1.75;vy=0;ground=true}}camera.rotation.order='YXZ';camera.rotation.y=yaw;camera.rotation.x=pitch;water.material.opacity=.85+Math.sin(now*.0006)*.035;renderer.render(scene,camera)}
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});status.hidden=true;requestAnimationFrame(frame);
}catch(error){status.textContent='No se pudo cargar el motor 3D: '+error.message}
