import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js';
const status=document.querySelector('#status');
try {
const scene=new THREE.Scene();scene.background=new THREE.Color('#91d6ed');scene.fog=new THREE.FogExp2(0x91d6ed,.008);
const camera=new THREE.PerspectiveCamera(74,innerWidth/innerHeight,.1,440);camera.position.set(0,1.75,14);
const renderer=new THREE.WebGLRenderer({antialias:false,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);renderer.outputColorSpace=THREE.SRGBColorSpace;document.body.prepend(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xe8f7ff,0x687d55,2.2));const sunlight=new THREE.DirectionalLight(0xffecc8,2);sunlight.position.set(-30,55,-35);scene.add(sunlight);
const mat=(c)=>new THREE.MeshStandardMaterial({color:c,roughness:1});const sand=mat(0xe9d6a8),wood=mat(0x785033),thatch=mat(0x98814e),leaf=mat(0x327c39),leaf2=mat(0x4d964b),stone=mat(0x99968c),sea=new THREE.MeshStandardMaterial({color:0x18b9c8,roughness:.4,transparent:true,opacity:.88});
function add(geometry,material,x,y,z){const mesh=new THREE.Mesh(geometry,material);mesh.position.set(x,y,z);scene.add(mesh);return mesh}
function cube(x,y,z,w,h,d,m){return add(new THREE.BoxGeometry(w,h,d),m,x,y,z)}
function cone(x,y,z,r,h,m,n=6){return add(new THREE.ConeGeometry(r,h,n),m,x,y,z)}
function palm(x,z,h){add(new THREE.CylinderGeometry(.14,.28,h,7),wood,x,h/2,z);for(let j=0;j<8;j++){const a=j*Math.PI/4;const f=add(new THREE.ConeGeometry(.8,4.8,4),j%2?leaf:leaf2,x+Math.cos(a)*1.4,h-.3,z+Math.sin(a)*1.4);f.rotation.set(Math.PI/2.9,0,a)}}
function bush(x,z,s){for(let i=0;i<4;i++)add(new THREE.IcosahedronGeometry(s*.65,0),i%2?leaf:leaf2,x+(i%2)*s*.5,s*.5,z+(i>>1)*s*.5)}
const blocks=[];function hut(x,z,s=1){cube(x,1.3*s,z,5*s,2.6*s,4*s,wood);const roof=cone(x,4*s,z,4*s,2.7*s,thatch,4);roof.rotation.y=Math.PI/4;cube(x,1*s,z+2.02*s,1.1*s,2*s,.08,mat(0x2b2219));blocks.push({x,z,r:3.5*s})}
function rock(x,z,s){const r=add(new THREE.IcosahedronGeometry(s,1),stone,x,.5*s,z);r.scale.set(1.3,.7,1);blocks.push({x,z,r:s})}
cube(0,-.25,0,170,.5,170,sand);cube(0,-.7,0,490,.3,490,sea);
const houses=[[-19,-13],[18,-20],[-12,28],[28,12],[-33,13],[5,-34]];houses.forEach(([x,z],i)=>hut(x,z,i%2?.85:1.1));
let seed=457;function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296}
for(let i=0;i<125;i++){const x=(rand()-.5)*150,z=(rand()-.5)*150;if(Math.hypot(x,z)<11||houses.some(([hx,hz])=>Math.hypot(x-hx,z-hz)<9))continue;if(i%8===0)rock(x,z,1+rand()*2);else if(i%4===0)bush(x,z,1+rand());else palm(x,z,5+rand()*5)}
for(let i=0;i<15;i++)cube((rand()-.5)*125,.08,(rand()-.5)*125,1,.16,3,wood);
const move={x:0,y:0},stick=document.querySelector('#stick'),knob=document.querySelector('#knob');let stickId=null;
function stickMove(e){const r=stick.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),length=Math.max(1,Math.hypot(dx,dy)),m=Math.min(1,length/44);move.x=dx/length*m;move.y=dy/length*m;knob.style.transform=`translate(${move.x*42}px,${move.y*42}px)`}
stick.addEventListener('pointerdown',e=>{stickId=e.pointerId;stick.setPointerCapture(stickId);stickMove(e)});stick.addEventListener('pointermove',e=>{if(stickId===e.pointerId)stickMove(e)});function stop(e){if(stickId!==e.pointerId)return;stickId=null;move.x=move.y=0;knob.style.transform=''}stick.addEventListener('pointerup',stop);stick.addEventListener('pointercancel',stop);
let yaw=0,pitch=0,lookId=null,oldX=0,oldY=0;const look=document.querySelector('#look');look.addEventListener('pointerdown',e=>{lookId=e.pointerId;oldX=e.clientX;oldY=e.clientY;look.setPointerCapture(lookId)});look.addEventListener('pointermove',e=>{if(e.pointerId!==lookId)return;yaw-=(e.clientX-oldX)*.004;pitch=Math.max(-1.3,Math.min(1.3,pitch-(e.clientY-oldY)*.004));oldX=e.clientX;oldY=e.clientY});look.addEventListener('pointerup',()=>lookId=null);look.addEventListener('pointercancel',()=>lookId=null);
const keys=new Set();window.addEventListener('keydown',e=>keys.add(e.key.toLowerCase()));window.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));let vy=0,ground=true;document.querySelector('#jump').addEventListener('pointerdown',e=>{e.preventDefault();if(ground){vy=5.7;ground=false}});
let prev=performance.now();function frame(now){requestAnimationFrame(frame);const dt=Math.min((now-prev)/1000,.05);prev=now;const dx=move.x+Number(keys.has('d'))-Number(keys.has('a')),dz=move.y+Number(keys.has('s'))-Number(keys.has('w'));const nx=camera.position.x+(Math.cos(yaw)*dx+Math.sin(yaw)*dz)*7*dt,nz=camera.position.z+(-Math.sin(yaw)*dx+Math.cos(yaw)*dz)*7*dt;if(Math.abs(nx)<82&&Math.abs(nz)<82&&!blocks.some(o=>Math.hypot(nx-o.x,nz-o.z)<o.r+.4)){camera.position.x=nx;camera.position.z=nz}if(!ground){vy-=14*dt;camera.position.y+=vy*dt;if(camera.position.y<1.75){camera.position.y=1.75;vy=0;ground=true}}camera.rotation.order='YXZ';camera.rotation.y=yaw;camera.rotation.x=pitch;renderer.render(scene,camera)}
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});status.hidden=true;requestAnimationFrame(frame);
}catch(error){status.textContent='No se pudo cargar el motor 3D: '+error.message}
