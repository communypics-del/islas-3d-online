import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js';
const status=document.querySelector('#status');
try {
const scene=new THREE.Scene();scene.background=new THREE.Color('#91d6ed');scene.fog=new THREE.FogExp2(0x91d6ed,.008);
const camera=new THREE.PerspectiveCamera(74,innerWidth/innerHeight,.1,440);camera.position.set(0,1.75,14);
const renderer=new THREE.WebGLRenderer({antialias:false,powerPreference:'high-performance'});
const qualitySelect=document.querySelector('#quality');
const allowedQualities=['low','medium','high'];
let quality=allowedQualities.includes(localStorage.getItem('peefeetoo-quality'))?localStorage.getItem('peefeetoo-quality'):'medium';
const profiles={low:{pixel:1,vegetation:.45,detail:false,shadows:false},medium:{pixel:1.35,vegetation:.78,detail:true,shadows:false},high:{pixel:1.75,vegetation:1,detail:true,shadows:true}};
qualitySelect.value=quality;
const cap=()=>Math.min(devicePixelRatio||1,profiles[quality].pixel);
renderer.setPixelRatio(cap());renderer.setSize(innerWidth,innerHeight);renderer.outputColorSpace=THREE.SRGBColorSpace;document.body.prepend(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xe8f7ff,0x687d55,2.2));const sunlight=new THREE.DirectionalLight(0xffecc8,2);sunlight.position.set(-30,55,-35);scene.add(sunlight);
sunlight.castShadow=profiles[quality].shadows;
renderer.shadowMap.enabled=profiles[quality].shadows;
renderer.shadowMap.type=THREE.PCFSoftShadowMap;
sunlight.shadow.mapSize.set(1024,1024);
sunlight.shadow.camera.left=-48;sunlight.shadow.camera.right=48;
sunlight.shadow.camera.top=48;sunlight.shadow.camera.bottom=-48;
sunlight.shadow.camera.near=.5;sunlight.shadow.camera.far=180;
const environmentalDetails=[];
function detail(mesh){environmentalDetails.push(mesh);mesh.visible=profiles[quality].detail;return mesh}
qualitySelect.addEventListener('change',()=>{
 quality=allowedQualities.includes(qualitySelect.value)?qualitySelect.value:'medium';
 localStorage.setItem('peefeetoo-quality',quality);
 renderer.setPixelRatio(cap());renderer.setSize(innerWidth,innerHeight);
 renderer.shadowMap.enabled=profiles[quality].shadows;
 sunlight.castShadow=profiles[quality].shadows;
 environmentalDetails.forEach(m=>m.visible=profiles[quality].detail);
});

// Procedural, tileable textures: locally generated; no additional downloads.
function texture(base, flecks, count=1100){
 const c=document.createElement('canvas');c.width=c.height=256;const ctx=c.getContext('2d');
 ctx.fillStyle=base;ctx.fillRect(0,0,256,256);
 let n=873;const rnd=()=>((n=(Math.imul(n,1664525)+1013904223)>>>0)/4294967296);
 for(let i=0;i<count;i++){ctx.globalAlpha=.07+rnd()*.22;ctx.fillStyle=flecks[Math.floor(rnd()*flecks.length)];ctx.fillRect(rnd()*256,rnd()*256,.5+rnd()*4,.5+rnd()*6)}
 ctx.globalAlpha=1;const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),4);return t;
}
const sandTex=texture('#e9d7ac',['#fff1d1','#a68d6b','#f8e4bd'],2200);sandTex.repeat.set(19,19);
const woodTex=texture('#93643c',['#38251b','#caa06c','#6a4529'],1500);woodTex.repeat.set(2,2);
const thatchTex=texture('#b49b5f',['#4c4329','#dfc58a','#8b713f'],2500);
const stoneTex=texture('#a29f92',['#555b57','#e4d9be','#747569'],1800);
const mat=(c)=>new THREE.MeshStandardMaterial({color:c,roughness:1});
const sand=new THREE.MeshStandardMaterial({map:sandTex,roughness:1}),wood=new THREE.MeshStandardMaterial({map:woodTex,roughness:.95});
const thatch=new THREE.MeshStandardMaterial({map:thatchTex,side:THREE.DoubleSide,roughness:1});
const leaf=new THREE.MeshStandardMaterial({color:0x287a42,side:THREE.DoubleSide,roughness:.85});
const leaf2=new THREE.MeshStandardMaterial({color:0x4b9651,side:THREE.DoubleSide,roughness:.85});
const stone=new THREE.MeshStandardMaterial({map:stoneTex,roughness:1});
const sea=new THREE.MeshStandardMaterial({color:0x25b6c3,metalness:.05,roughness:.27,transparent:true,opacity:.89});
function add(geometry,material,x,y,z){const mesh=new THREE.Mesh(geometry,material);mesh.position.set(x,y,z);scene.add(mesh);return mesh}
function cube(x,y,z,w,h,d,m){return add(new THREE.BoxGeometry(w,h,d),m,x,y,z)}
// Curved, tapered palm leaves: lightweight mesh geometry, not rectangular cards.
const palmLeafGeometry=(()=>{
 const vertices=[],indices=[],uv=[];
 const segments=9;
 for(let i=0;i<=segments;i++){
  const t=i/segments,spread=Math.sin(Math.PI*t)*.64;
  const bend=t*3.5,drop=.20*Math.sin(t*Math.PI)+t*t*.9;
  vertices.push(-spread,-drop,-bend,spread,-drop,-bend);
  uv.push(0,t,1,t);
  if(i<segments){const k=i*2;indices.push(k,k+1,k+2,k+1,k+3,k+2)}
 }
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
 g.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();return g;
})();
const palmLeaves=leaf.clone();palmLeaves.side=THREE.DoubleSide;
function palm(x,z,h){
 const trunk=add(new THREE.CylinderGeometry(.14,.34,h,9,5),wood,x,h/2,z);
 trunk.rotation.z=(x%7)*.012;
 for(let j=0;j<11;j++){
  const blade=new THREE.Mesh(palmLeafGeometry,j%3?leaf2:palmLeaves);
  blade.position.set(x,h-.1,z);blade.rotation.y=j*Math.PI*2/11;
  blade.rotation.x=-.08+(j%3)*.09;
  blade.scale.set(.85+h*.05,1,.9+h*.09);
  scene.add(blade);
 }
 for(let k=0;k<3;k++)add(new THREE.SphereGeometry(.22,6,5),mat(0x82622b),x+.25*Math.cos(k*2.1),h-.3,z+.25*Math.sin(k*2.1));
}
function bush(x,z,s){for(let i=0;i<5;i++)add(new THREE.IcosahedronGeometry(s*.53,1),i%2?leaf:leaf2,x+(i%3-1)*s*.38,s*.43,z+Math.floor(i/3)*s*.5)}
const blocks=[];
function hut(x,z,s=1){
 const w=5*s,d=4*s;
 // Open timber hut with posts, woven wall panels and visible door.
 cube(x,1.5*s,z-d/2,w,3*s,.16*s,wood);
 for(const xx of [-w/2,w/2])for(const zz of [-d/2,d/2])cube(x+xx,1.8*s,z+zz,.24*s,3.6*s,.24*s,wood);
 cube(x,1.4*s,z+d/2,w,2.8*s,.12*s,wood);
 cube(x,1.1*s,z+d/2+.09*s,1.2*s,2.2*s,.06*s,mat(0x30221a));
 for(const side of [-1,1])cube(x+side*w/2,1.3*s,z,.12*s,2.6*s,d,wood);
 const roof=add(new THREE.ConeGeometry(4.2*s,2.4*s,4),thatch,x,4.05*s,z);roof.rotation.y=Math.PI/4;
 // Overhanging thatch fringe and roof ridge.
 for(let k=0;k<4;k++)for(let side of [-1,1]){
   const fringe=detail(add(new THREE.ConeGeometry(.12*s,.8*s,4),thatch,x+(k-1.5)*1.2*s,3.05*s,z+side*2.15*s));
   fringe.rotation.z=.18*(k-1.5);
 }
 detail(cube(x,4.75*s,z,5.6*s,.13*s,.16*s,wood));
 for(let i=0;i<8;i++)cube(x-w/2+i*.72*s,2.9*s,z+d/2,.08*s,.17*s,.4*s,wood);
 blocks.push({x,z,r:3.4*s});
}
function rock(x,z,s){const r=add(new THREE.IcosahedronGeometry(s,1),stone,x,.48*s,z);r.scale.set(1.4,.65,1.15);blocks.push({x,z,r:s})}
const ground=add(new THREE.PlaneGeometry(174,174,32,32),sand,0,-.03,0);ground.rotation.x=-Math.PI/2;
const water=add(new THREE.PlaneGeometry(520,520),sea,0,-.37,0);water.rotation.x=-Math.PI/2;
const foam=new THREE.MeshBasicMaterial({color:0xd8f4e8,transparent:true,opacity:.48,side:THREE.DoubleSide});
for(let i=0;i<16;i++){
 const angle=i*Math.PI/8;
 const strip=add(new THREE.PlaneGeometry(13,.18),foam,Math.cos(angle)*85,-.012,Math.sin(angle)*85);
 strip.rotation.set(-Math.PI/2,0,angle);
}
const houses=[[-19,-13],[18,-20],[-12,28],[28,12],[-33,13],[5,-34]];
houses.forEach(([x,z],i)=>hut(x,z,i%2?.85:1.1));
let seed=457;function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296}
for(let i=0;i<Math.round(155*profiles[quality].vegetation);i++){
 const x=(rand()-.5)*160,z=(rand()-.5)*160;
 if(Math.hypot(x,z)<11||houses.some(([hx,hz])=>Math.hypot(x-hx,z-hz)<9))continue;
 if(i%10===0)rock(x,z,.8+rand()*2);else if(i%4===0)bush(x,z,.7+rand());else palm(x,z,4+rand()*7);
}
for(let i=0;i<16;i++){const x=(rand()-.5)*120,z=(rand()-.5)*120;cube(x,.08,z,1,.16,3,wood)}
// Beach details: instanced tufts, scattered driftwood and shells (single draw calls).
const grassMat=new THREE.MeshStandardMaterial({color:0x769a4d,side:THREE.DoubleSide,roughness:1});
const grassBlade=new THREE.ConeGeometry(.13,.72,3);
const tufts=new THREE.InstancedMesh(grassBlade,grassMat,quality==='low'?220:quality==='medium'?460:760);
const grassDummy=new THREE.Object3D();
for(let i=0;i<tufts.count;i++){
 const x=(rand()-.5)*159,z=(rand()-.5)*159;
 grassDummy.position.set(x,.31,z);grassDummy.rotation.y=rand()*6.283;
 const scale=.4+rand()*1.3;grassDummy.scale.set(scale,scale,scale);grassDummy.updateMatrix();
 tufts.setMatrixAt(i,grassDummy.matrix);
}
tufts.instanceMatrix.needsUpdate=true;scene.add(tufts);
const shellMat=new THREE.MeshStandardMaterial({color:0xf4e7d1,roughness:.88});
const shellGeo=new THREE.IcosahedronGeometry(.09,0);
const shells=new THREE.InstancedMesh(shellGeo,shellMat,quality==='low'?100:quality==='medium'?240:450);
for(let i=0;i<shells.count;i++){
 const a=rand()*6.283,r=48+rand()*33;
 grassDummy.position.set(Math.cos(a)*r,.03,Math.sin(a)*r);
 grassDummy.rotation.set(rand(),rand()*6.283,rand());
 grassDummy.scale.set(.6+rand()*1.5,.35,.8+rand()*1.4);grassDummy.updateMatrix();
 shells.setMatrixAt(i,grassDummy.matrix);
}
shells.instanceMatrix.needsUpdate=true;scene.add(shells);
// Shallow water colour gradient and translucent foam bands near the coast.
const shallowMaterial=new THREE.MeshBasicMaterial({color:0x7bd9c9,transparent:true,opacity:.27,depthWrite:false,side:THREE.DoubleSide});
const shallow=add(new THREE.RingGeometry(84,99,96),shallowMaterial,0,-.345,0);shallow.rotation.x=-Math.PI/2;
const deepWater=new THREE.MeshBasicMaterial({color:0x167f9c,transparent:true,opacity:.18,depthWrite:false,side:THREE.DoubleSide});
const deepRing=add(new THREE.RingGeometry(112,255,96),deepWater,0,-.338,0);deepRing.rotation.x=-Math.PI/2;
const rippleMat=new THREE.MeshBasicMaterial({color:0xe6fff4,transparent:true,opacity:.26,depthWrite:false,side:THREE.DoubleSide});
const ripples=[];
for(let i=0;i<24;i++){
 const a=i*2*Math.PI/24,r=84+rand()*7;
 const ripple=add(new THREE.PlaneGeometry(2.8+rand()*3,.08),rippleMat,Math.cos(a)*r,-.012,Math.sin(a)*r);
 ripple.rotation.set(-Math.PI/2,0,a);ripples.push(ripple);
}
// Light tropical haze and gentle water shimmer, with no expensive postprocessing.
const skyGlow=new THREE.MeshBasicMaterial({color:0xfff4d4,transparent:true,opacity:.55});
add(new THREE.SphereGeometry(4,12,8),skyGlow,-115,87,-170);
const move={x:0,y:0},stick=document.querySelector('#stick'),knob=document.querySelector('#knob');let stickId=null;
function stickMove(e){const r=stick.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),length=Math.max(1,Math.hypot(dx,dy)),m=Math.min(1,length/44);move.x=dx/length*m;move.y=dy/length*m;knob.style.transform=`translate(${move.x*42}px,${move.y*42}px)`}
stick.addEventListener('pointerdown',e=>{stickId=e.pointerId;stick.setPointerCapture(stickId);stickMove(e)});stick.addEventListener('pointermove',e=>{if(stickId===e.pointerId)stickMove(e)});function stop(e){if(stickId!==e.pointerId)return;stickId=null;move.x=move.y=0;knob.style.transform=''}stick.addEventListener('pointerup',stop);stick.addEventListener('pointercancel',stop);
let yaw=0,pitch=0,lookId=null,oldX=0,oldY=0;const look=document.querySelector('#look');look.addEventListener('pointerdown',e=>{lookId=e.pointerId;oldX=e.clientX;oldY=e.clientY;look.setPointerCapture(lookId)});look.addEventListener('pointermove',e=>{if(e.pointerId!==lookId)return;yaw-=(e.clientX-oldX)*.004;pitch=Math.max(-1.3,Math.min(1.3,pitch-(e.clientY-oldY)*.004));oldX=e.clientX;oldY=e.clientY});look.addEventListener('pointerup',()=>lookId=null);look.addEventListener('pointercancel',()=>lookId=null);
const keys=new Set();window.addEventListener('keydown',e=>keys.add(e.key.toLowerCase()));window.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));let vy=0,onGround=true;document.querySelector('#jump').addEventListener('pointerdown',e=>{e.preventDefault();if(onGround){vy=5.7;onGround=false}});

// Shooter 3D: independent mobile-friendly local match with AI opponents.
scene.add(camera);
const weapon=new THREE.Group();camera.add(weapon);weapon.position.set(.36,-.31,-.64);
const gunMetal=mat(0x26343b),gunGrip=mat(0x473e33),gunAccent=mat(0x171c1e);
function gunPart(w,h,d,x,y,z,m){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);mesh.position.set(x,y,z);weapon.add(mesh)}
gunPart(.13,.14,.55,0,0,-.14,gunMetal);gunPart(.17,.11,.23,0,.04,.02,gunAccent);gunPart(.075,.24,.11,0,-.16,.06,gunGrip);
gunPart(.07,.07,.22,0,.012,-.49,gunAccent);
const shotLight=new THREE.PointLight(0xffd77b,0,4);shotLight.position.set(0,.03,-.55);weapon.add(shotLight);
const enemies=[],botMaterial=mat(0xc95841),botDark=mat(0x253c37),botHead=mat(0xcba17c);
const botSpawns=[[-30,-24],[24,-32],[-38,24],[32,33],[10,-45],[-45,-8],[46,-10],[8,43],[-27,43]];
function enemyModel(){const g=new THREE.Group();const torso=new THREE.Mesh(new THREE.CylinderGeometry(.35,.43,1.05,8),botMaterial);torso.position.y=1.12;g.add(torso);const head=new THREE.Mesh(new THREE.SphereGeometry(.29,9,7),botHead);head.position.y=1.9;g.add(head);const helmet=new THREE.Mesh(new THREE.SphereGeometry(.305,9,6,0,Math.PI*2,0,Math.PI*.48),botDark);helmet.position.y=1.95;g.add(helmet);for(const x of [-.22,.22]){const leg=new THREE.Mesh(new THREE.CylinderGeometry(.13,.15,.65,6),botDark);leg.position.set(x,.34,0);g.add(leg)}const gun=new THREE.Mesh(new THREE.BoxGeometry(.16,.14,.75),gunMetal);gun.position.set(.33,1.25,-.4);g.add(gun);return g}
function freeSpot(x,z,r=1){return Math.abs(x)<79&&Math.abs(z)<79&&!blocks.some(b=>Math.hypot(x-b.x,z-b.z)<b.r+r)}
let botCounter=0;
function spawnBot(bot){for(let i=0;i<botSpawns.length;i++){const [x,z]=botSpawns[(botCounter++ +i)%botSpawns.length];if(freeSpot(x,z,1.5)&&Math.hypot(camera.position.x-x,camera.position.z-z)>10){bot.mesh.position.set(x,0,z);break}}bot.hp=100;bot.alive=true;bot.mesh.visible=true;bot.attack=1+rand()*1.2;bot.wander=rand()*6;bot.speed=1.3+rand()*1.2}
for(let i=0;i<8;i++){const mesh=enemyModel();scene.add(mesh);const bot={mesh,hp:100,alive:true,attack:0,wander:0,speed:1};spawnBot(bot);enemies.push(bot)}
let hp=100,ammo=24,reserve=144,kills=0,deaths=0,shots=0,hits=0,reloading=false,reloadUntil=0,invulnerableUntil=0,lastShot=0,matchEnd=performance.now()+300000,ended=false;
const ui={hp:document.querySelector('#healthValue'),hpbar:document.querySelector('#healthBar'),ammo:document.querySelector('#ammoValue'),score:document.querySelector('#scoreValue'),time:document.querySelector('#timeValue'),message:document.querySelector('#combatMessage'),fire:document.querySelector('#fire'),reload:document.querySelector('#reload'),result:document.querySelector('#result')};
const raycaster=new THREE.Raycaster(),center=new THREE.Vector2(0,0);let shooting=false;
function showMessage(msg){ui.message.textContent=msg;ui.message.hidden=false;clearTimeout(showMessage.timeout);showMessage.timeout=setTimeout(()=>ui.message.hidden=true,1100)}
function updateHud(now){ui.hp.textContent=Math.ceil(hp);ui.hpbar.style.width=hp+'%';ui.ammo.textContent=`${ammo} / ${reserve}`;ui.score.textContent=`${kills} BAJAS · ${deaths} MUERTES`;ui.time.textContent=`${Math.floor(Math.max(0,matchEnd-now)/60000)}:${String(Math.floor(Math.max(0,matchEnd-now)/1000)%60).padStart(2,'0')}`;ui.reload.disabled=reloading||reserve===0||ammo===24}
function reload(now=performance.now()){if(reloading||ammo===24||reserve===0||ended||hp===0)return;reloading=true;reloadUntil=now+1550;showMessage('RECARGANDO…')}
function fire(now=performance.now()){if(ended||hp===0||reloading||now-lastShot<150)return;if(ammo===0){reload(now);return}lastShot=now;ammo--;shots++;shotLight.intensity=3.5;weapon.position.z=-.53;
 camera.updateMatrixWorld(true);raycaster.setFromCamera(center,camera);raycaster.far=75;
 const targetMeshes=[];for(const b of enemies)if(b.alive)b.mesh.traverse(o=>{if(o.isMesh)targetMeshes.push(o)});
 const hit=raycaster.intersectObjects(targetMeshes,false)[0];if(hit){const bot=enemies.find(b=>{let p=hit.object;while(p&&p!==b.mesh)p=p.parent;return p===b.mesh});if(bot){hits++;bot.hp-=hit.object.geometry.type==='SphereGeometry'?75:38;if(bot.hp<=0){bot.alive=false;bot.mesh.visible=false;bot.respawn=now+2500+kills*15;kills++;showMessage('¡ELIMINACIÓN! +100')}else showMessage('IMPACTO')}}
 if(ammo===0&&reserve>0)reload(now+100)}
ui.fire.addEventListener('pointerdown',e=>{e.preventDefault();shooting=true;fire();ui.fire.setPointerCapture(e.pointerId)});for(const event of ['pointerup','pointercancel','lostpointercapture'])ui.fire.addEventListener(event,()=>shooting=false);
ui.reload.addEventListener('pointerdown',e=>{e.preventDefault();reload()});
window.addEventListener('keydown',e=>{if(e.code==='Space'&&onGround){vy=5.7;onGround=false}if(e.key.toLowerCase()==='r')reload();if(e.code==='Enter'&&ended)location.reload()});
const respawnPoints=[[0,14],[12,2],[-8,-4],[4,24]];
function playerRespawn(now){deaths++;hp=100;ammo=24;reserve=Math.max(reserve,48);const [x,z]=respawnPoints[deaths%respawnPoints.length];camera.position.set(x,1.75,z);invulnerableUntil=now+2200;showMessage('REAPARICISTE · 2 S DE PROTECCIÓN')}
function endMatch(){if(ended)return;ended=true;shooting=false;ui.result.hidden=false;ui.result.querySelector('#resultStats').textContent=`${kills} eliminaciones · ${deaths} muertes · ${shots?Math.round(hits/shots*100):0}% precisión`}
function updateCombat(now,dt){if(ended)return;if(now>=matchEnd){endMatch();return}if(reloading&&now>=reloadUntil){const n=Math.min(24-ammo,reserve);ammo+=n;reserve-=n;reloading=false}if(shooting)fire(now);shotLight.intensity=Math.max(0,shotLight.intensity-30*dt);weapon.position.z+=(-.64-weapon.position.z)*Math.min(1,dt*18);
 for(const b of enemies){if(!b.alive){if(now>b.respawn)spawnBot(b);continue}const p=b.mesh.position;const vx=camera.position.x-p.x,vz=camera.position.z-p.z,dist=Math.hypot(vx,vz);b.mesh.rotation.y=Math.atan2(-vx,-vz);b.wander-=dt;
 if(dist>4&&dist<50){const speed=b.speed*dt,tx=p.x+vx/dist*speed,tz=p.z+vz/dist*speed;if(freeSpot(tx,tz,.65)){p.x=tx;p.z=tz}}
 else if(dist>=50&&b.wander<=0){b.wander=2+rand()*3;const tx=p.x+(rand()-.5)*5,tz=p.z+(rand()-.5)*5;if(freeSpot(tx,tz,.7)){p.x=tx;p.z=tz}}
 if(dist<22&&now>invulnerableUntil){b.attack-=dt;if(b.attack<=0){b.attack=1.15+rand()*1.4;hp=Math.max(0,hp-(dist<9?13:7));if(hp===0)playerRespawn(now)}}
 }
 updateHud(now)
}

let prev=performance.now();function frame(now){requestAnimationFrame(frame);const dt=Math.min((now-prev)/1000,.05);prev=now;const dx=move.x+Number(keys.has('d'))-Number(keys.has('a')),dz=move.y+Number(keys.has('s'))-Number(keys.has('w'));const nx=camera.position.x+(Math.cos(yaw)*dx+Math.sin(yaw)*dz)*7*dt,nz=camera.position.z+(-Math.sin(yaw)*dx+Math.cos(yaw)*dz)*7*dt;if(Math.abs(nx)<82&&Math.abs(nz)<82&&!blocks.some(o=>Math.hypot(nx-o.x,nz-o.z)<o.r+.4)){camera.position.x=nx;camera.position.z=nz}if(!onGround){vy-=14*dt;camera.position.y+=vy*dt;if(camera.position.y<1.75){camera.position.y=1.75;vy=0;onGround=true}}camera.rotation.order='YXZ';camera.rotation.y=yaw;camera.rotation.x=pitch;water.material.opacity=.85+Math.sin(now*.0006)*.035;
 rippleMat.opacity=.19+.08*Math.sin(now*.001);
 updateCombat(now,dt);renderer.render(scene,camera)}
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});status.hidden=true;requestAnimationFrame(frame);
}catch(error){status.textContent='No se pudo cargar el motor 3D: '+error.message}
