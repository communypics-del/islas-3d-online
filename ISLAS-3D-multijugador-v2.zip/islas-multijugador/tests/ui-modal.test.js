import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
const dir=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const ui=fs.readFileSync(path.join(dir,'public/main.js'),'utf8');
const functions=ui.slice(ui.indexOf('function openModal('),ui.indexOf('function handleCard('));
function dialog(){
 let current={},next={},renderCount=0;
 const root={dataset:{modal:''},querySelector(){return null},get innerHTML(){return this._html||''},set innerHTML(html){
  this._html=html;renderCount++;
  next={};for(const id of ['bank-give','bank-want','trade-target','dev-resource','dev-res-a','dev-res-b']){
   const select=html.match(new RegExp(`<select[^>]+id="${id}"[^>]*>([\\s\\S]*?)<\\/select>`));if(!select)continue;
   const opts=[...select[1].matchAll(/<option value="([^"]+)"([^>]*)>/g)];
   next[id]={value:(opts.find(o=>o[2].includes('selected'))||opts[0])?.[1]||''};
  }current=next;
 }};
 const quote={textContent:'',classList:{toggle(){}},title:''},submit={disabled:false,title:''};
 const doc={body:{classList:{toggle(){}}},createElement(){return root},getElementById(id){return current[id]||null},querySelector(sel){if(sel==='#modal-root')return root;if(sel==='#bank-quote')return root.innerHTML.includes('id="bank-quote"')?quote:null;if(sel==='[data-action="bank-submit"]')return submit;return null}};
 const sandbox={document:doc,game:{mine:{hand:{wood:7,brick:2,wool:0,grain:0,ore:0},portRates:{wood:4,brick:3,wool:4,grain:4,ore:4}},bank:{wood:12,brick:12,wool:12,grain:12,ore:12},players:[]},keys:['wood','brick','wool','grain','ore'],resNames:{wood:'Madera',brick:'Arcilla',wool:'Lana',grain:'Trigo',ore:'Mineral'},resIcons:{wood:'🌲',brick:'🧱',wool:'🐑',grain:'🌾',ore:'⛰'},room:'TEST',modal:null,modalState:{},escapeHTML:s=>String(s),shareUrl:()=>'',$:doc.querySelector.bind(doc)};
 vm.createContext(sandbox);vm.runInContext(functions,sandbox);return {sandbox,doc,root,quote,submit,get renderCount(){return renderCount}};
}
test('la banca abre con recursos distintos y muestra el cálculo exacto',()=>{
 const a=dialog();vm.runInContext("openModal('bank')",a.sandbox);
 assert.equal(a.doc.getElementById('bank-give').value,'wood');assert.equal(a.doc.getElementById('bank-want').value,'brick');
 assert.match(a.quote.textContent,/Entregás 4 Madera/);assert.match(a.quote.textContent,/1 Arcilla/);assert.equal(a.submit.disabled,false);
});
test('los desplegables conservan identidad y selección ante una actualización SSE',()=>{
 const a=dialog();vm.runInContext("openModal('bank')",a.sandbox);const select=a.doc.getElementById('bank-want');
 select.value='ore';vm.runInContext("modalState['bank-want']='ore';renderModal()",a.sandbox);
 assert.equal(a.doc.getElementById('bank-want'),select,'No debe eliminar ni recrear el elemento select');
 assert.equal(select.value,'ore');assert.match(a.quote.textContent,/1 Mineral/);
 assert.equal(a.renderCount,1,'SSE no debería reconstruir el diálogo');
});
test('banca muestra mensajes específicos y bloquea confirmaciones inválidas',()=>{
 const a=dialog();vm.runInContext("openModal('bank')",a.sandbox);
 a.doc.getElementById('bank-give').value='brick';a.doc.getElementById('bank-want').value='ore';
 vm.runInContext("modalState['bank-give']='brick';modalState['bank-want']='ore';updateBankQuote()",a.sandbox);
 assert.equal(a.submit.disabled,true);assert.match(a.quote.textContent,/necesitás 3/);
 a.doc.getElementById('bank-want').value='brick';vm.runInContext('updateBankQuote()',a.sandbox);
 assert.equal(a.submit.disabled,true);assert.match(a.quote.textContent,/distinto/);
});
test('contadores y selecciones sobreviven redibujos deliberados de un intercambio entre jugadores',()=>{
 const a=dialog();a.sandbox.game.players=[{id:'uno',name:'Ana',me:true},{id:'dos',name:'Beto',me:false},{id:'tres',name:'Carla',me:false}];
 vm.runInContext("openModal('trade')",a.sandbox);
 a.doc.getElementById('trade-target').value='tres';vm.runInContext("modalState['trade-target']='tres';counter('give','wood',1)",a.sandbox);
 assert.equal(a.doc.getElementById('trade-target').value,'tres');assert.equal(a.sandbox.modalState.give.wood,1);
});
