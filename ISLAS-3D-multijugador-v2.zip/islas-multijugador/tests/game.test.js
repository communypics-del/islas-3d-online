import test from 'node:test';
import assert from 'node:assert/strict';
import {buildBoard,newGame,joinGame,startGame,applyAction,snapshot} from '../game.js';
function setup(n){const g=newGame('XYZ789','Anfitrión',6);for(let i=1;i<n;i++)joinGame(g,`Amigo ${i}`);startGame(g,g.host);
 let count=0;while(g.turn.phase==='setup'&&count++<n*6){const actorIndex=g.turn.setupStep<n?g.turn.setupStep:2*n-1-g.turn.setupStep;
  const p=g.players[actorIndex],s=snapshot(g,p.id),k=g.turn.setupMode;
  if(k==='settlement'){
   const vi=s.actions.settlement.positions[Math.floor(s.actions.settlement.positions.length/2)];assert.ok(Number.isInteger(vi),'Legal opening settlement');applyAction(g,p.id,{type:'placeSettlement',vertex:vi});
  } else {
   const ei=s.actions.road.positions[0];assert.ok(Number.isInteger(ei),'Legal opening road');applyAction(g,p.id,{type:'placeRoad',edge:ei});
  }
 }
 assert.equal(g.turn.phase,'roll');return g;
}
test('tableros válidos para grupos de hasta seis jugadores',()=>{
 const a=buildBoard(2),b=buildBoard(3);
 assert.equal(a.hexes.length,19);assert.equal(b.hexes.length,30);
 for(const board of [a,b]){
  assert.ok(board.vertices.length>40);assert.ok(board.edges.every(e=>board.vertices[e.a].edges.includes(e.id)&&board.vertices[e.b].edges.includes(e.id)));
  assert.ok(board.hexes.some(h=>h.type==='desert'));assert.ok(board.vertices.filter(v=>v.port).length>0);
 }
});
test('cuatro jugadores realizan colocación inicial en orden serpiente y reciben recursos',()=>{
 const g=setup(4);assert.equal(g.players.length,4);
 assert.ok(g.players.every(p=>p.settlements.length===2&&p.roads.length===2));assert.ok(g.players.some(p=>Object.values(p.hand).some(v=>v>0)));
 assert.equal(g.turn.index,0);assert.equal(g.turn.turnNumber,1);
});
test('seis jugadores realizan colocación inicial y pasan a turnos emparejados',()=>{
 const g=setup(6);assert.equal(g.board.hexes.length,30);
 applyAction(g,g.players[0].id,{type:'roll'});
 if(g.turn.phase==='discard')for(const id of Object.keys(g.turn.pendingDiscard)){const cards={};let remaining=g.turn.pendingDiscard[id];for(const[k,n]of Object.entries(g.players.find(p=>p.id===id).hand)){const c=Math.min(n,remaining);cards[k]=c;remaining-=c;}applyAction(g,id,{type:'discard',cards})}
 if(g.turn.phase==='robber')applyAction(g,g.players[0].id,{type:'moveRobber',hex:g.board.hexes.find(h=>h.id!==g.board.robber).id});
 if(g.turn.phase==='steal')applyAction(g,g.players[0].id,{type:'steal',target:g.turn.stealVictims[0]});
 assert.equal(g.turn.phase,'main');assert.throws(()=>applyAction(g,g.players[3].id,{type:'endTurn'}),/No es tu turno/);
 applyAction(g,g.players[0].id,{type:'endTurn'});assert.equal(g.turn.secondary,true);
 assert.equal(snapshot(g,g.players[3].id).active,true);
 applyAction(g,g.players[3].id,{type:'endTurn'});
 assert.equal(g.turn.index,1);assert.equal(g.turn.secondary,false);
});
test('las manos y cartas privadas no se filtran a otros jugadores',()=>{
 const g=setup(2);g.players[0].hand.ore=12;g.players[0].dev.push({id:'secret',type:'vp',boughtTurn:0});
 const view=snapshot(g,g.players[1].id);assert.equal(view.players[0].resources,Object.values(g.players[0].hand).reduce((a,b)=>a+b,0));
 assert.equal(JSON.stringify(view).includes('secret'),false);
 assert.equal(JSON.stringify(view).includes('"ore":12'),false);
});
test('turno con 7 exige descarte correcto y movimiento del ladrón',()=>{
 const g=setup(2);for(const p of g.players){p.hand={wood:8,brick:0,wool:0,grain:0,ore:0}}
 const random=Math.random;let counter=0;
 Math.random=()=>{counter++;return counter%2===1?.4:.57};
 try{applyAction(g,g.players[0].id,{type:'roll'})}finally{Math.random=random}
 assert.deepEqual(g.turn.rolled,[3,4]);assert.equal(g.turn.phase,'discard');
 assert.throws(()=>applyAction(g,g.players[0].id,{type:'discard',cards:{wood:3}}),/exactamente/);
 for(const p of g.players)applyAction(g,p.id,{type:'discard',cards:{wood:4}});
 assert.equal(g.turn.phase,'robber');
 applyAction(g,g.players[0].id,{type:'moveRobber',hex:g.board.hexes.find(h=>h.id!==g.board.robber).id});if(g.turn.phase==='steal')applyAction(g,g.players[0].id,{type:'steal',target:g.turn.stealVictims[0]});
 assert.equal(g.turn.phase,'main');
});
test('construcción y comercio bancario validados en servidor',()=>{
 const g=setup(3);g.players[0].hand={wood:6,brick:5,wool:6,grain:7,ore:7};g.bank={wood:19,brick:19,wool:19,grain:19,ore:19};
 const prevRandom=Math.random;Math.random=()=>.82;try{applyAction(g,g.players[0].id,{type:'roll'})}finally{Math.random=prevRandom}if(g.turn.phase==='discard')for(const id of Object.keys(g.turn.pendingDiscard)){const p=g.players.find(q=>q.id===id);let remaining=g.turn.pendingDiscard[id];const cards={};for(const k of Object.keys(p.hand)){cards[k]=Math.min(remaining,p.hand[k]);remaining-=cards[k]}applyAction(g,id,{type:'discard',cards})}
 if(g.turn.phase==='robber')applyAction(g,g.players[0].id,{type:'moveRobber',hex:g.board.hexes.find(h=>h.id!==g.board.robber).id});
 if(g.turn.phase==='steal')applyAction(g,g.players[0].id,{type:'steal',target:g.turn.stealVictims[0]});
 const s=snapshot(g,g.players[0].id);const edge=s.actions.road.positions[0];assert.ok(Number.isInteger(edge));applyAction(g,g.players[0].id,{type:'placeRoad',edge});
 assert.equal(g.players[0].roads.length,3);
 applyAction(g,g.players[0].id,{type:'bankTrade',give:'wood',want:'ore'});
 assert.equal(g.players[0].hand.ore>=7,true);
 assert.throws(()=>applyAction(g,g.players[1].id,{type:'placeRoad',edge}),/No es tu turno/);
});

test('tokens secretos de asiento no se exponen en snapshots públicos',()=>{
 const g=newGame('PRIVADOS','Ana',4),p2=joinGame(g,'Beto');
 const s=snapshot(g,g.players[0].id);
 assert.notEqual(s.players[1].id,p2.id);
 assert.notEqual(s.players[0].id,g.players[0].id);
 assert.notEqual(s.me,g.players[0].id);
 assert.ok(!JSON.stringify(s).includes(p2.id));
});
