import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {IslasScene} from '../public/scene3d.js';
import {buildBoard} from '../game.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../public');
const src=fs.readFileSync(path.join(root,'scene3d.js'),'utf8');
const ui=fs.readFileSync(path.join(root,'main.js'),'utf8');
test('la cámara del turno tiene vista elevada y se puede orbitar y acercar sin reiniciarse',()=>{
 const scene=Object.create(IslasScene.prototype);
 scene.angles={yaw:0,dist:1,height:1};scene.canvas={clientWidth:390,clientHeight:844};
 scene.game={players:[{me:false},{me:true}]};
 scene.fitView(true);
 assert.equal(scene.first,true);
 assert.ok(scene.angles.height>16);
 assert.ok(scene.angles.dist>8);
 assert.equal(scene.angles.yaw,Math.PI/3);
 assert.ok(scene.pan.every(Number.isFinite));
 const oldDistance=scene.angles.dist;
 scene.zoomIn();assert.ok(scene.angles.dist<oldDistance);
 scene.zoomOut();assert.ok(scene.angles.dist>0); // Órbita válida.
 scene.pan=[2,0,-1];scene.fitBoard();assert.ok(scene.pan.every(Number.isFinite));
 const smallMapDist=Math.hypot(scene.angles.dist,scene.angles.height-1);
 scene.game.board=buildBoard(6);
 scene.fitBoard();
 const bigMapDist=Math.hypot(scene.angles.dist,scene.angles.height-1);
 assert.ok(bigMapDist>smallMapDist,'Tablero grande necesita cámara más alejada');
 scene.canvas.clientWidth=1366;scene.canvas.clientHeight=768;scene.setOverview();
 assert.equal(scene.first,false);
 assert.ok(scene.currentEye().target[1]>scene.currentEye().look[1]+10);
});
test('arena, roca, bosque y arcilla tienen materiales y detalles físicos diferenciados',()=>{
 for(const material of ['sand','grass','forest','clay','crops','granite','bark','leaves','water','brick']){
   assert.ok(src.includes('MAT.'+material),`Material ${material}`);
 }
 for(const terrain of ['forest','hill','pasture','field','mountain','desert']){
   assert.ok(src.includes(`h.type==='${terrain}'`),`Terreno ${terrain}`);
 }
 assert.match(src,/rock\(x,y,z/);
 assert.match(src,/terrain\(x,y,z/);
 assert.match(src,/const radialBoundary=/);
});
test('controles de cámara visibles en pantalla y eventos enlazados',()=>{
 for(const action of ['camera-fit','camera-zoom-in','camera-zoom-out','overview','seat-view']){
  assert.ok(ui.includes(`data-action="${action}"`),`Botón ${action}`);
  assert.ok(ui.includes(`action==='${action}'`),`Handler ${action}`);
 }
});
