import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=join(dirname(fileURLToPath(import.meta.url)),'..','public');
const load=(name)=>readFileSync(join(root,name),'utf8');
test('la vista inmersiva incluye CSS a pantalla completa y sin scroll',()=>{
 const html=load('index.html'),css=load('immersive.css');
 assert.match(html,/immersive\.css/);assert.match(css,/height:100dvh/);
 assert.match(css,/overflow:hidden!important/);assert.match(css,/\.hud-controls/);
});
test('controles HUD, selecciones y cámara disponibles',()=>{
 const main=load('main.js');
 for(const feature of ['compactControls','compactResources','compactPlayers','toggle-panel','fullscreen','seat-view','overview','roll'])assert.ok(main.includes(feature),feature);
});
test('animación de dados y actualización selectiva de malla',()=>{
 const scene=load('scene3d.js');
 assert.match(scene,/renderDice\(time\)/);assert.match(scene,/rollDice\(values\)/);
 assert.doesNotMatch(scene,/stateKey=`\$\{game.version\}/);
});
