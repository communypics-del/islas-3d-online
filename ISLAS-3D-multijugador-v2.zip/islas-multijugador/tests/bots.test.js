import test from 'node:test';
import assert from 'node:assert/strict';
import {newGame,addBots,startGame,botDecision,applyAction,snapshot} from '../game.js';
test('modo online no incorpora bots; IA es independiente',()=>{
 const online=newGame('ON','Ana',4);assert.equal(online.players.length,1);assert.throws(()=>addBots(online,online.host,3));
 const g=newGame('AI','Ana',4);g.mode='ai';addBots(g,g.host,3,'hard');assert.equal(g.players.length,4);assert.equal(g.players.filter(p=>p.bot).length,3);assert.equal(snapshot(g,g.host).players.filter(p=>p.bot).length,3);
});
test('bots colocan poblados y carreteras durante toda la preparación',()=>{
 const g=newGame('AI','Ana',4);g.mode='ai';addBots(g,g.host,3);startGame(g,g.host);
 let turns=0;while(g.turn.phase==='setup'&&turns++<50){const n=g.players.length,idx=g.turn.setupStep<n?g.turn.setupStep:2*n-1-g.turn.setupStep,p=g.players[idx];let a;if(p.bot)a=botDecision(g,p.id);else {const snap=snapshot(g,p.id),kind=g.turn.setupMode;a={type:kind==='settlement'?'placeSettlement':'placeRoad',[kind==='settlement'?'vertex':'edge']:snap.actions[kind==='settlement'?'settlement':'road'].positions[0]};}assert.ok(a);applyAction(g,p.id,a);}
 assert.equal(g.turn.phase,'roll');assert.equal(g.players.every(p=>p.settlements.length===2&&p.roads.length===2),true);
});
