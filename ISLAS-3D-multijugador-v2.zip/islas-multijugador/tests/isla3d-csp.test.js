import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
const html=fs.readFileSync(new URL('../public/isla3d.html',import.meta.url),'utf8');
const server=fs.readFileSync(new URL('../server.js',import.meta.url),'utf8');
test('CSP allows inline importmap and diagnostic handler by sha256 hashes',()=>{
 const scripts=[...html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)].filter(x=>x[2]);
 assert.ok(scripts.some(x=>x[1].includes('importmap')));
 for(const x of scripts){const hash=createHash('sha256').update(x[2]).digest('base64');assert.ok(server.includes(`sha256-${hash}`),`CSP missing hash for ${x[1]}`)}
});
