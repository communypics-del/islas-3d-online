import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import net from 'node:net';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const DIR=path.dirname(fileURLToPath(import.meta.url));
const ROOT=path.resolve(DIR,'..');
async function unusedPort(){const s=net.createServer();s.listen(0,'127.0.0.1');await once(s,'listening');const p=s.address().port;s.close();await once(s,'close');return p}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
test('desconectar y reabrir la pestaña no elimina la sala', {timeout:20000}, async()=>{
 const port=await unusedPort(), folder=fs.mkdtempSync(path.join(os.tmpdir(),'islas-integration-'));
 const proc=spawn(process.execPath,['server.js'],{cwd:ROOT,env:{...process.env,PORT:String(port),ROOMS_FILE:path.join(folder,'rooms.json')},stdio:['ignore','ignore','pipe']});
 let stderr=''; proc.stderr.on('data',x=>stderr+=x.toString());
 const base=`http://127.0.0.1:${port}`;
 try {
   let ready=false;for(let i=0;i<60;i++){try{const r=await fetch(base+'/api/health');if(r.ok){ready=true;break}}catch{}await sleep(100)}
   assert.ok(ready,'Servidor inicia');
   const r=await fetch(base+'/api/create',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'Pepe',max:6})});
   assert.equal(r.status,200);const {room,token}=await r.json();
   for(let i=0;i<8;i++){
     const abort=new AbortController();const stream=await fetch(base+`/api/stream?room=${room}&token=${token}`,{signal:abort.signal});
     assert.equal(stream.status,200);const reader=stream.body.getReader();await reader.read();abort.abort();
     await sleep(15);
   }
   const guest=await fetch(base+`/api/lobby-info?room=${room}`);
   assert.equal(guest.status,200,'Enlace sigue siendo válido tras salir del navegador');
   const info=await guest.json();assert.equal(info.players[0].name,'Pepe');
   const state=await fetch(base+`/api/state?room=${room}&token=${token}`);
   assert.equal(state.status,200,'Anfitrión puede recuperar su asiento');
   const health=await fetch(base+'/api/health');assert.equal(health.status,200);
   assert.equal((await health.json()).rooms,1);
   assert.equal(proc.exitCode,null,`El servidor no debe caerse: ${stderr}`);
 } finally {proc.kill('SIGTERM');fs.rmSync(folder,{recursive:true,force:true});}
});
