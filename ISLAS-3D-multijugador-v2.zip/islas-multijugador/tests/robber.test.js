import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {newGame,joinGame,startGame,applyAction,snapshot} from '../game.js';
const DIR=path.dirname(fileURLToPath(import.meta.url));
const resourceCount=p=>Object.values(p.hand).reduce((s,n)=>s+n,0);
const blank=()=>({wood:0,brick:0,wool:0,grain:0,ore:0});
function sevenGame(players=3){
  const g=newGame('ROBBER','Primero',6);
  for(let i=1;i<players;i++)joinGame(g,`Rival ${i}`);
  startGame(g,g.host);
  // Isolated robbery rules: bypass setup, which is already integration-tested.
  g.turn.phase='roll';g.turn.index=0;g.turn.turnNumber=1;
  const prev=Math.random;let rolls=0;
  Math.random=()=>rolls++%2===0?.40:.57; // 3 + 4 = 7
  try{applyAction(g,g.players[0].id,{type:'roll'})}finally{Math.random=prev}
  assert.deepEqual(g.turn.rolled,[3,4]);
  assert.equal(g.turn.phase,'robber');
  return g;
}
function targetHex(g){return g.board.hexes.find(h=>h.id!==g.board.robber)}
test('7 ofrece mapa táctico, hexágonos legales y excluye la posición actual',()=>{
 const g=sevenGame();const s=snapshot(g,g.players[0].id),target=targetHex(g);
 assert.equal(s.actions.robber.enabled,true);
 assert.equal(s.actions.robber.positions.length,g.board.hexes.length-1);
 assert.ok(s.actions.robber.positions.includes(target.id));
 assert.ok(!s.actions.robber.positions.includes(g.board.robber));
 assert.deepEqual(snapshot(g,g.players[1].id).actions.robber.positions,[]);
 const current=g.board.robber;
 assert.throws(()=>applyAction(g,g.players[0].id,{type:'moveRobber',hex:current}),/otra casilla/);
 assert.equal(g.board.robber,current);
 assert.throws(()=>applyAction(g,g.players[1].id,{type:'moveRobber',hex:target.id}),/No es tu turno/);
});
test('7: tras mover ladrón muestra solo rivales adyacentes con cartas; roba del rival elegido',()=>{
 const g=sevenGame(4),target=targetHex(g);
 const around=g.board.vertices.filter(v=>v.hexes.includes(target.id));
 assert.ok(around.length>=3);
 for(const p of g.players)p.hand=blank();
 around[0].owner=g.players[1].id;
 around[1].owner=g.players[2].id;
 around[2].owner=g.players[3].id; // No cards; unavailable to rob.
 g.players[1].hand.wood=2;g.players[1].hand.grain=1;
 g.players[2].hand.ore=2;
 applyAction(g,g.players[0].id,{type:'moveRobber',hex:target.id});
 assert.equal(g.board.robber,target.id);assert.equal(g.turn.phase,'steal');
 assert.deepEqual(g.turn.stealVictims,[g.players[1].id,g.players[2].id]);
 const view=snapshot(g,g.players[0].id);
 assert.deepEqual(view.turn.stealVictims,[g.players[1].seatId,g.players[2].seatId]);
 assert.deepEqual(snapshot(g,g.players[1].id).turn.stealVictims,[]);
 assert.throws(()=>applyAction(g,g.players[0].id,{type:'steal',target:g.players[3].id}),/rival válido/);
 assert.throws(()=>applyAction(g,g.players[1].id,{type:'steal',target:g.players[2].id}),/No es tu turno/);
 const beforeThief=resourceCount(g.players[0]),beforeOne=resourceCount(g.players[1]),beforeTwo=resourceCount(g.players[2]);
 applyAction(g,g.players[0].id,{type:'steal',target:g.players[2].id});
 assert.equal(g.turn.phase,'main');assert.equal(resourceCount(g.players[0]),beforeThief+1);
 assert.equal(resourceCount(g.players[1]),beforeOne);assert.equal(resourceCount(g.players[2]),beforeTwo-1);
 assert.equal(g.players[0].hand.ore,1);
 assert.equal(g.turn.stealVictims.length,0);
 assert.throws(()=>applyAction(g,g.players[0].id,{type:'steal',target:g.players[1].id}),/Acción no reconocida/i);
});
test('7: con un único rival se pide elegirlo; sin rivales se puede continuar',()=>{
 const g=sevenGame(2),target=targetHex(g),around=g.board.vertices.find(v=>v.hexes.includes(target.id));
 g.players[0].hand=blank();g.players[1].hand=blank();g.players[1].hand.brick=1;
 around.owner=g.players[1].id;
 applyAction(g,g.players[0].id,{type:'moveRobber',hex:target.id});
 assert.equal(g.turn.phase,'steal');assert.deepEqual(g.turn.stealVictims,[g.players[1].id]);
 applyAction(g,g.players[0].id,{type:'steal',target:g.players[1].id});
 assert.equal(g.players[0].hand.brick,1);assert.equal(g.players[1].hand.brick,0);
 const h=sevenGame(2),hex=targetHex(h);applyAction(h,h.players[0].id,{type:'moveRobber',hex:hex.id});assert.equal(h.turn.phase,'main');
});
test('7 y carta caballero utilizan el mismo flujo de ladrón y robo',()=>{
 const g=sevenGame(2),h=targetHex(g);g.players[0].hand=blank();g.players[1].hand=blank();g.players[1].hand.ore=2;
 g.board.vertices.find(v=>v.hexes.includes(h.id)).owner=g.players[1].id;
 applyAction(g,g.players[0].id,{type:'moveRobber',hex:h.id});
 applyAction(g,g.players[0].id,{type:'steal',target:g.players[1].id});
 g.players[0].dev.push({id:'knight-test',type:'knight',boughtTurn:0});
 applyAction(g,g.players[0].id,{type:'playDev',card:'knight-test'});
 assert.equal(g.turn.phase,'robber');assert.ok(snapshot(g,g.players[0].id).actions.robber.enabled);
});
test('IU del 7: mapa táctico automático, selección validada y elección explícita de víctima',()=>{
 const main=fs.readFileSync(path.join(DIR,'../public/main.js'),'utf8');
 const scene=fs.readFileSync(path.join(DIR,'../public/scene3d.js'),'utf8');
 const css=fs.readFileSync(path.join(DIR,'../public/immersive.css'),'utf8');
 assert.match(main,/\['setup','robber'\]\.includes\(game.turn.phase\)/);
 assert.match(main,/const choice=setup\?game.turn.setupMode:robber\?'robber':mode/);
 assert.match(main,/game\.actions\?\.\[selected\]\?\.positions\?\.includes\(id\)/);
 assert.match(main,/function robberVictimPanel\(\)/);
 assert.match(main,/\$\{drawer\(\)\}\$\{tacticalPanel\(\)\}\$\{robberVictimPanel\(\)\}/);
 assert.match(main,/data-action=\\?"steal\\?"/);
 assert.match(scene,/if\(choice==='robber'\)return b\.hexes\.filter\(h=>positions\.includes\(h\.id\)\)/);
 assert.match(css,/\.robber-victim-layer/);
});
