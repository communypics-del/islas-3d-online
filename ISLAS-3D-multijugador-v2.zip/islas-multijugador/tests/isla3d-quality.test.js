import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
const js=fs.readFileSync(new URL('../public/isla3d.js',import.meta.url),'utf8');
const html=fs.readFileSync(new URL('../public/isla3d.html',import.meta.url),'utf8');
test('3D module has valid JavaScript syntax',()=>assert.doesNotThrow(()=>execFileSync(process.execPath,['--check',new URL('../public/isla3d.js',import.meta.url).pathname])));
test('medium is initial graphics quality with three presets',()=>{
 assert.match(js,/:'medium'/);for(const q of ['low','medium','high']){assert.match(js,new RegExp(q+':\\{pixel:'));assert.match(html,new RegExp('value="'+q+'"'))}
});
test('quality UI and 3D features are wired',()=>{
 for(const id of ['quality','status','fire','jump','reload'])assert.match(html,new RegExp('id="'+id+'"'));
 for(const feature of ['InstancedMesh','palmLeafGeometry','RingGeometry','renderer.setPixelRatio','localStorage.setItem'])assert.ok(js.includes(feature),feature);
});
