import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import net from 'node:net';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const sleep=t=>new Promise(r=>setTimeout(r,t));
async function unusedPort(){const s=net.createServer();s.listen(0,'127.0.0.1');await once(s,'listening');const port=s.address().port;s.close();await once(s,'close');return port}

test('flujo real: primera casa y primera carretera colocadas por el primer jugador', {timeout:20000}, async()=>{
  const port=await unusedPort(), folder=fs.mkdtempSync(path.join(os.tmpdir(),'islas-setup-'));
  const process=spawn(globalThis.process.execPath,['server.js'],{cwd:ROOT,env:{...globalThis.process.env,PORT:String(port),ROOMS_FILE:path.join(folder,'rooms.json')},stdio:'ignore'});
  const root=`http://127.0.0.1:${port}`;
  const post=async(url,body)=>{
    const res=await fetch(root+'/api/'+url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
    const text=await res.text();assert.equal(res.status,200,`La acción ${url} debe ser válida: ${text}`);
    // The success response is intentionally not re-read.
  };
  const state=async(room,token)=>{
    const res=await fetch(root+`/api/state?room=${room}&token=${token}`);
    assert.equal(res.status,200);return res.json();
  };
  try{
    for(let attempts=0;attempts<70;attempts++){try{if((await fetch(root+'/api/health')).ok)break}catch{}await sleep(50)}
    const create=await fetch(root+'/api/create',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'Anfitrión',max:2})});
    assert.equal(create.status,200);const {room,token}=await create.json();
    const join=await fetch(root+'/api/join',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'Invitado',room})});
    assert.equal(join.status,200);const guest=await join.json();
    await post('action',{room,token,action:{type:'start'}});
    const a=await state(room,token);assert.equal(a.turn.phase,'setup');assert.equal(a.turn.setupMode,'settlement');
    assert.ok(a.active);assert.ok(a.actions.settlement.positions.length>0);
    const vertex=a.actions.settlement.positions[0];
    await post('action',{room,token,action:{type:'placeSettlement',vertex}});
    const b=await state(room,token);
    assert.equal(b.turn.setupMode,'road');assert.equal(b.board.vertices[vertex].building,'settlement');assert.ok(b.actions.road.positions.length);
    const edge=b.actions.road.positions[0];
    await post('action',{room,token,action:{type:'placeRoad',edge}});
    const c=await state(room,token);
    assert.equal(c.board.edges[edge].owner,0);assert.equal(c.turn.index,1);assert.equal(c.turn.setupMode,'settlement');
    const d=await state(room,guest.token);assert.ok(d.active,'El segundo jugador ya puede colocar su casa');
  }finally{process.kill('SIGTERM');fs.rmSync(folder,{recursive:true,force:true})}
});

test('mapa táctico reacciona a intersecciones y carreteras sin arrastrar cámara',async()=>{
  const src=fs.readFileSync(path.join(ROOT,'public','main.js'),'utf8');
  const scene=fs.readFileSync(path.join(ROOT,'public','scene3d.js'),'utf8');
  const css=fs.readFileSync(path.join(ROOT,'public','immersive.css'),'utf8');
  for(const key of ['tacticalIsOpen','tacticalPanel','setPlacement','placementAllowed','tactical-open','tactical-close','confirm-placement'])assert.ok(src.includes(key),key);
  assert.match(src,/tacticalOpen===null\?\['setup','robber'\]\.includes\(game.turn.phase\)/);
  assert.match(src,/setPlacement\(point.dataset.map,Number\(point.dataset.id\)\)/);
  assert.match(scene,/if\(!this.dragging\|\|this.placementActive\(\)\)return/);
  assert.match(scene,/threshold=isTouch\?16:9/);
  assert.match(css,/\.tactical-board \[data-map\]/);
  assert.match(css,/@media\(max-height:590px\) and \(orientation:landscape\)/);
  assert.match(css,/@media\(max-width:440px\)/);
});
