import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {newGame,joinGame,startGame,applyAction,snapshot,RES} from '../game.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
function fullSetup(n=3){const g=newGame('FIXTURE','A',n);for(let i=1;i<n;i++)joinGame(g,`Jugador ${i+1}`);startGame(g,g.host);
 for(let step=0;step<n*4;step++){
  let index=g.turn.setupStep<n?g.turn.setupStep:2*n-1-g.turn.setupStep;
  const p=g.players[index],s=snapshot(g,p.id);const road=g.turn.setupMode==='road';
  const idx=s.actions[road?'road':'settlement'].positions[0];assert.ok(Number.isInteger(idx));
  applyAction(g,p.id,road?{type:'placeRoad',edge:idx}:{type:'placeSettlement',vertex:idx});
 }
 assert.equal(g.turn.phase,'roll');return g;
}
function mainPhase(g){
 // Force a non-seven roll: d1=d2=6 -> 12
 const old=Math.random;Math.random=()=>.9999999;try{applyAction(g,g.players[0].id,{type:'roll'})}finally{Math.random=old}
 assert.equal(g.turn.phase,'main');
}
function book(g){return {bank:{...g.bank},hands:g.players.map(p=>({...p.hand}))}}
function sameBook(g,b){assert.deepEqual(book(g),b)}

test('colocación ciega: no se filtran números, tipos, desierto, puertos ni recursos al cliente',()=>{
 for(const n of [2,3,4,5,6]){
  const g=newGame('BLIND'+n,'A',n);for(let i=1;i<n;i++)joinGame(g,'B'+i);startGame(g,g.host);
  for(const player of g.players){const s=snapshot(g,player.id);assert.equal(s.board.concealed,true);
   assert.ok(s.board.hexes.every(h=>h.type==='unknown'&&h.number===null));
   assert.equal(s.board.robber,null);assert.ok(s.board.vertices.every(v=>v.port===null));
   assert.ok(Object.values(s.mine.hand).every(x=>x===0));
   assert.ok(Object.values(s.mine.portRates).every(x=>x===4));
   assert.ok(Object.values(s.bank).every(x=>x=== (n>=5?29:19)));
  }
  let i=0;
  while(g.turn.phase==='setup'){
   assert.ok(i++<n*4+1,'initial setup terminates');
   const idx=g.turn.setupStep<n?g.turn.setupStep:2*n-1-g.turn.setupStep,p=g.players[idx];
   const road=g.turn.setupMode==='road',s=snapshot(g,p.id);
   const pick=s.actions[road?'road':'settlement'].positions[0];
   applyAction(g,p.id,road?{type:'placeRoad',edge:pick}:{type:'placeSettlement',vertex:pick});
   const revealed=snapshot(g,g.players[0].id);
   if(g.turn.phase==='setup'){
    assert.equal(revealed.board.concealed,true);
    assert.ok(revealed.board.hexes.every(h=>h.type==='unknown'&&h.number===null));
   }
  }
  assert.equal(i,n*4);const s=snapshot(g,g.players[0].id);
  assert.equal(s.board.concealed,false);assert.ok(s.board.hexes.some(h=>h.type==='forest'&&h.number));
  assert.ok(s.board.hexes.some(h=>h.type==='desert'));assert.notEqual(s.board.robber,null);
  assert.ok(s.board.vertices.some(v=>v.port));
 }
});

test('banca 4:1 entrega exactamente la tarifa y recibe exactamente una carta',()=>{
 const g=fullSetup(3);mainPhase(g);const p=g.players[0];
 p.hand.wood=9;p.hand.ore=0;g.bank.ore=5;
 const beforeBank={...g.bank};applyAction(g,p.id,{type:'bankTrade',give:'wood',want:'ore'});
 assert.equal(p.hand.wood,5);assert.equal(p.hand.ore,1);assert.equal(g.bank.wood,beforeBank.wood+4);assert.equal(g.bank.ore,4);
});

test('intercambio 3:1 mediante puerto genérico y 2:1 mediante puerto específico',()=>{
 const g=fullSetup(2);mainPhase(g);const p=g.players[0];
 g.board.vertices[p.settlements[0]].port='all';p.hand.wood=5;const oldWood=g.bank.wood;
 applyAction(g,p.id,{type:'bankTrade',give:'wood',want:'ore'});assert.equal(p.hand.wood,2);assert.equal(g.bank.wood,oldWood+3);
 g.board.vertices[p.settlements[0]].port='wood';p.hand.wood=5;
 applyAction(g,p.id,{type:'bankTrade',give:'wood',want:'wool'});assert.equal(p.hand.wood,3);
 assert.equal(snapshot(g,p.id).mine.portRates.wood,2);
});

test('banca no cobra cartas ni cierra turnos ante errores: recursos insuficientes, iguales o sin existencias',()=>{
 const g=fullSetup(2);mainPhase(g);const p=g.players[0];p.hand.wood=3;
 const b=book(g);assert.throws(()=>applyAction(g,p.id,{type:'bankTrade',give:'wood',want:'ore'}),/Necesitas/);sameBook(g,b);
 assert.throws(()=>applyAction(g,p.id,{type:'bankTrade',give:'wood',want:'wood'}),/distintos/);sameBook(g,b);
 g.bank.ore=0;const b2=book(g);p.hand.wood=6;const b3=book(g);
 assert.throws(()=>applyAction(g,p.id,{type:'bankTrade',give:'wood',want:'ore'}),/banca no tiene/);sameBook(g,b3);
});

test('banca no permite comerciar fuera del turno y jugadores mantienen manos privadas',()=>{
 const g=fullSetup(2);const p=g.players[0];p.hand.wood=9;
 assert.throws(()=>applyAction(g,p.id,{type:'bankTrade',give:'wood',want:'ore'}),/permitida/);
 mainPhase(g);assert.throws(()=>applyAction(g,g.players[1].id,{type:'bankTrade',give:'wood',want:'ore'}),/tu turno/);
 assert.ok(!JSON.stringify(snapshot(g,g.players[1].id)).includes(p.id));
});

test('intercambio entre jugadores: propuesta, rechazo, aceptación y conservación de recursos',()=>{
 const g=fullSetup(2);mainPhase(g);const [a,b]=g.players;
 a.hand.wood=5;b.hand.ore=4;
 applyAction(g,a.id,{type:'offerTrade',to:b.id,give:{wood:2},want:{ore:1}});
 assert.equal(snapshot(g,b.id).offer.to,b.seatId);
 applyAction(g,b.id,{type:'respondTrade',accept:false});assert.equal(g.offer,null);assert.equal(a.hand.wood,5);
 applyAction(g,a.id,{type:'offerTrade',to:b.id,give:{wood:2},want:{ore:1}});
 applyAction(g,b.id,{type:'respondTrade',accept:true});assert.equal(g.offer,null);
 assert.equal(a.hand.wood,3);assert.equal(a.hand.ore>=1,true);assert.equal(b.hand.wood>=2,true);assert.equal(b.hand.ore,3);
});

test('actualizaciones SSE no deben destruir desplegables de banca; texto UI incluye confirmación y cuotas',()=>{
 const ui=fs.readFileSync(path.join(root,'public','main.js'),'utf8');
 assert.match(ui,/root\.dataset\.modal===modal/);
 assert.match(ui,/modalState\[ev\.target\.id\]=ev\.target\.value/);
 assert.match(ui,/function bankQuote/);assert.match(ui,/id="bank-quote"/);
 assert.match(ui,/\['bankTrade','offerTrade','discard'/);
 const svg=ui.match(/function boardSVG\(\)[\s\S]*?function boardPane\(\)/)?.[0]||'';
 assert.match(svg,/b\.concealed/);assert.match(ui,/unknown:\x27#848881\x27/);
 const scene=fs.readFileSync(path.join(root,'public','scene3d.js'),'utf8');
 assert.match(scene,/if\(h\.type==='unknown'\)return/);
 assert.match(scene,/board\?\.concealed/);
});
