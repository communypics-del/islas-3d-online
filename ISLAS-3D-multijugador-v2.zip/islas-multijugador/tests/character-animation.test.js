import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const s=fs.readFileSync(new URL('../public/isla3d.js',import.meta.url),'utf8');
test('skinned character poses animate in gameplay',()=>{
 for(const key of ['animateBot(b,dt,now)',"poseBone(bot,'thigh_l'","poseBone(bot,'upperarm_l'",'b.deathProgress'])assert.ok(s.includes(key),key);
});
