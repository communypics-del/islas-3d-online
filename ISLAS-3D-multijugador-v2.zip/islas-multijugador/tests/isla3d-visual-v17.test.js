import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import {execFileSync} from 'node:child_process';
const js=fs.readFileSync(new URL('../public/isla3d.js',import.meta.url),'utf8');
test('3D syntax valid',()=>assert.doesNotThrow(()=>execFileSync(process.execPath,['--check',new URL('../public/isla3d.js',import.meta.url).pathname])));
test('tactical coastal map and custom gun exist',()=>{for(const name of ['function dock','function cliff','function lookout','function hut','barrel.rotation.x','Promise.allSettled'])assert.ok(js.includes(name),name)});
