import test from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {resolve,dirname} from 'node:path';
test('isla3d module passes JavaScript syntax check',()=>{const file=resolve(dirname(fileURLToPath(import.meta.url)),'../public/isla3d.js');assert.doesNotThrow(()=>execFileSync(process.execPath,['--check',file]));});
