import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const base=new URL('../public/assets/',import.meta.url).pathname;
test('glTF models include valid referenced binaries and textures',()=>{
 for(const rel of ['characters/Superhero_Male_FullBody.gltf','characters/Superhero_Female_FullBody.gltf','nature/Bush.gltf','nature/Bush_Small.gltf']){
  const file=path.join(base,rel),data=JSON.parse(fs.readFileSync(file,'utf8'));
  assert.ok(data.meshes?.length,rel);
  for(const a of [...(data.buffers||[]),...(data.images||[])])if(a.uri)assert.ok(fs.existsSync(path.join(path.dirname(file),a.uri)),`${rel}: missing ${a.uri}`);
 }
});
test('import map resolves GLTFLoader and SkeletonUtils from same Three version',()=>{
 const html=fs.readFileSync(new URL('../public/isla3d.html',import.meta.url),'utf8');
 const js=fs.readFileSync(new URL('../public/isla3d.js',import.meta.url),'utf8');
 assert.match(html,/type="importmap"/);assert.match(html,/three\/addons\//);
 assert.match(js,/GLTFLoader/);assert.match(js,/cloneSkeleton/);assert.match(js,/loadRealModels\(\)/);
});
