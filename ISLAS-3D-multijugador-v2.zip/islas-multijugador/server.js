import {matches,createMatch,joinMatch,startMatch,actMatch,viewMatch,tickMatches} from './shooter.js';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomBytes} from 'node:crypto';
import {newGame,joinGame,startGame,applyAction,snapshot,addBots,botDecision} from './game.js';
const HERE=path.dirname(fileURLToPath(import.meta.url));
const PUBLIC=path.join(HERE,'public');
const DB=process.env.ROOMS_FILE||path.join(HERE,'data','rooms.json');
const rooms=new Map();
try {const data=JSON.parse(fs.readFileSync(DB,'utf8'));for(const g of data)if(Date.now()-g.created<7*24*3600e3){for(const p of g.players){p.seatId||=randomBytes(9).toString('hex');p.avatar||=null}rooms.set(g.code,g)}}catch{}
const streams=new Map();
const voiceStreams=new Map();
const allowedAvatar=/^data:image\/(?:jpeg|webp|png);base64,[A-Za-z0-9+/=]+$/;
function avatarFrom(value){if(value==null||value==='')return null;if(typeof value!=='string'||value.length>88000||!allowedAvatar.test(value))throw Error('Imagen no válida o demasiado grande.');return value}
function announceVoice(code,message,except=null){for(const peer of voiceStreams.get(code)?.values()||[])if(peer.id!==except)try{peer.res.write(`data: ${JSON.stringify(message)}\n\n`)}catch{}}
const mime={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon','.webp':'image/webp'};
function persist(){fs.mkdirSync(path.dirname(DB),{recursive:true});const tmp=DB+'.tmp';fs.writeFileSync(tmp,JSON.stringify([...rooms.values()]));fs.renameSync(tmp,DB)}
function json(res,data,status=200){if(res.headersSent||res.writableEnded||res.destroyed)return;res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data))}
function bad(res,message,status=400){json(res,{error:message},status)}
function getRoom(code){const g=rooms.get(String(code||'').trim().toUpperCase());if(!g)throw Error('No encontramos esa sala. Comprueba el código.');return g}
function verify(g,token){const p=g.players.find(p=>p.id===token);if(!p)throw Error('Tu acceso a esta sala no es válido.');return p}
function publish(g){g.version++;persist();const conn=streams.get(g.code)||[];for(const c of conn)try{c.res.write(`data: ${JSON.stringify(snapshot(g,c.id))}\n\n`)}catch{}}
function setConnected(g){const ids=new Set((streams.get(g.code)||[]).map(x=>x.id));for(const p of g.players)p.connected=ids.has(p.id)}
const botTimers=new Map();
function scheduleBots(g){
 if(g.mode!=='ai'||!g.started||g.finished||botTimers.has(g.code))return;
 const tick=()=>{
   botTimers.delete(g.code);
   if(!g.started||g.finished)return;
   try{
     const pending=Object.keys(g.turn.pendingDiscard||{}).find(id=>g.players.some(p=>p.id===id&&p.bot));
     const id=pending||g.players[g.turn.phase==='setup'?(g.turn.setupStep<g.players.length?g.turn.setupStep:2*g.players.length-1-g.turn.setupStep):g.turn.secondary?(g.turn.index+3)%g.players.length:g.turn.index]?.id;
     const action=botDecision(g,id);
     if(action){applyAction(g,id,action);publish(g);}
   }catch(e){console.warn('Bot:',e.message)}
   const pendingAgain=Object.keys(g.turn.pendingDiscard||{}).some(id=>g.players.some(p=>p.id===id&&p.bot));
   const ix=g.turn.phase==='setup'?(g.turn.setupStep<g.players.length?g.turn.setupStep:2*g.players.length-1-g.turn.setupStep):g.turn.secondary?(g.turn.index+3)%g.players.length:g.turn.index;
   if(pendingAgain||g.players[ix]?.bot) scheduleBots(g);
 };
 botTimers.set(g.code,setTimeout(tick,650));
}
function makeCode(){let x;do{x=randomBytes(5).toString('hex').slice(0,8).toUpperCase()}while(rooms.has(x));return x}
async function readBody(req,limit=16000){const chunks=[];let total=0;for await(const chunk of req){total+=chunk.length;if(total>limit)throw Error('Solicitud demasiado grande.');chunks.push(chunk)}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'))}catch{throw Error('Datos inválidos.')}}
const requests=new Map();
function rateLimit(req){const ip=req.socket.remoteAddress||'unknown',now=Date.now();let x=requests.get(ip)||[];x=x.filter(t=>now-t<10000);if(x.length>=80)throw Error('Demasiadas solicitudes. Intenta de nuevo en unos segundos.');x.push(now);requests.set(ip,x);if(requests.size>500)for(const [key,value] of requests)if(now-value.at(-1)>10000)requests.delete(key)}
function serveStatic(req,res,url){let pathname=url.pathname==='/'?'/index.html':url.pathname;
 let decoded;try{decoded=decodeURIComponent(pathname)}catch{return bad(res,'URL incorrecta',400)}
 const filename=path.resolve(PUBLIC,'.'+decoded);if(!filename.startsWith(PUBLIC+path.sep))return bad(res,'No encontrado',404);
 fs.readFile(filename,(err,body)=>{if(res.writableEnded||res.destroyed)return;if(err)return bad(res,'No encontrado',404);res.writeHead(200,{'Content-Type':mime[path.extname(filename)]||'application/octet-stream','Cache-Control':path.extname(filename)==='.html'?'no-cache, no-store, must-revalidate':'public, max-age=300','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' https://cdn.jsdelivr.net 'sha256-XJO1qE/t7XZYEC0HTvK28+SYGr14JxUyBmyaaZMMEnE=' 'sha256-PJuPofc3VlYWTUNXN9BXKt1IhI2wg5qUvxVGhJE5x5k='; font-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"});res.end(body)})
}
setInterval(tickMatches,120).unref();
const server=http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost');
 try{
   rateLimit(req);
   if(url.pathname.startsWith('/api/shooter/')){
     if(req.method==='POST'&&url.pathname==='/api/shooter/create')return json(res,createMatch(await readBody(req)));
     if(req.method==='POST'&&url.pathname==='/api/shooter/join'){const b=await readBody(req);return json(res,joinMatch(b.room,b.name,b.profile));}
     if(req.method==='GET'&&url.pathname==='/api/shooter/state'){const g=matches.get(String(url.searchParams.get('room')||'').toUpperCase());if(!g)throw Error('Sala no encontrada');return json(res,viewMatch(g,url.searchParams.get('token')));}
     if(req.method==='POST'&&url.pathname==='/api/shooter/action'){const b=await readBody(req),g=matches.get(String(b.room||'').toUpperCase());if(!g)throw Error('Sala no encontrada');if(b.action?.type==='start')startMatch(g,b.token);else actMatch(g,b.token,b.action||{});return json(res,{ok:true});}
     return bad(res,'Ruta no encontrada',404);
   }
   if(req.method==='GET'&&url.pathname==='/api/health')return json(res,{ok:true,rooms:rooms.size});
   if(req.method==='GET'&&url.pathname==='/api/lobby-info'){const g=getRoom(url.searchParams.get('room'));return json(res,{room:g.code,players:g.players.map(p=>({name:p.name,avatar:p.avatar,connected:!!p.connected})),started:g.started,max:g.max,variant:g.variant})}
   if(req.method==='GET'&&url.pathname==='/api/state'){const g=getRoom(url.searchParams.get('room'));const id=url.searchParams.get('token');verify(g,id);return json(res,snapshot(g,id))}
   if(req.method==='GET'&&url.pathname==='/api/stream'){
     const g=getRoom(url.searchParams.get('room'));const id=url.searchParams.get('token');verify(g,id);
     res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no','Access-Control-Allow-Origin':'same-origin'});
     res.write(`data: ${JSON.stringify(snapshot(g,id))}\n\n`);const c={res,id};if(!streams.has(g.code))streams.set(g.code,new Set());streams.get(g.code).add(c);setConnected(g);for(const x of streams.get(g.code))try{x.res.write(`data: ${JSON.stringify(snapshot(g,x.id))}\n\n`)}catch{}
     const timer=setInterval(()=>{try{res.write(': ping\n\n')}catch{}},22000);
     req.on('close',()=>{clearInterval(timer);streams.get(g.code)?.delete(c);setConnected(g);for(const x of streams.get(g.code)||[])try{x.res.write(`data: ${JSON.stringify(snapshot(g,x.id))}\n\n`)}catch{}});return;
   }
   if(req.method==='POST'&&url.pathname==='/api/create'){
     const body=await readBody(req,110000);if(rooms.size>=500)throw Error('El servidor alcanzó el máximo de salas.');
     const code=makeCode(),g=newGame(code,body.name,body.max,body.variant);if(body.mode==='ai')addBots(g,g.host,Number(body.bots)||3,body.difficulty||'normal');g.players[0].avatar=avatarFrom(body.avatar);rooms.set(code,g);persist();return json(res,{room:code,token:g.host});
   }
   if(req.method==='POST'&&url.pathname==='/api/join'){
     const body=await readBody(req,110000);const g=getRoom(body.room);if(g.mode==='ai')throw Error('Las partidas contra IA son individuales.');const p=joinGame(g,body.name);p.avatar=avatarFrom(body.avatar);publish(g);return json(res,{room:g.code,token:p.id});
   }

   if(req.method==='POST'&&url.pathname==='/api/avatar'){
     const body=await readBody(req,110000),g=getRoom(body.room),p=verify(g,body.token);
     p.avatar=avatarFrom(body.avatar);publish(g);scheduleBots(g);return json(res,{ok:true});
   }
   if(req.method==='GET'&&url.pathname==='/api/voice-stream'){
     const g=getRoom(url.searchParams.get('room')),p=verify(g,url.searchParams.get('token'));
     let peers=voiceStreams.get(g.code);if(!peers){peers=new Map();voiceStreams.set(g.code,peers)}
     // One live voice connection per player; reconnects replace old sessions.
     const former=peers.get(p.seatId);if(former){try{former.res.end()}catch{}peers.delete(p.seatId)}
     res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no'});
     res.write(`data: ${JSON.stringify({type:'welcome',peers:[...peers.keys()]})}\n\n`);
     const peer={id:p.seatId,res};peers.set(p.seatId,peer);
     announceVoice(g.code,{type:'peer-joined',from:p.seatId},p.seatId);
     const timer=setInterval(()=>{try{res.write(': audio ping\n\n')}catch{}},15000);
     req.on('close',()=>{clearInterval(timer);if(peers.get(p.seatId)===peer){peers.delete(p.seatId);announceVoice(g.code,{type:'peer-left',from:p.seatId});}});return;
   }
   if(req.method==='POST'&&url.pathname==='/api/signal'){
     const body=await readBody(req,22000),g=getRoom(body.room),p=verify(g,body.token),peer=voiceStreams.get(g.code)?.get(body.to);
     if(!['offer','answer','candidate'].includes(body.type)||typeof body.to!=='string')throw Error('Señal no válida.');
     if(typeof body.payload!=='object'||!body.payload||JSON.stringify(body.payload).length>14000)throw Error('Datos de señal no válidos.');
     if(peer)peer.res.write(`data: ${JSON.stringify({type:body.type,from:p.seatId,payload:body.payload})}\n\n`);
     return json(res,{ok:true,delivered:!!peer});
   }
   if(req.method==='POST'&&url.pathname==='/api/action'){
     const body=await readBody(req);const g=getRoom(body.room),p=verify(g,body.token);
     if(body.action?.type==='start')startGame(g,p.id);else {if(['offerTrade','steal'].includes(body.action?.type)){const k=body.action.type==='offerTrade'?'to':'target';const publicId=body.action[k],target=g.players.find(x=>x.seatId===publicId);if(!target)throw Error('Jugador no válido.');body.action[k]=target.id}applyAction(g,p.id,body.action)}
     publish(g);scheduleBots(g);return json(res,{ok:true});
   }
   if(req.method==='GET'||req.method==='HEAD')return serveStatic(req,res,url);
   return bad(res,'Método no permitido',405);
 }catch(e){
   // A mobile browser can interrupt an already-open Server-Sent Events connection.
   // Never try to send HTTP headers twice: this previously crashed the entire server
   // and consequently destroyed every temporary room on Render Free.
   if(res.headersSent){
     if(!res.writableEnded&&!res.destroyed){try{res.end()}catch{}}
     console.warn('Connection interrupted after headers were sent:',e.message||e);
   } else if(!res.writableEnded&&!res.destroyed){
     try{bad(res,e.message||'Error interno',400)}catch(err){console.warn('Could not return HTTP error:',err.message)}
   }
 }
});
const PORT=Number(process.env.PORT)||3000;
server.listen(PORT,'0.0.0.0',()=>console.log(`ISLAS listo en http://localhost:${PORT}`));
